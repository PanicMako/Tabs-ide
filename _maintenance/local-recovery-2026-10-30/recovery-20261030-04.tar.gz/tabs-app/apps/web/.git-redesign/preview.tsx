import { AppAtomRegistryProvider } from "/src/state/atomRegistry";
import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import "/src/index.css";
import "/src/components/git/GitToolV2.css";
import { Sidebar, NAV } from "/src/components/git/Sidebar";
import { TopBar } from "/src/components/git/TopBar";
import { OverviewPanel } from "/src/components/git/OverviewPanel";
import { SettingsPanel } from "/src/components/git/SettingsPanel";
import { SettingsSectionHeader } from "/src/components/settings/SettingsLayout";
import { GitApiProvider } from "/src/components/git/gitApiContext";
import { BranchesPanel } from "/src/components/git/BranchesPanel";
import { HistoryPanel } from "/src/components/git/HistoryPanel";
import { StashesPanel } from "/src/components/git/StashesPanel";
import { ChangesPanel } from "/src/components/git/ChangesPanel";
import { DivergencePanel } from "/src/components/git/DivergencePanel";
import { AccountsPanel } from "/src/components/git/AccountsPanel";
import { DEFAULT_SERVER_SETTINGS } from "@tabs/contracts";
const providers = [{ instanceId: "codex", driver: "codex", displayName:"Codex", enabled:true, installed:true, status:"ready", auth:{status:"authenticated"}, models:[{slug:"gpt-5.3-codex",name:"GPT-5.3 Codex",isCustom:false,capabilities:null}], slashCommands:[],skills:[] }];
window.nativeApi = { server: { getConfig: async () => ({settings:{...DEFAULT_SERVER_SETTINGS, providers:{...DEFAULT_SERVER_SETTINGS.providers,codex:{...DEFAULT_SERVER_SETTINGS.providers.codex,enabled:true}},gitAi:{...DEFAULT_SERVER_SETTINGS.gitAi,gitTextGenerationModelSelection:{instanceId:"codex",model:"gpt-5.3-codex"}}},providers,keybindings:[]}), updateSettings: async () => DEFAULT_SERVER_SETTINGS } } as any;

const noop = () => {};
const environment = { git: { installed: true, version: "2.55.0" }, gitHub: { cliInstalled: true, authenticated: true, version: "2.98.0", activeLogin: "PanicMako", accounts: [] } };
environment.gitHub.accounts = [{host:"github.com",login:"PanicMako",active:true,scopes:["repo"]}] as any;
const branch = "codex/t3-parity-goal-2026-10-06";
const branches = { isRepo: true, hasOriginRemote: true, remoteName: "origin", pushAccess: "write", branches: [{ name: branch, current: true }] };
const status = { branch, aheadCount: 2, behindCount: 0, staged: { files: [], additions: 0, deletions: 0 }, unstaged: { files: [{ path: "apps/web/src/components/git/OverviewPanel.tsx", status: "M", additions: 14, deletions: 3 }], additions: 14, deletions: 3 }, conflicted: { files: [] }, hasOriginRemote: true };
const commits = [{sha:"abc123456789",shortSha:"abc123",subject:"Refine Git workspace",authorName:"Developer",authoredAt:"2026-10-13T10:00:00Z"}];
const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
document.documentElement.classList.add("dark");
document.documentElement.dataset.theme = "tabs-dark";
document.documentElement.style.setProperty("--font-display", "Syne, sans-serif");
function Preview() {
 const [panel, setPanel] = useState("overview");
 const [collapsed, setCollapsed] = useState(false);
 return <QueryClientProvider client={client}><GitApiProvider api={null} scopeKey="design-preview">
 <div style={{height:"100vh",background:"var(--background)",color:"var(--foreground)",display:"flex",flexDirection:"column"}}>
 <div style={{padding:"14px 24px",borderBottom:"1px solid var(--border)",fontSize:12,color:"var(--muted-foreground)"}}>Git workspace preview · Sample repository</div>
 <div className="git-tool-v2 flex flex-1 min-h-0 overflow-hidden" data-redesigned="true">
 <Sidebar redesigned={panel !== "prs"} repoName="tabs" panel={panel} setPanel={setPanel} collapsed={collapsed} setCollapsed={setCollapsed} changeCount={1} prCount={0} hasConflict={false} idPrefix="preview" />
 <div className="git-main flex flex-col flex-1 min-w-0 min-h-0 overflow-hidden">
 <TopBar repoName="tabs" branchLabel={branch} accentDotTone="ok" accounts={environment.gitHub.accounts} activeAccountLogin="PanicMako" terminalOpen={false} onToggleTerminal={noop} onSwitchAccount={noop} onOpenAccounts={() => setPanel("accounts")} onOpenSignIn={noop}/>
 <div className="git-content-scroll flex-1 overflow-y-auto"><div className="git-content-width w-full mx-auto git-page">
 <SettingsSectionHeader title={panel === "overview" ? "Repository overview" : panel === "settings" ? "Git settings" : NAV.find(n => n.id === panel)?.label || panel} description={NAV.find(n => n.id === panel)?.desc || ""}/>
 {panel === "overview" ? <OverviewPanel cwd="/preview/tabs" repoName="tabs" statusData={status} environmentData={environment} branchList={branches} commits={commits} watchedBranchStatuses={[{name:"main",aheadCount:2,behindCount:3}]} onGoToChanges={() => setPanel("changes")} onGoToAccounts={() => setPanel("accounts")} onGoToDivergence={() => setPanel("divergence")} onOpenSignIn={noop} onOpenAddRemote={noop} onOpenCreateBranch={noop} onOpenCreatePullRequest={noop} onRunInTerminal={noop} onInitRepo={noop}/> : panel === "settings" ? <SettingsPanel cwd="/preview/tabs" environmentData={environment} onOpenAddRemote={noop}/> : panel === "accounts" ? <AccountsPanel accounts={environment.gitHub.accounts} activeAccountLogin="PanicMako" repoName="tabs" onOpenConnectAccount={noop} onSwitchAccount={noop} onRemoveAccount={noop} onRefresh={async () => {}} /> : panel === "branches" ? <BranchesPanel cwd="/preview/tabs" activeBranch={branches.branches[0]} allBranches={[...branches.branches,{name:"main",current:false}]} aheadCount={2} behindCount={0} isDetached={false} onOpenNewBranch={noop} onOpenNewWorktree={noop}/> : panel === "history" ? <HistoryPanel cwd="/preview/tabs" commits={commits} onReset={noop} onRevert={noop} onCherryPick={noop}/> : panel === "stashes" ? <StashesPanel stashes={[{stashRef:"stash@{0}",message:"Workspace in progress",createdAt:"Today"}]} hasChanges behindCount={0} hasConflict={false} onOpenStash={noop} onOpenStashPullReapply={noop} onApplyStash={noop} onDropStash={noop}/> : panel === "changes" ? <ChangesPanel cwd="/preview/tabs" statusData={status} onOpenDiff={noop} onOpenStash={noop} onOpenDiscardAll={noop} onRunInTerminal={noop}/> : panel === "divergence" ? <DivergencePanel cwd="/preview/tabs" watchedBranchStatuses={[{name:"main",aheadCount:2,behindCount:3}]} onScanAllBranches={noop}/> : <p className="text-sm text-muted-foreground">This view requires a live repository. Pull-request layouts are preserved.</p>}
 </div></div></div></div></div>
 </GitApiProvider></QueryClientProvider>;
}
createRoot(document.getElementById("root")!).render(<AppAtomRegistryProvider><Preview/></AppAtomRegistryProvider>);
