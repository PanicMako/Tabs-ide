export interface CustomThemeColors {
  background: string;
  foreground: string;
  card: string;
  border: string;
  primary: string;
}

export interface CustomThemeConfig {
  baseVariant: "dark" | "light";
  colors: CustomThemeColors;
  tokenOverrides?: Record<string, string>;
  diffColorScheme?: "red-green" | "blue-orange";
  fonts: {
    uiFont: string;
    editorFont: string;
    /** Optional heading/display font pairing (e.g. from a named font combo like "Syne Dropped"). */
    headingFont?: string;
    sectionFont?: string | undefined;
    supportingFont?: string | undefined;
  };
}

export const BUILTIN_THEME_CONFIGS: Record<string, CustomThemeConfig> = {
  "tabs-dark": {
    baseVariant: "dark",
    colors: {
      background: "#101113",
      card: "#191b1f",
      foreground: "#f0f1f3",
      border: "#303339",
      primary: "#0E2AF3",
    },
    fonts: { uiFont: "Inter, sans-serif", editorFont: "Geist Mono, monospace" },
  },
  "true-black": {
    baseVariant: "dark",
    colors: {
      background: "#000000",
      card: "#0c0d10",
      foreground: "#f4f5f7",
      border: "#292c33",
      primary: "#709aff",
    },
    fonts: { uiFont: "Inter, sans-serif", editorFont: "Geist Mono, monospace" },
  },
  "tabs-monotone": {
    baseVariant: "dark",
    colors: {
      background: "#09090b",
      card: "#18181b",
      foreground: "#fafafa",
      border: "rgba(255, 255, 255, 0.12)",
      primary: "#e5e5e5",
    },
    tokenOverrides: { focusBorder: "#e5e5e573" },
    fonts: { uiFont: "Inter, sans-serif", editorFont: "Geist Mono, monospace" },
  },
  "tabs-monotone-light": {
    baseVariant: "light",
    colors: {
      background: "#eeeeee",
      card: "#fafafa",
      foreground: "#242424",
      border: "#d0d0d0",
      primary: "#3b3b3b",
    },
    fonts: { uiFont: "Inter, sans-serif", editorFont: "Geist Mono, monospace" },
  },
  "tabs-light": {
    baseVariant: "light",
    colors: {
      background: "#e9ecf2",
      card: "#f9fafc",
      foreground: "#202634",
      border: "#cdd3de",
      primary: "#0E2AF3",
    },
    fonts: { uiFont: "Inter, sans-serif", editorFont: "Geist Mono, monospace" },
  },
  abyss: {
    baseVariant: "dark",
    colors: {
      background: "#101718",
      card: "#1a2425",
      foreground: "#e5efed",
      border: "#344447",
      primary: "#73d7c3",
    },
    fonts: { uiFont: "Inter, sans-serif", editorFont: "Geist Mono, monospace" },
  },
  dracula: {
    baseVariant: "dark",
    colors: {
      background: "#1b161b",
      card: "#282128",
      foreground: "#f5e9ed",
      border: "#4a3c45",
      primary: "#efacc4",
    },
    fonts: { uiFont: "Inter, sans-serif", editorFont: "Geist Mono, monospace" },
  },
  "deep-blue": {
    baseVariant: "dark",
    colors: {
      background: "#131a16",
      card: "#1e2922",
      foreground: "#eaf0e5",
      border: "#3b4c3e",
      primary: "#c3d987",
    },
    fonts: { uiFont: "Inter, sans-serif", editorFont: "Geist Mono, monospace" },
  },
  "solarized-light": {
    baseVariant: "light",
    colors: {
      background: "#e9e6dc",
      card: "#f7f5ec",
      foreground: "#333b2d",
      border: "#cdcdbb",
      primary: "#536832",
    },
    fonts: { uiFont: "Inter, sans-serif", editorFont: "Geist Mono, monospace" },
  },
};

export type TokenCategory =
  | "surfaces"
  | "text"
  | "borders"
  | "accents"
  | "editor"
  | "widgets"
  | "git";

export interface TokenMetadata {
  id: string;
  label: string;
  description: string;
  category: TokenCategory;
  deriveDefault: (colors: CustomThemeColors, isDark: boolean) => string;
  contrastPairId?: string;
  isBg?: boolean;
}

export interface WcagCheckResult {
  fgToken: string;
  bgToken: string;
  fgLabel: string;
  bgLabel: string;
  fgHex: string;
  bgHex: string;
  ratio: number;
  isLowContrast: boolean;
  recommendedFg?: string | undefined;
}

/**
 * Normalizes a color string to a valid hex string (#RRGGBB or #RRGGBBAA).
 * Supports #RGB, #RGBA, #RRGGBB, #RRGGBBAA, rgb(), rgba(), and transparent.
 */
export function toHexColor(color: string | undefined): string {
  if (!color || typeof color !== "string") return "#000000";
  const trimmed = color.trim();
  if (trimmed === "transparent") return "#00000000";

  const rgbMatch = trimmed.match(
    /^rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\s*\)/i,
  );
  if (rgbMatch) {
    const r = parseInt(rgbMatch[1] || "0", 10)
      .toString(16)
      .padStart(2, "0");
    const g = parseInt(rgbMatch[2] || "0", 10)
      .toString(16)
      .padStart(2, "0");
    const b = parseInt(rgbMatch[3] || "0", 10)
      .toString(16)
      .padStart(2, "0");
    let a = "";
    if (rgbMatch[4] !== undefined) {
      a = Math.round(parseFloat(rgbMatch[4]) * 255)
        .toString(16)
        .padStart(2, "0");
    }
    return `#${r}${g}${b}${a}`;
  }

  let clean = trimmed.replace(/^#/, "");
  if (clean.length === 3 || clean.length === 4) {
    clean = clean
      .split("")
      .map((c) => c + c)
      .join("");
  }
  if (clean.length === 6 || clean.length === 8) {
    return `#${clean}`;
  }
  if (clean.length > 8) return `#${clean.substring(0, 8)}`;
  if (clean.length > 6) return `#${clean.substring(0, 6)}`;
  return "#000000";
}

/**
 * Returns a hex color with alpha channel appended, e.g. #RRGGBBAA.
 */
export function alpha(color: string, opacity: number): string {
  const hex = toHexColor(color);
  const clampOp = Math.max(0, Math.min(1, opacity));
  const intOp = Math.round(clampOp * 255)
    .toString(16)
    .padStart(2, "0");
  return `${hex}${intOp}`;
}

/**
 * Blends a color with potential alpha channel over a solid background color to compute its effective visual hex color.
 */
export function resolveSolidColor(colorHex: string, parentBgHex = "#121824"): string {
  if (!colorHex || typeof colorHex !== "string") return toHexColor(parentBgHex);
  const clean = colorHex.trim().replace(/^#/, "");
  if (clean.length === 8) {
    const fgR = parseInt(clean.substring(0, 2), 16);
    const fgG = parseInt(clean.substring(2, 4), 16);
    const fgB = parseInt(clean.substring(4, 6), 16);
    const opacity = parseInt(clean.substring(6, 8), 16) / 255;

    const baseHex = toHexColor(parentBgHex).replace("#", "");
    const bgR = parseInt(baseHex.substring(0, 2), 16);
    const bgG = parseInt(baseHex.substring(2, 4), 16);
    const bgB = parseInt(baseHex.substring(4, 6), 16);

    const r = Math.round(bgR + (fgR - bgR) * opacity);
    const g = Math.round(bgG + (fgG - bgG) * opacity);
    const b = Math.round(bgB + (fgB - bgB) * opacity);

    return `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
  }
  return toHexColor(colorHex);
}

/**
 * Calculates sRGB relative luminance for contrast ratio checking.
 */
export function calculateLuminance(hex: string): number {
  const norm = toHexColor(hex).replace("#", "");
  const r = parseInt(norm.substring(0, 2), 16) / 255;
  const g = parseInt(norm.substring(2, 4), 16) / 255;
  const b = parseInt(norm.substring(4, 6), 16) / 255;

  const cal = (val: number) =>
    val <= 0.03928 ? val / 12.92 : Math.pow((val + 0.055) / 1.055, 2.4);

  return 0.2126 * cal(r) + 0.7152 * cal(g) + 0.0722 * cal(b);
}

/**
 * Calculates WCAG contrast ratio between two hex colors, blending transparent surfaces over a parent background.
 */
function calculateRawContrastRatio(fgHex: string, bgHex: string, parentBgHex = "#121824"): number {
  const solidBg = resolveSolidColor(bgHex, parentBgHex);
  const solidFg = resolveSolidColor(fgHex, solidBg);

  const l1 = calculateLuminance(solidFg);
  const l2 = calculateLuminance(solidBg);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  const ratio = (lighter + 0.05) / (darker + 0.05);

  return ratio;
}

export function calculateContrastRatio(
  fgHex: string,
  bgHex: string,
  parentBgHex = "#121824",
): { ratio: number; isLowContrast: boolean } {
  const ratio = calculateRawContrastRatio(fgHex, bgHex, parentBgHex);
  return {
    ratio: Math.round(ratio * 10) / 10,
    isLowContrast: ratio < 4.5,
  };
}

/**
 * Clamps / adjusts a foreground color against a background color to guarantee a minimum WCAG contrast ratio.
 * Preserves the original color's hue and saturation as much as possible while shifting lightness.
 */
export function ensureMinContrast(
  fgColor: string,
  bgColor: string,
  minRatio = 4.5,
  parentBgHex = "#121824",
): string {
  const solidBg = resolveSolidColor(bgColor, parentBgHex);
  const fgHex = toHexColor(fgColor);

  const currentRatio = calculateRawContrastRatio(fgHex, solidBg);
  if (currentRatio >= minRatio) {
    return fgColor;
  }

  const bgLum = calculateLuminance(solidBg);
  const shouldLighten = 1.05 / (bgLum + 0.05) > (bgLum + 0.05) / 0.05;

  const cleanFg = fgHex.replace("#", "");
  const r = parseInt(cleanFg.substring(0, 2), 16);
  const g = parseInt(cleanFg.substring(2, 4), 16);
  const b = parseInt(cleanFg.substring(4, 6), 16);

  let bestHex = fgHex;
  let bestRatio = currentRatio;

  for (let step = 1; step <= 20; step++) {
    const t = step / 20;

    let nr: number;
    let ng: number;
    let nb: number;

    if (shouldLighten) {
      nr = Math.round(r + (255 - r) * t);
      ng = Math.round(g + (255 - g) * t);
      nb = Math.round(b + (255 - b) * t);
    } else {
      nr = Math.round(r * (1 - t));
      ng = Math.round(g * (1 - t));
      nb = Math.round(b * (1 - t));
    }

    const hexCandidate = `#${nr.toString(16).padStart(2, "0")}${ng.toString(16).padStart(2, "0")}${nb.toString(16).padStart(2, "0")}`;
    const candRatio = calculateRawContrastRatio(hexCandidate, solidBg);

    if (candRatio > bestRatio) {
      bestRatio = candRatio;
      bestHex = hexCandidate;
    }

    if (candRatio >= minRatio) {
      if (fgHex.length === 9) {
        const alphaSuffix = fgHex.substring(7, 9);
        return `${hexCandidate}${alphaSuffix}`;
      }
      return hexCandidate;
    }
  }

  const fallback = shouldLighten ? "#f8fafc" : "#0f172a";
  if (fgHex.length === 9) {
    const alphaSuffix = fgHex.substring(7, 9);
    return `${fallback}${alphaSuffix}`;
  }
  return fallback;
}

/**
 * Determines optimal primary text foreground (#ffffff vs #0f172a) for a primary background.
 * Clamps result to guarantee WCAG AA contrast ratio (>= 4.5:1).
 */
export function getOptimalPrimaryForeground(primaryHex: string): string {
  if (!primaryHex) return "#ffffff";
  const whiteRatio = calculateContrastRatio("#ffffff", primaryHex).ratio;
  const darkRatio = calculateContrastRatio("#0f172a", primaryHex).ratio;
  if (whiteRatio >= 4.5) return "#ffffff";
  if (darkRatio < 4.5) return "#000000";
  return darkRatio >= whiteRatio ? "#0f172a" : "#ffffff";
}

/**
 * Suggests a WCAG AA-compliant foreground color against a background color.
 */
export function suggestAccessibleFg(fgHex: string, bgHex: string): string {
  return ensureMinContrast(fgHex, bgHex, 4.5);
}

/**
 * Master Spec & Registry for Native VS Code Tokens + Web App Shell Component Tokens (~95 Tokens Total).
 */
const VSCODE_TOKEN_REGISTRY_ENTRIES: TokenMetadata[] = [
  // ── 0. Web App Shell Component Tokens ────────────────────────────────────
  {
    id: "app.primaryBackground",
    label: "App Primary Button Background",
    description: "Background for primary web app buttons (e.g. Save Preset)",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => c.primary,
  },
  {
    id: "app.primaryForeground",
    label: "App Primary Button Text (Save Preset)",
    description: "Foreground text color for primary buttons (Save Preset)",
    category: "accents",
    contrastPairId: "app.primaryBackground",
    deriveDefault: (c) => getOptimalPrimaryForeground(c.primary),
  },
  {
    id: "app.secondaryBackground",
    label: "App Secondary Button Background",
    description: "Background for secondary UI controls",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "app.secondaryForeground",
    label: "App Secondary Button Text",
    description: "Text color for secondary UI controls",
    category: "accents",
    contrastPairId: "app.secondaryBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "app.accentBackground",
    label: "App Accent Highlight Background",
    description: "Background for interactive highlights",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "app.accentForeground",
    label: "App Accent Highlight Text",
    description: "Text color for interactive highlights",
    category: "accents",
    contrastPairId: "app.accentBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "app.cardBackground",
    label: "App Card / Dialog Surface",
    description: "Background for modal cards and settings drawers",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "app.cardForeground",
    label: "App Card / Dialog Text",
    description: "Text color for modal cards and settings drawers",
    category: "text",
    contrastPairId: "app.cardBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "app.popoverBackground",
    label: "App Popover / Dropdown Surface",
    description: "Background for floating tooltips and popovers",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "app.popoverForeground",
    label: "App Popover / Dropdown Text",
    description: "Text color for floating tooltips and popovers",
    category: "text",
    contrastPairId: "app.popoverBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "app.mutedBackground",
    label: "App Muted Surface",
    description: "Background for subtle containers",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.06),
  },
  {
    id: "app.mutedForeground",
    label: "App Muted Subtitle Text",
    description: "Text color for secondary subtitles and muted labels",
    category: "text",
    contrastPairId: "editor.background",
    deriveDefault: (c, isDark) => (isDark ? "#ffffffa6" : "#0f172aa6"),
  },
  {
    id: "app.destructiveBackground",
    label: "App Destructive Button Background",
    description: "Background for destructive actions (e.g. Delete)",
    category: "accents",
    isBg: true,
    deriveDefault: () => "#b91c1c",
  },
  {
    id: "app.destructiveForeground",
    label: "App Destructive Button Text",
    description: "Text color inside destructive action buttons",
    category: "accents",
    contrastPairId: "app.destructiveBackground",
    deriveDefault: () => "#ffffff",
  },

  // ── 1. Surfaces & Containers ──────────────────────────────────────────────
  {
    id: "titleBar.activeBackground",
    label: "Title Bar Background",
    description: "Active window title bar background",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "titleBar.inactiveBackground",
    label: "Title Bar Inactive Bg",
    description: "Inactive window title bar background",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "activityBar.background",
    label: "Activity Bar Background",
    description: "Activity bar container background",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "activityBar.activeBackground",
    label: "Activity Bar Active Item",
    description: "Background of the active activity bar item",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.1),
  },
  {
    id: "sideBar.background",
    label: "Side Bar Background",
    description: "Sidebar panel background color",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "sideBarSectionHeader.background",
    label: "Side Bar Section Header",
    description: "Sidebar section header background",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "editorGroupHeader.tabsBackground",
    label: "Tabs Header Background",
    description: "Tab bar row container background",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "editorGroupHeader.noTabsBackground",
    label: "No-Tabs Header Background",
    description: "Header background when tabs are disabled",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "tab.activeBackground",
    label: "Active Tab Background",
    description: "Background of the focused/active tab",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "tab.inactiveBackground",
    label: "Inactive Tab Background",
    description: "Background of unselected tabs",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "tab.hoverBackground",
    label: "Tab Hover Background",
    description: "Background of a tab when hovered",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.05),
  },
  {
    id: "editor.background",
    label: "Editor Background",
    description: "Main code editor canvas background",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "panel.background",
    label: "Panel / Terminal Background",
    description: "Bottom panel background color",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "terminal.background",
    label: "Integrated Terminal Bg",
    description: "Integrated terminal container background",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "statusBar.background",
    label: "Status Bar Background",
    description: "Main status bar background color",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "statusBar.inactiveBackground",
    label: "Inactive Status Bar Background",
    description: "Status bar background when the window loses focus",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "statusBar.noFolderBackground",
    label: "Status Bar No-Folder Bg",
    description: "Status bar background when no folder is open",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "statusBar.debuggingBackground",
    label: "Status Bar Debugging Bg",
    description: "Status bar background during debug sessions",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "statusBarItem.prominentBackground",
    label: "Status Bar Item Prominent Bg",
    description: "Background of prominent status items",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "statusBarItem.remoteBackground",
    label: "Status Bar Item Remote Bg",
    description: "Background of remote status items",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.primary,
  },

  // ── 2. Text & Typography ──────────────────────────────────────────────────
  {
    id: "foreground",
    label: "Global Text / Foreground",
    description: "Default body text color",
    category: "text",
    contrastPairId: "editor.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "disabledForeground",
    label: "Disabled Text Color",
    description: "Text color for disabled UI controls",
    category: "text",
    contrastPairId: "editor.background",
    deriveDefault: (c) => alpha(c.foreground, 0.38),
  },
  {
    id: "descriptionForeground",
    label: "Description Muted Text",
    description: "Subtitles and secondary descriptions",
    category: "text",
    contrastPairId: "editor.background",
    deriveDefault: (c, isDark) => (isDark ? "#ffffffa6" : "#0f172aa6"),
  },
  {
    id: "titleBar.activeForeground",
    label: "Title Bar Text",
    description: "Active window title text color",
    category: "text",
    contrastPairId: "titleBar.activeBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "titleBar.inactiveForeground",
    label: "Title Bar Inactive Text",
    description: "Inactive title bar text color",
    category: "text",
    contrastPairId: "titleBar.inactiveBackground",
    deriveDefault: (c) => alpha(c.foreground, 0.5),
  },
  {
    id: "activityBar.foreground",
    label: "Activity Bar Icon Color",
    description: "Active activity bar icon color",
    category: "text",
    contrastPairId: "activityBar.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "activityBar.inactiveForeground",
    label: "Activity Bar Inactive Icon",
    description: "Inactive activity bar icon color",
    category: "text",
    contrastPairId: "activityBar.background",
    deriveDefault: (c) => alpha(c.foreground, 0.5),
  },
  {
    id: "sideBar.foreground",
    label: "Side Bar Text Color",
    description: "General sidebar text color",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "sideBarTitle.foreground",
    label: "Side Bar Title Text",
    description: "Sidebar main title text color",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "sideBarSectionHeader.foreground",
    label: "Side Bar Header Text",
    description: "Sidebar section title text color",
    category: "text",
    contrastPairId: "sideBarSectionHeader.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "tab.activeForeground",
    label: "Active Tab Text",
    description: "Foreground text color for active tab",
    category: "text",
    contrastPairId: "tab.activeBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "tab.inactiveForeground",
    label: "Inactive Tab Text",
    description: "Foreground text color for unselected tabs",
    category: "text",
    contrastPairId: "tab.inactiveBackground",
    deriveDefault: (c) => alpha(c.foreground, 0.55),
  },
  {
    id: "tab.hoverForeground",
    label: "Tab Hover Text",
    description: "Text color of a hovered tab",
    category: "text",
    contrastPairId: "tab.hoverBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "editor.foreground",
    label: "Editor Default Text",
    description: "Code editor text color",
    category: "text",
    contrastPairId: "editor.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "panelTitle.activeForeground",
    label: "Panel Active Tab Text",
    description: "Active panel title text color",
    category: "text",
    contrastPairId: "panel.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "panelTitle.inactiveForeground",
    label: "Panel Inactive Tab Text",
    description: "Inactive panel title text color",
    category: "text",
    contrastPairId: "panel.background",
    deriveDefault: (c) => alpha(c.foreground, 0.5),
  },
  {
    id: "terminal.foreground",
    label: "Terminal Text",
    description: "Default terminal text color",
    category: "text",
    contrastPairId: "terminal.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "statusBar.foreground",
    label: "Status Bar Text",
    description: "Status bar text color (including OVR indicator)",
    category: "text",
    contrastPairId: "statusBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "statusBar.noFolderForeground",
    label: "Status Bar No-Folder Text",
    description: "Status bar text when no folder open",
    category: "text",
    contrastPairId: "statusBar.noFolderBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "statusBar.debuggingForeground",
    label: "Status Bar Debugging Text",
    description: "Status bar text during debugging",
    category: "text",
    contrastPairId: "statusBar.debuggingBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "statusBarItem.prominentForeground",
    label: "Status Item Prominent Text",
    description: "Text color for prominent status items",
    category: "text",
    contrastPairId: "statusBarItem.prominentBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "statusBarItem.remoteForeground",
    label: "Status Item Remote Text",
    description: "Text color for remote status items",
    category: "text",
    contrastPairId: "statusBarItem.remoteBackground",
    deriveDefault: (c) => getOptimalPrimaryForeground(c.primary),
  },
  {
    id: "list.hoverForeground",
    label: "List Item Hover Text",
    description: "Text color of list items on hover",
    category: "text",
    contrastPairId: "list.hoverBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "list.activeSelectionForeground",
    label: "List Active Selected Text",
    description: "Text color of active list selections",
    category: "text",
    contrastPairId: "list.activeSelectionBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "list.inactiveSelectionForeground",
    label: "List Inactive Selected Text",
    description: "Text color of inactive list selections",
    category: "text",
    contrastPairId: "list.inactiveSelectionBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "list.focusForeground",
    label: "List Focused Text",
    description: "Text color of focused list items",
    category: "text",
    contrastPairId: "list.focusBackground",
    deriveDefault: (c) => c.foreground,
  },

  // ── 3. Borders & Dividers ─────────────────────────────────────────────────
  {
    id: "focusBorder",
    label: "Focus Ring Border",
    description: "Border outline for focused interactive elements",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "widget.border",
    label: "Widget Outline Border",
    description: "Border outline around floating widgets",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "widget.shadow",
    label: "Widget Shadow Color",
    description: "Shadow color for popups and widgets",
    category: "borders",
    deriveDefault: () => "transparent",
  },
  {
    id: "titleBar.border",
    label: "Title Bar Divider",
    description: "Border under the window titlebar",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "activityBar.border",
    label: "Activity Bar Border",
    description: "Border separating activity bar from sidebar",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "sideBar.border",
    label: "Side Bar Border",
    description: "Border separating sidebar from editor",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "sideBarSectionHeader.border",
    label: "Side Bar Header Border",
    description: "Border under sidebar section headers",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "editorGroupHeader.tabsBorder",
    label: "Tab Bar Bottom Border",
    description: "Border under the tab bar row",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "editorGroup.border",
    label: "Editor Split Group Border",
    description: "Border separating split editor panes",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "tab.border",
    label: "Tab Border",
    description: "Border separating individual tabs",
    category: "borders",
    deriveDefault: () => "transparent",
  },
  {
    id: "tab.activeBorder",
    label: "Active Tab Bottom Line",
    description: "Line indicator at bottom of active tab",
    category: "borders",
    deriveDefault: () => "transparent",
  },
  {
    id: "tab.activeBorderTop",
    label: "Active Tab Top Line",
    description: "Line indicator at top of active tab",
    category: "borders",
    deriveDefault: () => "transparent",
  },
  {
    id: "tab.unfocusedActiveBorder",
    label: "Unfocused Tab Line",
    description: "Active tab bottom line when window unfocused",
    category: "borders",
    deriveDefault: () => "transparent",
  },
  {
    id: "tab.unfocusedActiveBorderTop",
    label: "Unfocused Tab Top Line",
    description: "Active tab top line when window unfocused",
    category: "borders",
    deriveDefault: () => "transparent",
  },
  {
    id: "editorWidget.border",
    label: "Editor Widget Border",
    description: "Border around find/replace popups",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "editorHoverWidget.border",
    label: "Hover Tooltip Border",
    description: "Border around hover tooltips",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "panel.border",
    label: "Panel Top Border",
    description: "Border separating terminal panel from editor",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "statusBar.border",
    label: "Status Bar Top Border",
    description: "Border separating status bar from main workbench",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "input.border",
    label: "Input Box Border",
    description: "Border around text input boxes",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "dropdown.border",
    label: "Dropdown Border",
    description: "Border around dropdown select menus",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "checkbox.border",
    label: "Checkbox Border",
    description: "Border around checkbox inputs",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "menu.border",
    label: "Menu Popup Border",
    description: "Border around context menus",
    category: "borders",
    deriveDefault: (c) => c.border,
  },

  // ── 4. Accents & Interaction States ───────────────────────────────────────
  {
    id: "selection.background",
    label: "General Selection Bg",
    description: "Background for text selections in UI",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.25),
  },
  {
    id: "icon.foreground",
    label: "Default Icon Color",
    description: "Color for icons across the interface",
    category: "accents",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "activityBarBadge.background",
    label: "Activity Badge Bg",
    description: "Badge background in activity bar",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => c.primary,
  },
  {
    id: "activityBarBadge.foreground",
    label: "Activity Badge Text",
    description: "Text color inside activity bar badges",
    category: "accents",
    contrastPairId: "activityBarBadge.background",
    deriveDefault: (c) => getOptimalPrimaryForeground(c.primary),
  },
  {
    id: "activityBar.activeBorder",
    label: "Activity Active Border",
    description: "Left accent bar on active activity icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "editorLineNumber.activeForeground",
    label: "Current Line Number",
    description: "Line number color for active line",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "editorCursor.foreground",
    label: "Editor Cursor Color",
    description: "Color of the editor insertion caret",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "editor.selectionBackground",
    label: "Editor Selected Text Bg",
    description: "Selection background in code editor",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "editor.selectionHighlightBackground",
    label: "Selection Matches Highlight",
    description: "Highlight color for matching selections",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.12),
  },
  {
    id: "editor.inactiveSelectionBackground",
    label: "Inactive Selection Bg",
    description: "Editor selection when focus is lost",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.1),
  },
  {
    id: "editor.lineHighlightBackground",
    label: "Active Line Background",
    description: "Background highlight behind active cursor line",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.04),
  },
  {
    id: "editor.lineHighlightBorder",
    label: "Active Line Border",
    description: "Border around active cursor line",
    category: "accents",
    deriveDefault: () => "transparent",
  },
  {
    id: "panelTitle.activeBorder",
    label: "Panel Active Tab Line",
    description: "Active indicator line under panel tab",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "statusBarItem.hoverBackground",
    label: "Status Item Hover",
    description: "Background of status bar item on hover",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "statusBarItem.activeBackground",
    label: "Status Item Click",
    description: "Background of status bar item when pressed",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.15),
  },
  {
    id: "list.hoverBackground",
    label: "List Hover Background",
    description: "Background of items in lists on hover",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.1),
  },
  {
    id: "list.activeSelectionBackground",
    label: "List Selected Background",
    description: "Background of focused selected list item",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "list.inactiveSelectionBackground",
    label: "List Inactive Selected Bg",
    description: "Background of selected item when unfocused",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.12),
  },
  {
    id: "list.focusBackground",
    label: "List Focus Background",
    description: "Background of item when focused in tree",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "list.highlightForeground",
    label: "List Search Match Highlight",
    description: "Text highlight color for search matches",
    category: "accents",
    contrastPairId: "list.hoverBackground",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "button.background",
    label: "Primary Button Bg",
    description: "Background color of primary action buttons",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => c.primary,
  },
  {
    id: "button.foreground",
    label: "Primary Button Text",
    description: "Text color inside primary action buttons",
    category: "accents",
    contrastPairId: "button.background",
    deriveDefault: (c) => getOptimalPrimaryForeground(c.primary),
  },
  {
    id: "button.hoverBackground",
    label: "Primary Button Hover",
    description: "Background color of primary button on hover",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.85),
  },
  {
    id: "button.secondaryBackground",
    label: "Secondary Button Bg",
    description: "Background color of secondary action buttons",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "button.secondaryForeground",
    label: "Secondary Button Text",
    description: "Text color inside secondary action buttons",
    category: "accents",
    contrastPairId: "button.secondaryBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "button.secondaryHoverBackground",
    label: "Secondary Button Hover",
    description: "Background color of secondary button on hover",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.14),
  },
  {
    id: "button.separator",
    label: "Button Dropdown Separator",
    description: "Separator line in split dropdown buttons",
    category: "accents",
    deriveDefault: (c) => getOptimalPrimaryForeground(c.primary),
  },
  {
    id: "badge.background",
    label: "Badge Background",
    description: "Notification badge background color",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => c.primary,
  },
  {
    id: "badge.foreground",
    label: "Badge Text Color",
    description: "Text color inside notification badges",
    category: "accents",
    contrastPairId: "badge.background",
    deriveDefault: (c) => getOptimalPrimaryForeground(c.primary),
  },

  // ── 5. Editor Specific ───────────────────────────────────────────────────
  {
    id: "editorLineNumber.foreground",
    label: "Editor Line Numbers",
    description: "Code editor gutter line number color",
    category: "editor",
    contrastPairId: "editor.background",
    deriveDefault: (c) => alpha(c.foreground, 0.4),
  },
  {
    id: "editorIndentGuide.background",
    label: "Indent Guide Lines",
    description: "Vertical indent guide line color",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "editorIndentGuide.activeBackground",
    label: "Active Indent Guide",
    description: "Indent guide color for active code block",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.16),
  },
  {
    id: "editorWhitespace.foreground",
    label: "Whitespace Characters",
    description: "Color for visible whitespace characters",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.1),
  },
  {
    id: "tree.indentGuidesStroke",
    label: "Tree View Indent Lines",
    description: "Indent lines in explorer tree views",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.1),
  },
  {
    id: "scrollbar.shadow",
    label: "Scrollbar Shadow",
    description: "Shadow cast by scrollbar containers",
    category: "editor",
    deriveDefault: () => "transparent",
  },
  {
    id: "scrollbarSlider.background",
    label: "Scrollbar Thumb",
    description: "Scrollbar slider thumb background",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.12),
  },
  {
    id: "scrollbarSlider.hoverBackground",
    label: "Scrollbar Thumb Hover",
    description: "Scrollbar thumb color on hover",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.2),
  },
  {
    id: "scrollbarSlider.activeBackground",
    label: "Scrollbar Thumb Active",
    description: "Scrollbar thumb color when dragged",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.3),
  },

  // ── 6. Widgets & Overlays ─────────────────────────────────────────────────
  {
    id: "editorWidget.background",
    label: "Editor Widget Bg",
    description: "Background for floating editor popups",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "editorWidget.foreground",
    label: "Editor Widget Text",
    description: "Text color inside floating editor popups",
    category: "widgets",
    contrastPairId: "editorWidget.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "editorSuggestWidget.background",
    label: "Suggest / Auto-complete Bg",
    description: "Background for code completion popover",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "editorSuggestWidget.border",
    label: "Suggest Popover Border",
    description: "Border around auto-complete popup",
    category: "widgets",
    deriveDefault: (c) => c.border,
  },
  {
    id: "editorSuggestWidget.foreground",
    label: "Suggest Popover Text",
    description: "Text color inside auto-complete popup",
    category: "widgets",
    contrastPairId: "editorSuggestWidget.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "editorSuggestWidget.selectedBackground",
    label: "Suggest Active Item Bg",
    description: "Background of selected item in suggest popover",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "editorSuggestWidget.selectedForeground",
    label: "Suggest Active Item Text",
    description: "Text color of selected item in suggest popover",
    category: "widgets",
    contrastPairId: "editorSuggestWidget.selectedBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "editorHoverWidget.background",
    label: "Hover Tooltip Background",
    description: "Background color of hover tooltips",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "editorHoverWidget.foreground",
    label: "Hover Tooltip Text",
    description: "Text color of hover tooltips",
    category: "widgets",
    contrastPairId: "editorHoverWidget.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "input.background",
    label: "Input Field Background",
    description: "Background color of text input boxes",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "input.foreground",
    label: "Input Field Text",
    description: "Text color inside text input boxes",
    category: "widgets",
    contrastPairId: "input.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "input.placeholderForeground",
    label: "Input Placeholder Text",
    description: "Placeholder text color inside text inputs",
    category: "widgets",
    contrastPairId: "input.background",
    deriveDefault: (c) => alpha(c.foreground, 0.4),
  },
  {
    id: "dropdown.background",
    label: "Dropdown Select Bg",
    description: "Background color of dropdown select menus",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "dropdown.foreground",
    label: "Dropdown Select Text",
    description: "Text color inside dropdown menus",
    category: "widgets",
    contrastPairId: "dropdown.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "checkbox.background",
    label: "Checkbox Background",
    description: "Background color of checkbox input",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "checkbox.foreground",
    label: "Checkbox Check Mark",
    description: "Check mark icon color in checkboxes",
    category: "widgets",
    contrastPairId: "checkbox.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "menu.background",
    label: "Context Menu Background",
    description: "Background of context menus",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "menu.foreground",
    label: "Context Menu Text",
    description: "Text color inside context menus",
    category: "widgets",
    contrastPairId: "menu.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "menu.selectionBackground",
    label: "Context Menu Selected Item",
    description: "Background of selected context menu item",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "menu.selectionForeground",
    label: "Context Menu Selected Text",
    description: "Text of selected context menu item",
    category: "widgets",
    contrastPairId: "menu.selectionBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "quickInput.background",
    label: "Command Palette Bg",
    description: "Background of Quick Open / Command Palette",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "quickInput.foreground",
    label: "Command Palette Text",
    description: "Text color inside Command Palette",
    category: "widgets",
    contrastPairId: "quickInput.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "quickInputList.focusBackground",
    label: "Command Palette Selection",
    description: "Selection background inside Command Palette",
    category: "widgets",
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "notifications.background",
    label: "Notification Toast Bg",
    description: "Background of popup notification toasts",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "notifications.foreground",
    label: "Notification Toast Text",
    description: "Text inside popup notification toasts",
    category: "widgets",
    contrastPairId: "notifications.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "notifications.border",
    label: "Notification Toast Border",
    description: "Border around popup notification toasts",
    category: "widgets",
    deriveDefault: (c) => c.border,
  },
  {
    id: "errorForeground",
    label: "Global Error Red",
    description: "Color for error messages and indicators",
    category: "widgets",
    contrastPairId: "editor.background",
    deriveDefault: () => "#f87171",
  },

  // ── 7. Git & Status Decorators ───────────────────────────────────────────
  {
    id: "gitDecoration.modifiedResourceForeground",
    label: "Git Modified Color",
    description: "Tree view label color for modified files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#eab308" : "#ca8a04"),
  },
  {
    id: "gitDecoration.deletedResourceForeground",
    label: "Git Deleted Color",
    description: "Tree view label color for deleted files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "gitDecoration.addedResourceForeground",
    label: "Git Added Color",
    description: "Tree view label color for staged new files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#4ade80" : "#16a34a"),
  },
  {
    id: "gitDecoration.untrackedResourceForeground",
    label: "Git Untracked Color",
    description: "Tree view label color for untracked files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#4ade80" : "#16a34a"),
  },
  {
    id: "gitDecoration.conflictingResourceForeground",
    label: "Git Conflict Color",
    description: "Tree view label color for merge conflicts",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#f97316" : "#ea580c"),
  },
  {
    id: "gitDecoration.submoduleResourceForeground",
    label: "Git Submodule Color",
    description: "Tree view label color for git submodules",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#a855f7" : "#9333ea"),
  },
  {
    id: "gitDecoration.ignoredResourceForeground",
    label: "Git Ignored Color",
    description: "Tree view label color for .gitignore files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => alpha(c.foreground, 0.4),
  },

  // ── 8. Diff Editor & Gutter / Overview Tokens ────────────────────────────
  {
    id: "diffEditor.insertedTextBackground",
    label: "Diff Inserted Text Bg",
    description: "Background color for text that got inserted",
    category: "git",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#34d39933" : "#16a34a33"),
  },
  {
    id: "diffEditor.removedTextBackground",
    label: "Diff Removed Text Bg",
    description: "Background color for text that got removed",
    category: "git",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#f8717140" : "#dc262633"),
  },
  {
    id: "diffEditor.insertedLineBackground",
    label: "Diff Inserted Line Bg",
    description: "Background color for lines that got inserted",
    category: "git",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#34d3991f" : "#16a34a1a"),
  },
  {
    id: "diffEditor.removedLineBackground",
    label: "Diff Removed Line Bg",
    description: "Background color for lines that got removed",
    category: "git",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#f871711f" : "#dc26261a"),
  },
  {
    id: "diffEditorGutter.insertedLineBackground",
    label: "Diff Gutter Inserted Bg",
    description: "Background color for margin/gutter where lines got inserted",
    category: "git",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#34d3994d" : "#16a34a4d"),
  },
  {
    id: "diffEditorGutter.removedLineBackground",
    label: "Diff Gutter Removed Bg",
    description: "Background color for margin/gutter where lines got removed",
    category: "git",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#f871714d" : "#dc26264d"),
  },
  {
    id: "diffEditorOverview.insertedForeground",
    label: "Diff Overview Inserted",
    description: "Diff overview ruler foreground for inserted content",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#34d399b3" : "#16a34ab3"),
  },
  {
    id: "diffEditorOverview.removedForeground",
    label: "Diff Overview Removed",
    description: "Diff overview ruler foreground for removed content",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#f87171b3" : "#dc2626b3"),
  },
  {
    id: "diffEditor.insertedTextBorder",
    label: "Diff Inserted Text Border",
    description: "Outline color for text that got inserted",
    category: "git",
    deriveDefault: () => "#00000000",
  },
  {
    id: "diffEditor.removedTextBorder",
    label: "Diff Removed Text Border",
    description: "Outline color for text that got removed",
    category: "git",
    deriveDefault: () => "#00000000",
  },
  {
    id: "diffEditor.border",
    label: "Diff Split Border",
    description: "Border color between side-by-side diff panes",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "diffEditor.diagonalFill",
    label: "Diff Diagonal Fill",
    description: "Color of diff editor diagonal fill pattern",
    category: "git",
    deriveDefault: (c) => alpha(c.foreground, 0.12),
  },
  {
    id: "diffEditor.unchangedRegionBackground",
    label: "Diff Unchanged Region Bg",
    description: "Background color of unchanged folded code blocks in diff editor",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "diffEditor.unchangedRegionForeground",
    label: "Diff Unchanged Region Text",
    description: "Foreground text color of unchanged folded code blocks in diff editor",
    category: "text",
    contrastPairId: "diffEditor.unchangedRegionBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "diffEditor.unchangedCodeBackground",
    label: "Diff Unchanged Code Bg",
    description: "Background color of unchanged code in diff editor",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.04),
  },

  // ── 9. Terminal Tokens ─────────────────────────────────────────────────────
  {
    id: "terminal.ansiBlack",
    label: "Terminal ANSI Black",
    description: "ANSI black color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#1e293b" : "#e2e8f0"),
  },
  {
    id: "terminal.ansiRed",
    label: "Terminal ANSI Red",
    description: "ANSI red color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "terminal.ansiGreen",
    label: "Terminal ANSI Green",
    description: "ANSI green color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#4ade80" : "#16a34a"),
  },
  {
    id: "terminal.ansiYellow",
    label: "Terminal ANSI Yellow",
    description: "ANSI yellow color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "terminal.ansiBlue",
    label: "Terminal ANSI Blue",
    description: "ANSI blue color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#60a5fa" : "#2563eb"),
  },
  {
    id: "terminal.ansiMagenta",
    label: "Terminal ANSI Magenta",
    description: "ANSI magenta color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#c084fc" : "#9333ea"),
  },
  {
    id: "terminal.ansiCyan",
    label: "Terminal ANSI Cyan",
    description: "ANSI cyan color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#38bdf8" : "#0284c7"),
  },
  {
    id: "terminal.ansiWhite",
    label: "Terminal ANSI White",
    description: "ANSI white color in terminal",
    category: "text",
    contrastPairId: "terminal.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "terminal.ansiBrightBlack",
    label: "Terminal ANSI Bright Black",
    description: "ANSI bright black color in terminal",
    category: "git",
    deriveDefault: (c) => alpha(c.foreground, 0.5),
  },
  {
    id: "terminal.ansiBrightRed",
    label: "Terminal ANSI Bright Red",
    description: "ANSI bright red color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#ef4444" : "#b91c1c"),
  },
  {
    id: "terminal.ansiBrightGreen",
    label: "Terminal ANSI Bright Green",
    description: "ANSI bright green color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#22c55e" : "#15803d"),
  },
  {
    id: "terminal.ansiBrightYellow",
    label: "Terminal ANSI Bright Yellow",
    description: "ANSI bright yellow color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#eab308" : "#a16207"),
  },
  {
    id: "terminal.ansiBrightBlue",
    label: "Terminal ANSI Bright Blue",
    description: "ANSI bright blue color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#3b82f6" : "#1d4ed8"),
  },
  {
    id: "terminal.ansiBrightMagenta",
    label: "Terminal ANSI Bright Magenta",
    description: "ANSI bright magenta color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#a855f7" : "#7e22ce"),
  },
  {
    id: "terminal.ansiBrightCyan",
    label: "Terminal ANSI Bright Cyan",
    description: "ANSI bright cyan color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#0ea5e9" : "#0369a1"),
  },
  {
    id: "terminal.ansiBrightWhite",
    label: "Terminal ANSI Bright White",
    description: "ANSI bright white color in terminal",
    category: "text",
    contrastPairId: "terminal.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "terminal.selectionBackground",
    label: "Terminal Selection Bg",
    description: "Selection background in terminal",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.25),
  },
  {
    id: "terminal.selectionForeground",
    label: "Terminal Selection Text",
    description: "Selection text color in terminal",
    category: "text",
    contrastPairId: "terminal.selectionBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "terminal.inactiveSelectionBackground",
    label: "Terminal Inactive Selection Bg",
    description: "Inactive selection background in terminal",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.12),
  },
  {
    id: "terminal.findMatchBackground",
    label: "Terminal Find Match Bg",
    description: "Find match background color in terminal",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.3),
  },
  {
    id: "terminal.findMatchHighlightBackground",
    label: "Terminal Find Highlight Bg",
    description: "Find highlight background in terminal",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.18),
  },
  {
    id: "terminal.border",
    label: "Terminal Border",
    description: "Border color between terminal panes",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "terminalCursor.foreground",
    label: "Terminal Cursor Color",
    description: "Color of insertion cursor in terminal",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "terminalCursor.background",
    label: "Terminal Cursor Text",
    description: "Text color inside terminal block cursor",
    category: "surfaces",
    deriveDefault: (c) => c.background,
  },
  {
    id: "terminalCommandDecoration.defaultBackground",
    label: "Terminal Command Marker",
    description: "Default command marker color in terminal gutter",
    category: "git",
    deriveDefault: (c) => alpha(c.foreground, 0.25),
  },
  {
    id: "terminalCommandDecoration.errorBackground",
    label: "Terminal Command Error",
    description: "Error command marker color in terminal gutter",
    category: "git",
    deriveDefault: () => "#f87171",
  },
  {
    id: "terminalCommandDecoration.successBackground",
    label: "Terminal Command Success",
    description: "Success command marker color in terminal gutter",
    category: "git",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "terminalStickyScroll.background",
    label: "Terminal Sticky Scroll Bg",
    description: "Sticky header background in terminal",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "terminalStickyScroll.border",
    label: "Terminal Sticky Scroll Border",
    description: "Sticky header border in terminal",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "terminalStickyScrollHover.background",
    label: "Terminal Sticky Scroll Hover",
    description: "Sticky header hover background in terminal",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "terminalOverviewRuler.cursorForeground",
    label: "Terminal Overview Cursor",
    description: "Overview ruler cursor marker in terminal",
    category: "git",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "terminalOverviewRuler.findMatchForeground",
    label: "Terminal Overview Find Match",
    description: "Overview ruler find match marker in terminal",
    category: "git",
    deriveDefault: (c) => alpha(c.primary, 0.5),
  },
  {
    id: "terminalOverviewRuler.border",
    label: "Terminal Overview Border",
    description: "Overview ruler border in terminal",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "terminalCommandGuide.foreground",
    label: "Terminal Command Guide",
    description: "Command guide vertical line color in terminal",
    category: "git",
    deriveDefault: (c) => alpha(c.foreground, 0.15),
  },

  // ── 10. Chat & AI Tokens ───────────────────────────────────────────────────
  {
    id: "chat.requestBackground",
    label: "Chat Request Background",
    description: "Background of user request bubble in chat",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.03),
  },
  {
    id: "chat.requestBorder",
    label: "Chat Request Border",
    description: "Border around user request bubble in chat",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "chat.requestBubbleBackground",
    label: "Chat Request Bubble Bg",
    description: "Inner request bubble background in chat",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.05),
  },
  {
    id: "chat.requestBubbleHoverBackground",
    label: "Chat Request Bubble Hover",
    description: "Hover state for chat request bubble",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "chat.requestCodeBorder",
    label: "Chat Request Code Border",
    description: "Border around inline code inside chat request",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "chat.slashCommandBackground",
    label: "Chat Slash Command Bg",
    description: "Background of slash command tags in chat",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "chat.slashCommandForeground",
    label: "Chat Slash Command Text",
    description: "Text color of slash command tags in chat",
    category: "text",
    contrastPairId: "chat.slashCommandBackground",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "chat.avatarBackground",
    label: "Chat Avatar Background",
    description: "Background color of agent avatar in chat",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "chat.avatarForeground",
    label: "Chat Avatar Foreground",
    description: "Icon/text color inside agent avatar in chat",
    category: "text",
    contrastPairId: "chat.avatarBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "chat.linesAddedForeground",
    label: "Chat Diff Lines Added",
    description: "Color for added lines in chat code edits",
    category: "git",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#34d399" : "#16a34a"),
  },
  {
    id: "chat.linesRemovedForeground",
    label: "Chat Diff Lines Removed",
    description: "Color for removed lines in chat code edits",
    category: "git",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "chat.editedFileForeground",
    label: "Chat Edited File Text",
    description: "Color of edited file pill titles in chat",
    category: "git",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "chat.checkpointSeparator",
    label: "Chat Checkpoint Separator",
    description: "Divider line for chat state checkpoints",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "inlineChat.background",
    label: "Inline Chat Background",
    description: "Background color for floating inline chat widget",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "inlineChat.border",
    label: "Inline Chat Border",
    description: "Border around floating inline chat widget",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "inlineChat.shadow",
    label: "Inline Chat Shadow",
    description: "Shadow color cast by inline chat widget",
    category: "borders",
    deriveDefault: () => "transparent",
  },
  {
    id: "inlineChatInput.border",
    label: "Inline Chat Input Border",
    description: "Border around text input in inline chat widget",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "inlineChatDiff.inserted",
    label: "Inline Chat Inserted Bg",
    description: "Background overlay for inserted code in inline chat",
    category: "git",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#34d39926" : "#16a34a26"),
  },
  {
    id: "inlineChatDiff.removed",
    label: "Inline Chat Removed Bg",
    description: "Background overlay for removed code in inline chat",
    category: "git",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#f8717126" : "#dc262626"),
  },

  // ── 11. Debug & Testing Tokens ─────────────────────────────────────────────
  {
    id: "debugToolBar.background",
    label: "Debug Toolbar Background",
    description: "Background of floating debug control toolbar",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "debugToolBar.border",
    label: "Debug Toolbar Border",
    description: "Border around floating debug control toolbar",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "debugConsole.errorForeground",
    label: "Debug Console Error",
    description: "Text color for error logs in debug console",
    category: "text",
    contrastPairId: "panel.background",
    deriveDefault: () => "#f87171",
  },
  {
    id: "debugConsole.infoForeground",
    label: "Debug Console Info",
    description: "Text color for info messages in debug console",
    category: "text",
    contrastPairId: "panel.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugConsole.warningForeground",
    label: "Debug Console Warning",
    description: "Text color for warning logs in debug console",
    category: "text",
    contrastPairId: "panel.background",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "debugConsole.sourceForeground",
    label: "Debug Console Source Text",
    description: "Text color for source code location links in debug console",
    category: "text",
    contrastPairId: "panel.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "debugIcon.breakpointForeground",
    label: "Breakpoint Icon Color",
    description: "Color of red breakpoint dot icon",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "debugIcon.breakpointDisabledForeground",
    label: "Disabled Breakpoint Icon",
    description: "Color of disabled breakpoint icon",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.35),
  },
  {
    id: "debugIcon.breakpointUnverifiedForeground",
    label: "Unverified Breakpoint Icon",
    description: "Color of unverified breakpoint icon",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.5),
  },
  {
    id: "debugIcon.breakpointCurrentStackframeForeground",
    label: "Active Stackframe Icon",
    description: "Color of breakpoint icon on current active stack frame",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "debugIcon.breakpointStackframeForeground",
    label: "Stackframe Breakpoint Icon",
    description: "Color of stack frame breakpoint icon",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "debugIcon.startForeground",
    label: "Debug Start Icon",
    description: "Color of Debug Start action button icon",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "debugIcon.pauseForeground",
    label: "Debug Pause Icon",
    description: "Color of Debug Pause action button icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.stopForeground",
    label: "Debug Stop Icon",
    description: "Color of Debug Stop action button icon",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "debugIcon.continueForeground",
    label: "Debug Continue Icon",
    description: "Color of Debug Continue action button icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.restartForeground",
    label: "Debug Restart Icon",
    description: "Color of Debug Restart action button icon",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "debugIcon.stepOverForeground",
    label: "Debug Step Over Icon",
    description: "Color of Debug Step Over action icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.stepIntoForeground",
    label: "Debug Step Into Icon",
    description: "Color of Debug Step Into action icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.stepOutForeground",
    label: "Debug Step Out Icon",
    description: "Color of Debug Step Out action icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.stepBackForeground",
    label: "Debug Step Back Icon",
    description: "Color of Debug Step Back action icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.disconnectForeground",
    label: "Debug Disconnect Icon",
    description: "Color of Debug Disconnect action icon",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "debugTokenExpression.name",
    label: "Debug Variable Name",
    description: "Variable name text color in debug views",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugTokenExpression.value",
    label: "Debug Variable Value",
    description: "Variable value text color in debug views",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "debugTokenExpression.string",
    label: "Debug Variable String",
    description: "String literal text color in debug variable view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#ce9178" : "#a31515"),
  },
  {
    id: "debugTokenExpression.number",
    label: "Debug Variable Number",
    description: "Number literal text color in debug variable view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#b5cea8" : "#098658"),
  },
  {
    id: "debugTokenExpression.boolean",
    label: "Debug Variable Boolean",
    description: "Boolean value text color in debug variable view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#569cd6" : "#0000ff"),
  },
  {
    id: "debugTokenExpression.error",
    label: "Debug Variable Error",
    description: "Error text color in debug variable view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: () => "#f87171",
  },
  {
    id: "debugTokenExpression.type",
    label: "Debug Variable Type",
    description: "Type label text color in debug variable view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#4ec9b0" : "#267f99"),
  },
  {
    id: "debugView.exceptionLabelBackground",
    label: "Debug Exception Label Bg",
    description: "Background of exception message pill in debug call stack",
    category: "accents",
    isBg: true,
    deriveDefault: () => "#b91c1c",
  },
  {
    id: "debugView.exceptionLabelForeground",
    label: "Debug Exception Label Text",
    description: "Text color inside exception message pill",
    category: "text",
    contrastPairId: "debugView.exceptionLabelBackground",
    deriveDefault: () => "#ffffff",
  },
  {
    id: "debugView.stateLabelBackground",
    label: "Debug State Label Bg",
    description: "Background of state label in debug view",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.1),
  },
  {
    id: "debugView.stateLabelForeground",
    label: "Debug State Label Text",
    description: "Text color inside debug state label",
    category: "text",
    contrastPairId: "debugView.stateLabelBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "debugView.valueChangedHighlight",
    label: "Debug Value Changed Highlight",
    description: "Highlight color for changed variable values during debugging",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.3),
  },
  {
    id: "debugExceptionWidget.background",
    label: "Debug Exception Widget Bg",
    description: "Background of exception popup widget in code editor",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "debugExceptionWidget.border",
    label: "Debug Exception Widget Border",
    description: "Border around exception popup widget in editor",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "testing.iconFailed",
    label: "Test Failed Icon",
    description: "Icon color for failed unit tests",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "testing.iconErrored",
    label: "Test Errored Icon",
    description: "Icon color for errored unit tests",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "testing.iconPassed",
    label: "Test Passed Icon",
    description: "Icon color for passed unit tests",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "testing.iconQueued",
    label: "Test Queued Icon",
    description: "Icon color for queued unit tests",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "testing.iconUnset",
    label: "Test Unset Icon",
    description: "Icon color for unset unit tests",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.4),
  },
  {
    id: "testing.runAction",
    label: "Test Run Action Icon",
    description: "Color of play/run action icon in test explorer",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "testing.message.error.decorationForeground",
    label: "Test Error Gutter Marker",
    description: "Gutter marker text color for test error messages",
    category: "git",
    contrastPairId: "editor.background",
    deriveDefault: () => "#f87171",
  },
  {
    id: "testing.message.info.decorationForeground",
    label: "Test Info Gutter Marker",
    description: "Gutter marker text color for test info messages",
    category: "git",
    contrastPairId: "editor.background",
    deriveDefault: (c) => c.primary,
  },

  // ── 12. Notebook Tokens ───────────────────────────────────────────────────
  {
    id: "notebook.editorBackground",
    label: "Notebook Canvas Background",
    description: "Main canvas background for Jupyter notebooks",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "notebook.cellBorderColor",
    label: "Notebook Cell Border",
    description: "Border outline around notebook code cells",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "notebook.cellHoverBackground",
    label: "Notebook Cell Hover",
    description: "Hover state background for notebook cells",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.04),
  },
  {
    id: "notebook.cellInsertionIndicator",
    label: "Notebook Insert Indicator",
    description: "Indicator bar for inserting new notebook cells",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "notebook.focusedCellBorder",
    label: "Notebook Focused Cell Border",
    description: "Active focused border around notebook cell",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "notebook.focusedEditorBorder",
    label: "Notebook Focused Editor Border",
    description: "Focused border around active code editor in notebook cell",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "notebook.inactiveFocusedCellBorder",
    label: "Notebook Unfocused Cell Border",
    description: "Border around focused notebook cell when window is unfocused",
    category: "borders",
    deriveDefault: (c) => alpha(c.foreground, 0.2),
  },
  {
    id: "notebook.selectedCellBackground",
    label: "Notebook Selected Cell Bg",
    description: "Background color of multi-selected notebook cells",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.1),
  },
  {
    id: "notebook.selectedCellBorder",
    label: "Notebook Selected Cell Border",
    description: "Border outline for selected notebook cells",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "notebook.cellStatusBarItemHoverBackground",
    label: "Notebook Cell Status Hover",
    description: "Hover background of notebook cell status items",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "notebook.cellToolbarSeparator",
    label: "Notebook Toolbar Separator",
    description: "Separator line between cell action toolbar buttons",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "notebook.cellEditorBackground",
    label: "Notebook Cell Editor Bg",
    description: "Background color inside notebook cell code input",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "notebookScrollbarSlider.activeBackground",
    label: "Notebook Scrollbar Active",
    description: "Active scrollbar thumb color in notebook editor",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.3),
  },
  {
    id: "notebookScrollbarSlider.background",
    label: "Notebook Scrollbar Thumb",
    description: "Scrollbar thumb color in notebook editor",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.12),
  },
  {
    id: "notebookScrollbarSlider.hoverBackground",
    label: "Notebook Scrollbar Hover",
    description: "Scrollbar thumb hover color in notebook editor",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.2),
  },

  // ── 13. Syntax Highlights & Editor Decorators ──────────────────────────────
  {
    id: "editor.findMatchBackground",
    label: "Find Match Background",
    description: "Highlight background for current find match",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.35),
  },
  {
    id: "editor.findMatchHighlightBackground",
    label: "Find All Matches Highlight",
    description: "Highlight background for all other find matches",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "editor.findRangeHighlightBackground",
    label: "Find Range Highlight",
    description: "Highlight background for search scope range",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.06),
  },
  {
    id: "editor.hoverHighlightBackground",
    label: "Editor Hover Highlight",
    description: "Highlight background behind word when hovering",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "editor.wordHighlightBackground",
    label: "Symbol Word Highlight",
    description: "Highlight background for matching variable occurrences",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.12),
  },
  {
    id: "editor.wordHighlightStrongBackground",
    label: "Write Word Highlight",
    description: "Highlight background for write-access variable occurrences",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.22),
  },
  {
    id: "editor.rangeHighlightBackground",
    label: "Code Range Highlight",
    description: "Background highlight for target code ranges",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.05),
  },
  {
    id: "editor.symbolHighlightBackground",
    label: "Symbol Navigation Highlight",
    description: "Highlight background when jumping to symbol definition",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "editor.linkedEditingBackground",
    label: "Linked Editing Highlight",
    description: "Highlight background for synchronized tag editing",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.25),
  },
  {
    id: "editor.foldBackground",
    label: "Folded Code Highlight",
    description: "Highlight background behind folded code blocks",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.1),
  },
  {
    id: "editorGutter.background",
    label: "Editor Gutter Background",
    description: "Background of code editor line-number gutter",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "editorGutter.modifiedBackground",
    label: "Gutter Modified Marker",
    description: "Line decoration marker for modified git lines in gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "editorGutter.addedBackground",
    label: "Gutter Added Marker",
    description: "Line decoration marker for added git lines in gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#4ade80" : "#16a34a"),
  },
  {
    id: "editorGutter.deletedBackground",
    label: "Gutter Deleted Marker",
    description: "Line decoration marker for deleted git lines in gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "editorGutter.commentRangeForeground",
    label: "Gutter Comment Range Icon",
    description: "Icon color for active comment range in editor gutter",
    category: "text",
    contrastPairId: "editor.background",
    deriveDefault: (c) => alpha(c.foreground, 0.3),
  },
  {
    id: "editorBracketMatch.background",
    label: "Bracket Match Background",
    description: "Highlight background behind matching bracket pair",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.1),
  },
  {
    id: "editorBracketMatch.border",
    label: "Bracket Match Border",
    description: "Border outline around matching bracket pair",
    category: "borders",
    deriveDefault: (c) => alpha(c.foreground, 0.3),
  },
  {
    id: "editorBracketHighlight.foreground1",
    label: "Rainbow Bracket Level 1",
    description: "Color for level 1 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#ffd700" : "#0431fa"),
  },
  {
    id: "editorBracketHighlight.foreground2",
    label: "Rainbow Bracket Level 2",
    description: "Color for level 2 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#da70d6" : "#319331"),
  },
  {
    id: "editorBracketHighlight.foreground3",
    label: "Rainbow Bracket Level 3",
    description: "Color for level 3 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#179fff" : "#7b3814"),
  },
  {
    id: "editorBracketHighlight.foreground4",
    label: "Rainbow Bracket Level 4",
    description: "Color for level 4 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#ffd700" : "#0431fa"),
  },
  {
    id: "editorBracketHighlight.foreground5",
    label: "Rainbow Bracket Level 5",
    description: "Color for level 5 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#da70d6" : "#319331"),
  },
  {
    id: "editorBracketHighlight.foreground6",
    label: "Rainbow Bracket Level 6",
    description: "Color for level 6 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#179fff" : "#7b3814"),
  },
  {
    id: "editorBracketHighlight.unexpectedBracket.foreground",
    label: "Unexpected Bracket Red",
    description: "Color for mismatched/unclosed bracket errors",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: () => "#f87171",
  },
  {
    id: "editorError.foreground",
    label: "Editor Error Underline Red",
    description: "Squiggly underline color for error diagnostics in editor",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: () => "#f87171",
  },
  {
    id: "editorWarning.foreground",
    label: "Editor Warning Underline Yellow",
    description: "Squiggly underline color for warning diagnostics in editor",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "editorInfo.foreground",
    label: "Editor Info Underline Blue",
    description: "Squiggly underline color for info diagnostics in editor",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "editorHint.foreground",
    label: "Editor Hint Underline Muted",
    description: "Underline color for code hint diagnostics in editor",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (c) => alpha(c.foreground, 0.6),
  },
  {
    id: "editorMarkerNavigation.background",
    label: "Diagnostic Navigation Card",
    description: "Background of error/warning inline banner card in editor",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "editorMarkerNavigationError.background",
    label: "Diagnostic Error Header",
    description: "Header background of diagnostic navigation card on errors",
    category: "accents",
    isBg: true,
    deriveDefault: () => "#f87171",
  },
  {
    id: "editorMarkerNavigationWarning.background",
    label: "Diagnostic Warning Header",
    description: "Header background of diagnostic navigation card on warnings",
    category: "accents",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "editorMarkerNavigationInfo.background",
    label: "Diagnostic Info Header",
    description: "Header background of diagnostic navigation card on info",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => c.primary,
  },

  // ── 14. Minimap & Overview Ruler Tokens ────────────────────────────────────
  {
    id: "minimap.background",
    label: "Minimap Background",
    description: "Background canvas of code minimap",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "minimap.selectionHighlight",
    label: "Minimap Selection Highlight",
    description: "Highlight color for selected text range in minimap",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.4),
  },
  {
    id: "minimap.findMatchHighlight",
    label: "Minimap Find Match Highlight",
    description: "Highlight color for search matches in minimap",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.5),
  },
  {
    id: "minimap.selectionOccurrenceHighlight",
    label: "Minimap Symbol Highlight",
    description: "Highlight color for matching symbol occurrences in minimap",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.25),
  },
  {
    id: "minimap.errorHighlight",
    label: "Minimap Error Highlight",
    description: "Highlight color for error markers in minimap",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "minimap.warningHighlight",
    label: "Minimap Warning Highlight",
    description: "Highlight color for warning markers in minimap",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "minimapGutter.addedBackground",
    label: "Minimap Added Git Gutter",
    description: "Marker color for added lines in minimap gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#4ade80" : "#16a34a"),
  },
  {
    id: "minimapGutter.modifiedBackground",
    label: "Minimap Modified Git Gutter",
    description: "Marker color for modified lines in minimap gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "minimapGutter.deletedBackground",
    label: "Minimap Deleted Git Gutter",
    description: "Marker color for deleted lines in minimap gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "minimapSlider.background",
    label: "Minimap Viewport Slider",
    description: "Viewport slider thumb color in minimap",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.12),
  },
  {
    id: "minimapSlider.hoverBackground",
    label: "Minimap Slider Hover",
    description: "Viewport slider hover color in minimap",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.2),
  },
  {
    id: "minimapSlider.activeBackground",
    label: "Minimap Slider Drag",
    description: "Viewport slider drag color in minimap",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.3),
  },
  {
    id: "editorOverviewRuler.border",
    label: "Overview Ruler Border",
    description: "Border outline separating overview ruler from editor scrollbar",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "editorOverviewRuler.findMatchForeground",
    label: "Overview Ruler Find Match",
    description: "Overview ruler tick marker for search matches",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.6),
  },
  {
    id: "editorOverviewRuler.errorForeground",
    label: "Overview Ruler Error Marker",
    description: "Overview ruler tick marker for error diagnostics",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "editorOverviewRuler.warningForeground",
    label: "Overview Ruler Warning Marker",
    description: "Overview ruler tick marker for warning diagnostics",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "editorOverviewRuler.infoForeground",
    label: "Overview Ruler Info Marker",
    description: "Overview ruler tick marker for info diagnostics",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },

  // ── 15. Breadcrumbs & Peek View Tokens ─────────────────────────────────────
  {
    id: "breadcrumb.foreground",
    label: "Breadcrumb Item Text",
    description: "Text color of breadcrumb navigation items",
    category: "text",
    contrastPairId: "breadcrumb.background",
    deriveDefault: (c) => alpha(c.foreground, 0.7),
  },
  {
    id: "breadcrumb.background",
    label: "Breadcrumb Bar Background",
    description: "Background color of breadcrumb header strip",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "breadcrumb.focusForeground",
    label: "Breadcrumb Focused Item",
    description: "Text color of focused breadcrumb item",
    category: "text",
    contrastPairId: "breadcrumb.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "breadcrumb.activeSelectionForeground",
    label: "Breadcrumb Active Dropdown Item",
    description: "Text color of active selection in breadcrumb menu",
    category: "text",
    contrastPairId: "breadcrumb.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "breadcrumbPicker.background",
    label: "Breadcrumb Dropdown Surface",
    description: "Background color of breadcrumb dropdown popover menu",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "peekView.border",
    label: "Peek View Frame Border",
    description: "Border frame around inline Peek View (Peek Definition)",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "peekViewEditor.background",
    label: "Peek View Canvas Background",
    description: "Background color of embedded editor inside Peek View",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "peekViewEditorGutter.background",
    label: "Peek View Gutter Background",
    description: "Gutter background inside Peek View embedded editor",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "peekViewEditor.matchHighlightBackground",
    label: "Peek View Match Highlight",
    description: "Match highlight background inside Peek View editor",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.3),
  },
  {
    id: "peekViewResult.background",
    label: "Peek View Results List Bg",
    description: "Background of right-hand reference list in Peek View",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.background, 0.95),
  },
  {
    id: "peekViewResult.fileForeground",
    label: "Peek View File Header Text",
    description: "File header text color in Peek View results list",
    category: "text",
    contrastPairId: "peekViewResult.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "peekViewResult.lineForeground",
    label: "Peek View Line Content Text",
    description: "Line preview text color in Peek View results list",
    category: "text",
    contrastPairId: "peekViewResult.background",
    deriveDefault: (c) => alpha(c.foreground, 0.6),
  },
  {
    id: "peekViewResult.matchHighlightBackground",
    label: "Peek View List Search Match",
    description: "Search match highlight in Peek View results list",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.3),
  },
  {
    id: "peekViewResult.selectionBackground",
    label: "Peek View List Selected Item",
    description: "Selected item background in Peek View results list",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "peekViewResult.selectionForeground",
    label: "Peek View List Selected Text",
    description: "Selected item text color in Peek View results list",
    category: "text",
    contrastPairId: "peekViewResult.selectionBackground",
    deriveDefault: (c) => c.foreground,
  },

  // ── 16. Comments, Git, Controls & Symbol Icons ─────────────────────────────
  {
    id: "commentsView.resolvedIcon",
    label: "Resolved Comment Check Icon",
    description: "Icon color for resolved comments",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "commentsView.unresolvedIcon",
    label: "Unresolved Comment Icon",
    description: "Icon color for unresolved comment threads",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "commentThread.replyInputBackground",
    label: "Comment Thread Reply Field",
    description: "Background of reply text box in comment threads",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "editorCommentsWidget.resolvedBorder",
    label: "Resolved Comment Widget Border",
    description: "Border around resolved inline comment widget",
    category: "borders",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "editorCommentsWidget.unresolvedBorder",
    label: "Unresolved Comment Widget Border",
    description: "Border around unresolved inline comment widget",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "editorCommentsWidget.rangeBackground",
    label: "Commented Code Range Bg",
    description: "Highlight background over commented code range",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.1),
  },
  {
    id: "editorCommentsWidget.rangeActiveBackground",
    label: "Active Commented Code Range",
    description: "Active highlight background over focused comment range",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "scm.historyItemAdditionsForeground",
    label: "SCM History Insertions",
    description: "Color for added lines count in SCM history list",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#34d399" : "#16a34a"),
  },
  {
    id: "scm.historyItemDeletionsForeground",
    label: "SCM History Deletions",
    description: "Color for deleted lines count in SCM history list",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "scm.historyItemSelectedBorder",
    label: "SCM History Selected Border",
    description: "Border around selected item in SCM graph list",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "gitDecoration.stageModifiedResourceForeground",
    label: "Staged Modified File",
    description: "Tree view text color for staged modified files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "gitDecoration.stageDeletedResourceForeground",
    label: "Staged Deleted File",
    description: "Tree view text color for staged deleted files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "gitDecoration.renamedResourceForeground",
    label: "Git Renamed File",
    description: "Tree view text color for renamed files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "button.border",
    label: "Primary Button Border",
    description: "Border outline around primary buttons",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "button.secondaryBorder",
    label: "Secondary Button Border",
    description: "Border outline around secondary buttons",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "inputOption.activeBackground",
    label: "Input Regex Toggle Active Bg",
    description: "Background of active option button inside text inputs (e.g. Regex, Match Case)",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "inputOption.activeBorder",
    label: "Input Option Active Border",
    description: "Border around active option toggle in search/find inputs",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "inputOption.activeForeground",
    label: "Input Option Active Text",
    description: "Text/icon color inside active option toggle in text inputs",
    category: "text",
    contrastPairId: "inputOption.activeBackground",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "inputOption.hoverBackground",
    label: "Input Option Hover Bg",
    description: "Background of option toggle on hover in search inputs",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "inputValidation.errorBackground",
    label: "Input Error Tooltip Bg",
    description: "Background of validation error tooltip under inputs",
    category: "widgets",
    isBg: true,
    deriveDefault: () => "#b91c1c22",
  },
  {
    id: "inputValidation.errorBorder",
    label: "Input Error Tooltip Border",
    description: "Border of validation error tooltip under text inputs",
    category: "borders",
    deriveDefault: () => "#f87171",
  },
  {
    id: "inputValidation.warningBackground",
    label: "Input Warning Tooltip Bg",
    description: "Background of validation warning tooltip under inputs",
    category: "widgets",
    isBg: true,
    deriveDefault: () => "#ca8a0422",
  },
  {
    id: "inputValidation.warningBorder",
    label: "Input Warning Tooltip Border",
    description: "Border of validation warning tooltip under text inputs",
    category: "borders",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "statusBar.focusBorder",
    label: "Status Bar Focus Ring",
    description: "Border around status bar when focused via keyboard",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "statusBar.noFolderBorder",
    label: "Status Bar No-Folder Border",
    description: "Border separating status bar when no workspace folder is open",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "statusBarItem.focusBorder",
    label: "Status Item Focus Ring",
    description: "Border outline around status bar items when focused",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "statusBarItem.hoverForeground",
    label: "Status Item Hover Text",
    description: "Text color of status bar item on hover",
    category: "text",
    contrastPairId: "statusBarItem.hoverBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "statusBarItem.prominentHoverBackground",
    label: "Status Item Prominent Hover",
    description: "Background of prominent status bar item on hover",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.15),
  },
  {
    id: "statusBarItem.prominentHoverForeground",
    label: "Status Prominent Hover Text",
    description: "Text color of prominent status bar item on hover",
    category: "text",
    contrastPairId: "statusBarItem.prominentHoverBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "statusBarItem.errorBackground",
    label: "Status Item Error Background",
    description: "Background color of status bar error indicators",
    category: "accents",
    isBg: true,
    deriveDefault: () => "#b91c1c",
  },
  {
    id: "statusBarItem.errorForeground",
    label: "Status Item Error Text",
    description: "Text color inside status bar error indicators",
    category: "text",
    contrastPairId: "statusBarItem.errorBackground",
    deriveDefault: () => "#ffffff",
  },
  {
    id: "statusBarItem.warningBackground",
    label: "Status Item Warning Bg",
    description: "Background color of status bar warning indicators",
    category: "accents",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#ca8a04" : "#eab308"),
  },
  {
    id: "statusBarItem.warningForeground",
    label: "Status Item Warning Text",
    description: "Text color inside status bar warning indicators",
    category: "text",
    contrastPairId: "statusBarItem.warningBackground",
    deriveDefault: (_, isDark) => (isDark ? "#0f172a" : "#ffffff"),
  },
  {
    id: "statusBarItem.offlineBackground",
    label: "Status Item Offline Bg",
    description: "Background color of status bar indicator when offline",
    category: "accents",
    isBg: true,
    deriveDefault: () => "#6c1717",
  },
  {
    id: "statusBarItem.offlineForeground",
    label: "Status Item Offline Text",
    description: "Text color of status bar indicator when offline",
    category: "text",
    contrastPairId: "statusBarItem.offlineBackground",
    deriveDefault: () => "#ffffff",
  },
  {
    id: "activityBar.activeFocusBorder",
    label: "Activity Bar Active Focus",
    description: "Focus ring border around active activity bar item",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "activityBar.dropBorder",
    label: "Activity Bar Drop Highlight",
    description: "Border highlight when dragging views into activity bar",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "activityBarTop.background",
    label: "Activity Bar Top Background",
    description: "Background of horizontal top activity bar row",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "activityBarTop.foreground",
    label: "Activity Bar Top Active Icon",
    description: "Icon color of active item in top activity bar",
    category: "text",
    contrastPairId: "activityBarTop.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "activityBarTop.inactiveForeground",
    label: "Activity Bar Top Inactive",
    description: "Icon color of unselected item in top activity bar",
    category: "text",
    contrastPairId: "activityBarTop.background",
    deriveDefault: (c) => alpha(c.foreground, 0.5),
  },
  {
    id: "activityBarTop.activeBorder",
    label: "Activity Bar Top Active Line",
    description: "Active indicator line under item in top activity bar",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "sideBar.dropBackground",
    label: "Side Bar Drag Drop Overlay",
    description: "Background highlight when dragging views into sidebar panel",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "banner.background",
    label: "Banner Message Background",
    description: "Background of top notification banner bar",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "banner.foreground",
    label: "Banner Message Text",
    description: "Text color inside top notification banner bar",
    category: "text",
    contrastPairId: "banner.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "banner.iconForeground",
    label: "Banner Message Icon",
    description: "Icon color inside top notification banner bar",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "notificationCenterHeader.background",
    label: "Notification Center Header",
    description: "Header background of notification center drawer",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "notificationCenterHeader.foreground",
    label: "Notification Center Text",
    description: "Header text color in notification center drawer",
    category: "text",
    contrastPairId: "notificationCenterHeader.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "notificationsKeybinding.foreground",
    label: "Notification Shortcut Text",
    description: "Keyboard shortcut text color inside notification toasts",
    category: "text",
    contrastPairId: "notifications.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "keybindingLabel.background",
    label: "Keybinding Badge Background",
    description: "Background of keyboard shortcut badges across UI",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "keybindingLabel.foreground",
    label: "Keybinding Badge Text",
    description: "Text color of keyboard shortcut badges across UI",
    category: "text",
    contrastPairId: "keybindingLabel.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "keybindingLabel.border",
    label: "Keybinding Badge Border",
    description: "Border outline around keyboard shortcut badges",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "keybindingLabel.bottomBorder",
    label: "Keybinding Badge Shadow Line",
    description: "Bottom border shadow line under keyboard shortcut badges",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "settings.dropdownBackground",
    label: "Settings Dropdown Surface",
    description: "Background color of dropdown select boxes in settings view",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "settings.dropdownBorder",
    label: "Settings Dropdown Border",
    description: "Border outline around dropdown select boxes in settings view",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "settings.checkboxBackground",
    label: "Settings Checkbox Surface",
    description: "Background color of checkbox toggles in settings view",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "settings.textInputBackground",
    label: "Settings Text Input Surface",
    description: "Background color of text input boxes in settings view",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "settings.numberInputBackground",
    label: "Settings Number Input Surface",
    description: "Background color of number input boxes in settings view",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "symbolIcon.classForeground",
    label: "Symbol Class Icon",
    description: "Icon color for Class symbols in outline and auto-complete",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#ee9d28" : "#d67e00"),
  },
  {
    id: "symbolIcon.constructorForeground",
    label: "Symbol Constructor Icon",
    description: "Icon color for Constructor symbols in code views",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#b180d7" : "#652d90"),
  },
  {
    id: "symbolIcon.enumForeground",
    label: "Symbol Enum Icon",
    description: "Icon color for Enum symbols in outline view",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#ee9d28" : "#d67e00"),
  },
  {
    id: "symbolIcon.eventForeground",
    label: "Symbol Event Icon",
    description: "Icon color for Event symbols in outline view",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#ee9d28" : "#d67e00"),
  },
  {
    id: "symbolIcon.fieldForeground",
    label: "Symbol Field Icon",
    description: "Icon color for Field symbols in outline view",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#75beff" : "#006fff"),
  },
  {
    id: "symbolIcon.fileForeground",
    label: "Symbol File Icon",
    description: "Icon color for File symbols in file search and outline",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.folderForeground",
    label: "Symbol Folder Icon",
    description: "Icon color for Folder symbols in breadcrumbs and explorer",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.functionForeground",
    label: "Symbol Function Icon",
    description: "Icon color for Function symbols in outline and suggest popup",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#b180d7" : "#652d90"),
  },
  {
    id: "symbolIcon.interfaceForeground",
    label: "Symbol Interface Icon",
    description: "Icon color for Interface symbols in outline view",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#75beff" : "#006fff"),
  },
  {
    id: "symbolIcon.methodForeground",
    label: "Symbol Method Icon",
    description: "Icon color for Method symbols in outline and suggest popup",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#b180d7" : "#652d90"),
  },
  {
    id: "symbolIcon.moduleForeground",
    label: "Symbol Module Icon",
    description: "Icon color for Module symbols in outline view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.namespaceForeground",
    label: "Symbol Namespace Icon",
    description: "Icon color for Namespace symbols in outline view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.numberForeground",
    label: "Symbol Number Icon",
    description: "Icon color for Number constant symbols",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.objectForeground",
    label: "Symbol Object Icon",
    description: "Icon color for Object symbols in outline view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.propertyForeground",
    label: "Symbol Property Icon",
    description: "Icon color for Property symbols in outline and suggest popup",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#75beff" : "#006fff"),
  },
  {
    id: "symbolIcon.stringForeground",
    label: "Symbol String Icon",
    description: "Icon color for String constant symbols",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.structForeground",
    label: "Symbol Struct Icon",
    description: "Icon color for Struct symbols in outline view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.variableForeground",
    label: "Symbol Variable Icon",
    description: "Icon color for Variable symbols in outline and suggest popup",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#75beff" : "#006fff"),
  },
  {
    id: "welcomePage.background",
    label: "Welcome Page Background",
    description: "Background canvas color of welcome start page",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "welcomePage.tileBackground",
    label: "Welcome Page Tile Surface",
    description: "Background color of feature cards/tiles on welcome page",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "welcomePage.tileHoverBackground",
    label: "Welcome Page Tile Hover",
    description: "Hover state background of feature cards on welcome page",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "welcomePage.tileBorder",
    label: "Welcome Page Tile Border",
    description: "Border outline around feature cards on welcome page",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "welcomePage.progress.background",
    label: "Welcome Progress Bar Surface",
    description: "Track background of setup progress bar on welcome page",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.primary,
  },
  {
    id: "welcomePage.progress.foreground",
    label: "Welcome Progress Bar Fill",
    description: "Fill indicator color of setup progress bar on welcome page",
    category: "text",
    contrastPairId: "welcomePage.progress.background",
    deriveDefault: (c) => getOptimalPrimaryForeground(c.primary),
  },

  // ── 9. Terminal Tokens ─────────────────────────────────────────────────────
  {
    id: "terminal.ansiBlack",
    label: "Terminal ANSI Black",
    description: "ANSI black color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#1e293b" : "#e2e8f0"),
  },
  {
    id: "terminal.ansiRed",
    label: "Terminal ANSI Red",
    description: "ANSI red color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "terminal.ansiGreen",
    label: "Terminal ANSI Green",
    description: "ANSI green color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#4ade80" : "#16a34a"),
  },
  {
    id: "terminal.ansiYellow",
    label: "Terminal ANSI Yellow",
    description: "ANSI yellow color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "terminal.ansiBlue",
    label: "Terminal ANSI Blue",
    description: "ANSI blue color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#60a5fa" : "#2563eb"),
  },
  {
    id: "terminal.ansiMagenta",
    label: "Terminal ANSI Magenta",
    description: "ANSI magenta color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#c084fc" : "#9333ea"),
  },
  {
    id: "terminal.ansiCyan",
    label: "Terminal ANSI Cyan",
    description: "ANSI cyan color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#38bdf8" : "#0284c7"),
  },
  {
    id: "terminal.ansiWhite",
    label: "Terminal ANSI White",
    description: "ANSI white color in terminal",
    category: "text",
    contrastPairId: "terminal.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "terminal.ansiBrightBlack",
    label: "Terminal ANSI Bright Black",
    description: "ANSI bright black color in terminal",
    category: "git",
    deriveDefault: (c) => alpha(c.foreground, 0.5),
  },
  {
    id: "terminal.ansiBrightRed",
    label: "Terminal ANSI Bright Red",
    description: "ANSI bright red color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#ef4444" : "#b91c1c"),
  },
  {
    id: "terminal.ansiBrightGreen",
    label: "Terminal ANSI Bright Green",
    description: "ANSI bright green color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#22c55e" : "#15803d"),
  },
  {
    id: "terminal.ansiBrightYellow",
    label: "Terminal ANSI Bright Yellow",
    description: "ANSI bright yellow color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#eab308" : "#a16207"),
  },
  {
    id: "terminal.ansiBrightBlue",
    label: "Terminal ANSI Bright Blue",
    description: "ANSI bright blue color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#3b82f6" : "#1d4ed8"),
  },
  {
    id: "terminal.ansiBrightMagenta",
    label: "Terminal ANSI Bright Magenta",
    description: "ANSI bright magenta color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#a855f7" : "#7e22ce"),
  },
  {
    id: "terminal.ansiBrightCyan",
    label: "Terminal ANSI Bright Cyan",
    description: "ANSI bright cyan color in terminal",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#0ea5e9" : "#0369a1"),
  },
  {
    id: "terminal.ansiBrightWhite",
    label: "Terminal ANSI Bright White",
    description: "ANSI bright white color in terminal",
    category: "text",
    contrastPairId: "terminal.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "terminal.selectionBackground",
    label: "Terminal Selection Bg",
    description: "Selection background in terminal",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.25),
  },
  {
    id: "terminal.selectionForeground",
    label: "Terminal Selection Text",
    description: "Selection text color in terminal",
    category: "text",
    contrastPairId: "terminal.selectionBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "terminal.inactiveSelectionBackground",
    label: "Terminal Inactive Selection Bg",
    description: "Inactive selection background in terminal",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.12),
  },
  {
    id: "terminal.findMatchBackground",
    label: "Terminal Find Match Bg",
    description: "Find match background color in terminal",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.3),
  },
  {
    id: "terminal.findMatchHighlightBackground",
    label: "Terminal Find Highlight Bg",
    description: "Find highlight background in terminal",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.18),
  },
  {
    id: "terminal.border",
    label: "Terminal Border",
    description: "Border color between terminal panes",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "terminalCursor.foreground",
    label: "Terminal Cursor Color",
    description: "Color of insertion cursor in terminal",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "terminalCursor.background",
    label: "Terminal Cursor Text",
    description: "Text color inside terminal block cursor",
    category: "surfaces",
    deriveDefault: (c) => c.background,
  },
  {
    id: "terminalCommandDecoration.defaultBackground",
    label: "Terminal Command Marker",
    description: "Default command marker color in terminal gutter",
    category: "git",
    deriveDefault: (c) => alpha(c.foreground, 0.25),
  },
  {
    id: "terminalCommandDecoration.errorBackground",
    label: "Terminal Command Error",
    description: "Error command marker color in terminal gutter",
    category: "git",
    deriveDefault: () => "#f87171",
  },
  {
    id: "terminalCommandDecoration.successBackground",
    label: "Terminal Command Success",
    description: "Success command marker color in terminal gutter",
    category: "git",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "terminalStickyScroll.background",
    label: "Terminal Sticky Scroll Bg",
    description: "Sticky header background in terminal",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "terminalStickyScroll.border",
    label: "Terminal Sticky Scroll Border",
    description: "Sticky header border in terminal",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "terminalStickyScrollHover.background",
    label: "Terminal Sticky Scroll Hover",
    description: "Sticky header hover background in terminal",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "terminalOverviewRuler.cursorForeground",
    label: "Terminal Overview Cursor",
    description: "Overview ruler cursor marker in terminal",
    category: "git",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "terminalOverviewRuler.findMatchForeground",
    label: "Terminal Overview Find Match",
    description: "Overview ruler find match marker in terminal",
    category: "git",
    deriveDefault: (c) => alpha(c.primary, 0.5),
  },
  {
    id: "terminalOverviewRuler.border",
    label: "Terminal Overview Border",
    description: "Overview ruler border in terminal",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "terminalCommandGuide.foreground",
    label: "Terminal Command Guide",
    description: "Command guide vertical line color in terminal",
    category: "git",
    deriveDefault: (c) => alpha(c.foreground, 0.15),
  },

  // ── 10. Chat & AI Tokens ───────────────────────────────────────────────────
  {
    id: "chat.requestBackground",
    label: "Chat Request Background",
    description: "Background of user request bubble in chat",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.03),
  },
  {
    id: "chat.requestBorder",
    label: "Chat Request Border",
    description: "Border around user request bubble in chat",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "chat.requestBubbleBackground",
    label: "Chat Request Bubble Bg",
    description: "Inner request bubble background in chat",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.05),
  },
  {
    id: "chat.requestBubbleHoverBackground",
    label: "Chat Request Bubble Hover",
    description: "Hover state for chat request bubble",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "chat.requestCodeBorder",
    label: "Chat Request Code Border",
    description: "Border around inline code inside chat request",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "chat.slashCommandBackground",
    label: "Chat Slash Command Bg",
    description: "Background of slash command tags in chat",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "chat.slashCommandForeground",
    label: "Chat Slash Command Text",
    description: "Text color of slash command tags in chat",
    category: "text",
    contrastPairId: "chat.slashCommandBackground",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "chat.avatarBackground",
    label: "Chat Avatar Background",
    description: "Background color of agent avatar in chat",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "chat.avatarForeground",
    label: "Chat Avatar Foreground",
    description: "Icon/text color inside agent avatar in chat",
    category: "text",
    contrastPairId: "chat.avatarBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "chat.linesAddedForeground",
    label: "Chat Diff Lines Added",
    description: "Color for added lines in chat code edits",
    category: "git",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#34d399" : "#16a34a"),
  },
  {
    id: "chat.linesRemovedForeground",
    label: "Chat Diff Lines Removed",
    description: "Color for removed lines in chat code edits",
    category: "git",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "chat.editedFileForeground",
    label: "Chat Edited File Text",
    description: "Color of edited file pill titles in chat",
    category: "git",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "chat.checkpointSeparator",
    label: "Chat Checkpoint Separator",
    description: "Divider line for chat state checkpoints",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "inlineChat.background",
    label: "Inline Chat Background",
    description: "Background color for floating inline chat widget",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "inlineChat.border",
    label: "Inline Chat Border",
    description: "Border around floating inline chat widget",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "inlineChat.shadow",
    label: "Inline Chat Shadow",
    description: "Shadow color cast by inline chat widget",
    category: "borders",
    deriveDefault: () => "transparent",
  },
  {
    id: "inlineChatInput.border",
    label: "Inline Chat Input Border",
    description: "Border around text input in inline chat widget",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "inlineChatDiff.inserted",
    label: "Inline Chat Inserted Bg",
    description: "Background overlay for inserted code in inline chat",
    category: "git",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#34d39926" : "#16a34a26"),
  },
  {
    id: "inlineChatDiff.removed",
    label: "Inline Chat Removed Bg",
    description: "Background overlay for removed code in inline chat",
    category: "git",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#f8717126" : "#dc262626"),
  },

  // ── 11. Debug & Testing Tokens ─────────────────────────────────────────────
  {
    id: "debugToolBar.background",
    label: "Debug Toolbar Background",
    description: "Background of floating debug control toolbar",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "debugToolBar.border",
    label: "Debug Toolbar Border",
    description: "Border around floating debug control toolbar",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "debugConsole.errorForeground",
    label: "Debug Console Error",
    description: "Text color for error logs in debug console",
    category: "text",
    contrastPairId: "panel.background",
    deriveDefault: () => "#f87171",
  },
  {
    id: "debugConsole.infoForeground",
    label: "Debug Console Info",
    description: "Text color for info messages in debug console",
    category: "text",
    contrastPairId: "panel.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugConsole.warningForeground",
    label: "Debug Console Warning",
    description: "Text color for warning logs in debug console",
    category: "text",
    contrastPairId: "panel.background",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "debugConsole.sourceForeground",
    label: "Debug Console Source Text",
    description: "Text color for source code location links in debug console",
    category: "text",
    contrastPairId: "panel.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "debugIcon.breakpointForeground",
    label: "Breakpoint Icon Color",
    description: "Color of red breakpoint dot icon",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "debugIcon.breakpointDisabledForeground",
    label: "Disabled Breakpoint Icon",
    description: "Color of disabled breakpoint icon",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.35),
  },
  {
    id: "debugIcon.breakpointUnverifiedForeground",
    label: "Unverified Breakpoint Icon",
    description: "Color of unverified breakpoint icon",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.5),
  },
  {
    id: "debugIcon.breakpointCurrentStackframeForeground",
    label: "Active Stackframe Icon",
    description: "Color of breakpoint icon on current active stack frame",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "debugIcon.breakpointStackframeForeground",
    label: "Stackframe Breakpoint Icon",
    description: "Color of stack frame breakpoint icon",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "debugIcon.startForeground",
    label: "Debug Start Icon",
    description: "Color of Debug Start action button icon",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "debugIcon.pauseForeground",
    label: "Debug Pause Icon",
    description: "Color of Debug Pause action button icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.stopForeground",
    label: "Debug Stop Icon",
    description: "Color of Debug Stop action button icon",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "debugIcon.continueForeground",
    label: "Debug Continue Icon",
    description: "Color of Debug Continue action button icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.restartForeground",
    label: "Debug Restart Icon",
    description: "Color of Debug Restart action button icon",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "debugIcon.stepOverForeground",
    label: "Debug Step Over Icon",
    description: "Color of Debug Step Over action icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.stepIntoForeground",
    label: "Debug Step Into Icon",
    description: "Color of Debug Step Into action icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.stepOutForeground",
    label: "Debug Step Out Icon",
    description: "Color of Debug Step Out action icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.stepBackForeground",
    label: "Debug Step Back Icon",
    description: "Color of Debug Step Back action icon",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugIcon.disconnectForeground",
    label: "Debug Disconnect Icon",
    description: "Color of Debug Disconnect action icon",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "debugTokenExpression.name",
    label: "Debug Variable Name",
    description: "Variable name text color in debug views",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "debugTokenExpression.value",
    label: "Debug Variable Value",
    description: "Variable value text color in debug views",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "debugTokenExpression.string",
    label: "Debug Variable String",
    description: "String literal text color in debug variable view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#ce9178" : "#a31515"),
  },
  {
    id: "debugTokenExpression.number",
    label: "Debug Variable Number",
    description: "Number literal text color in debug variable view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#b5cea8" : "#098658"),
  },
  {
    id: "debugTokenExpression.boolean",
    label: "Debug Variable Boolean",
    description: "Boolean value text color in debug variable view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#569cd6" : "#0000ff"),
  },
  {
    id: "debugTokenExpression.error",
    label: "Debug Variable Error",
    description: "Error text color in debug variable view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: () => "#f87171",
  },
  {
    id: "debugTokenExpression.type",
    label: "Debug Variable Type",
    description: "Type label text color in debug variable view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#4ec9b0" : "#267f99"),
  },
  {
    id: "debugView.exceptionLabelBackground",
    label: "Debug Exception Label Bg",
    description: "Background of exception message pill in debug call stack",
    category: "accents",
    isBg: true,
    deriveDefault: () => "#b91c1c",
  },
  {
    id: "debugView.exceptionLabelForeground",
    label: "Debug Exception Label Text",
    description: "Text color inside exception message pill",
    category: "text",
    contrastPairId: "debugView.exceptionLabelBackground",
    deriveDefault: () => "#ffffff",
  },
  {
    id: "debugView.stateLabelBackground",
    label: "Debug State Label Bg",
    description: "Background of state label in debug view",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.1),
  },
  {
    id: "debugView.stateLabelForeground",
    label: "Debug State Label Text",
    description: "Text color inside debug state label",
    category: "text",
    contrastPairId: "debugView.stateLabelBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "debugView.valueChangedHighlight",
    label: "Debug Value Changed Highlight",
    description: "Highlight color for changed variable values during debugging",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.3),
  },
  {
    id: "debugExceptionWidget.background",
    label: "Debug Exception Widget Bg",
    description: "Background of exception popup widget in code editor",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "debugExceptionWidget.border",
    label: "Debug Exception Widget Border",
    description: "Border around exception popup widget in editor",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "testing.iconFailed",
    label: "Test Failed Icon",
    description: "Icon color for failed unit tests",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "testing.iconErrored",
    label: "Test Errored Icon",
    description: "Icon color for errored unit tests",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "testing.iconPassed",
    label: "Test Passed Icon",
    description: "Icon color for passed unit tests",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "testing.iconQueued",
    label: "Test Queued Icon",
    description: "Icon color for queued unit tests",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "testing.iconUnset",
    label: "Test Unset Icon",
    description: "Icon color for unset unit tests",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.4),
  },
  {
    id: "testing.runAction",
    label: "Test Run Action Icon",
    description: "Color of play/run action icon in test explorer",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "testing.message.error.decorationForeground",
    label: "Test Error Gutter Marker",
    description: "Gutter marker text color for test error messages",
    category: "git",
    contrastPairId: "editor.background",
    deriveDefault: () => "#f87171",
  },
  {
    id: "testing.message.info.decorationForeground",
    label: "Test Info Gutter Marker",
    description: "Gutter marker text color for test info messages",
    category: "git",
    contrastPairId: "editor.background",
    deriveDefault: (c) => c.primary,
  },

  // ── 12. Notebook Tokens ───────────────────────────────────────────────────
  {
    id: "notebook.editorBackground",
    label: "Notebook Canvas Background",
    description: "Main canvas background for Jupyter notebooks",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "notebook.cellBorderColor",
    label: "Notebook Cell Border",
    description: "Border outline around notebook code cells",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "notebook.cellHoverBackground",
    label: "Notebook Cell Hover",
    description: "Hover state background for notebook cells",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.04),
  },
  {
    id: "notebook.cellInsertionIndicator",
    label: "Notebook Insert Indicator",
    description: "Indicator bar for inserting new notebook cells",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "notebook.focusedCellBorder",
    label: "Notebook Focused Cell Border",
    description: "Active focused border around notebook cell",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "notebook.focusedEditorBorder",
    label: "Notebook Focused Editor Border",
    description: "Focused border around active code editor in notebook cell",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "notebook.inactiveFocusedCellBorder",
    label: "Notebook Unfocused Cell Border",
    description: "Border around focused notebook cell when window is unfocused",
    category: "borders",
    deriveDefault: (c) => alpha(c.foreground, 0.2),
  },
  {
    id: "notebook.selectedCellBackground",
    label: "Notebook Selected Cell Bg",
    description: "Background color of multi-selected notebook cells",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.1),
  },
  {
    id: "notebook.selectedCellBorder",
    label: "Notebook Selected Cell Border",
    description: "Border outline for selected notebook cells",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "notebook.cellStatusBarItemHoverBackground",
    label: "Notebook Cell Status Hover",
    description: "Hover background of notebook cell status items",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "notebook.cellToolbarSeparator",
    label: "Notebook Toolbar Separator",
    description: "Separator line between cell action toolbar buttons",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "notebook.cellEditorBackground",
    label: "Notebook Cell Editor Bg",
    description: "Background color inside notebook cell code input",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "notebookScrollbarSlider.activeBackground",
    label: "Notebook Scrollbar Active",
    description: "Active scrollbar thumb color in notebook editor",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.3),
  },
  {
    id: "notebookScrollbarSlider.background",
    label: "Notebook Scrollbar Thumb",
    description: "Scrollbar thumb color in notebook editor",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.12),
  },
  {
    id: "notebookScrollbarSlider.hoverBackground",
    label: "Notebook Scrollbar Hover",
    description: "Scrollbar thumb hover color in notebook editor",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.2),
  },

  // ── 13. Syntax Highlights & Editor Decorators ──────────────────────────────
  {
    id: "editor.findMatchBackground",
    label: "Find Match Background",
    description: "Highlight background for current find match",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.35),
  },
  {
    id: "editor.findMatchHighlightBackground",
    label: "Find All Matches Highlight",
    description: "Highlight background for all other find matches",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "editor.findRangeHighlightBackground",
    label: "Find Range Highlight",
    description: "Highlight background for search scope range",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.06),
  },
  {
    id: "editor.hoverHighlightBackground",
    label: "Editor Hover Highlight",
    description: "Highlight background behind word when hovering",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "editor.wordHighlightBackground",
    label: "Symbol Word Highlight",
    description: "Highlight background for matching variable occurrences",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.12),
  },
  {
    id: "editor.wordHighlightStrongBackground",
    label: "Write Word Highlight",
    description: "Highlight background for write-access variable occurrences",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.22),
  },
  {
    id: "editor.rangeHighlightBackground",
    label: "Code Range Highlight",
    description: "Background highlight for target code ranges",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.05),
  },
  {
    id: "editor.symbolHighlightBackground",
    label: "Symbol Navigation Highlight",
    description: "Highlight background when jumping to symbol definition",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "editor.linkedEditingBackground",
    label: "Linked Editing Highlight",
    description: "Highlight background for synchronized tag editing",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.25),
  },
  {
    id: "editor.foldBackground",
    label: "Folded Code Highlight",
    description: "Highlight background behind folded code blocks",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.1),
  },
  {
    id: "editorGutter.background",
    label: "Editor Gutter Background",
    description: "Background of code editor line-number gutter",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "editorGutter.modifiedBackground",
    label: "Gutter Modified Marker",
    description: "Line decoration marker for modified git lines in gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "editorGutter.addedBackground",
    label: "Gutter Added Marker",
    description: "Line decoration marker for added git lines in gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#4ade80" : "#16a34a"),
  },
  {
    id: "editorGutter.deletedBackground",
    label: "Gutter Deleted Marker",
    description: "Line decoration marker for deleted git lines in gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "editorGutter.commentRangeForeground",
    label: "Gutter Comment Range Icon",
    description: "Icon color for active comment range in editor gutter",
    category: "text",
    contrastPairId: "editor.background",
    deriveDefault: (c) => alpha(c.foreground, 0.3),
  },
  {
    id: "editorBracketMatch.background",
    label: "Bracket Match Background",
    description: "Highlight background behind matching bracket pair",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.1),
  },
  {
    id: "editorBracketMatch.border",
    label: "Bracket Match Border",
    description: "Border outline around matching bracket pair",
    category: "borders",
    deriveDefault: (c) => alpha(c.foreground, 0.3),
  },
  {
    id: "editorBracketHighlight.foreground1",
    label: "Rainbow Bracket Level 1",
    description: "Color for level 1 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#ffd700" : "#0431fa"),
  },
  {
    id: "editorBracketHighlight.foreground2",
    label: "Rainbow Bracket Level 2",
    description: "Color for level 2 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#da70d6" : "#319331"),
  },
  {
    id: "editorBracketHighlight.foreground3",
    label: "Rainbow Bracket Level 3",
    description: "Color for level 3 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#179fff" : "#7b3814"),
  },
  {
    id: "editorBracketHighlight.foreground4",
    label: "Rainbow Bracket Level 4",
    description: "Color for level 4 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#ffd700" : "#0431fa"),
  },
  {
    id: "editorBracketHighlight.foreground5",
    label: "Rainbow Bracket Level 5",
    description: "Color for level 5 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#da70d6" : "#319331"),
  },
  {
    id: "editorBracketHighlight.foreground6",
    label: "Rainbow Bracket Level 6",
    description: "Color for level 6 matched brackets",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#179fff" : "#7b3814"),
  },
  {
    id: "editorBracketHighlight.unexpectedBracket.foreground",
    label: "Unexpected Bracket Red",
    description: "Color for mismatched/unclosed bracket errors",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: () => "#f87171",
  },
  {
    id: "editorError.foreground",
    label: "Editor Error Underline Red",
    description: "Squiggly underline color for error diagnostics in editor",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: () => "#f87171",
  },
  {
    id: "editorWarning.foreground",
    label: "Editor Warning Underline Yellow",
    description: "Squiggly underline color for warning diagnostics in editor",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "editorInfo.foreground",
    label: "Editor Info Underline Blue",
    description: "Squiggly underline color for info diagnostics in editor",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "editorHint.foreground",
    label: "Editor Hint Underline Muted",
    description: "Underline color for code hint diagnostics in editor",
    category: "accents",
    contrastPairId: "editor.background",
    deriveDefault: (c) => alpha(c.foreground, 0.6),
  },
  {
    id: "editorMarkerNavigation.background",
    label: "Diagnostic Navigation Card",
    description: "Background of error/warning inline banner card in editor",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "editorMarkerNavigationError.background",
    label: "Diagnostic Error Header",
    description: "Header background of diagnostic navigation card on errors",
    category: "accents",
    isBg: true,
    deriveDefault: () => "#f87171",
  },
  {
    id: "editorMarkerNavigationWarning.background",
    label: "Diagnostic Warning Header",
    description: "Header background of diagnostic navigation card on warnings",
    category: "accents",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "editorMarkerNavigationInfo.background",
    label: "Diagnostic Info Header",
    description: "Header background of diagnostic navigation card on info",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => c.primary,
  },

  // ── 14. Minimap & Overview Ruler Tokens ────────────────────────────────────
  {
    id: "minimap.background",
    label: "Minimap Background",
    description: "Background canvas of code minimap",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "minimap.selectionHighlight",
    label: "Minimap Selection Highlight",
    description: "Highlight color for selected text range in minimap",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.4),
  },
  {
    id: "minimap.findMatchHighlight",
    label: "Minimap Find Match Highlight",
    description: "Highlight color for search matches in minimap",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.5),
  },
  {
    id: "minimap.selectionOccurrenceHighlight",
    label: "Minimap Symbol Highlight",
    description: "Highlight color for matching symbol occurrences in minimap",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.25),
  },
  {
    id: "minimap.errorHighlight",
    label: "Minimap Error Highlight",
    description: "Highlight color for error markers in minimap",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "minimap.warningHighlight",
    label: "Minimap Warning Highlight",
    description: "Highlight color for warning markers in minimap",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "minimapGutter.addedBackground",
    label: "Minimap Added Git Gutter",
    description: "Marker color for added lines in minimap gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#4ade80" : "#16a34a"),
  },
  {
    id: "minimapGutter.modifiedBackground",
    label: "Minimap Modified Git Gutter",
    description: "Marker color for modified lines in minimap gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "minimapGutter.deletedBackground",
    label: "Minimap Deleted Git Gutter",
    description: "Marker color for deleted lines in minimap gutter",
    category: "git",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "minimapSlider.background",
    label: "Minimap Viewport Slider",
    description: "Viewport slider thumb color in minimap",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.12),
  },
  {
    id: "minimapSlider.hoverBackground",
    label: "Minimap Slider Hover",
    description: "Viewport slider hover color in minimap",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.2),
  },
  {
    id: "minimapSlider.activeBackground",
    label: "Minimap Slider Drag",
    description: "Viewport slider drag color in minimap",
    category: "editor",
    deriveDefault: (c) => alpha(c.foreground, 0.3),
  },
  {
    id: "editorOverviewRuler.border",
    label: "Overview Ruler Border",
    description: "Border outline separating overview ruler from editor scrollbar",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "editorOverviewRuler.findMatchForeground",
    label: "Overview Ruler Find Match",
    description: "Overview ruler tick marker for search matches",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.6),
  },
  {
    id: "editorOverviewRuler.errorForeground",
    label: "Overview Ruler Error Marker",
    description: "Overview ruler tick marker for error diagnostics",
    category: "accents",
    deriveDefault: () => "#f87171",
  },
  {
    id: "editorOverviewRuler.warningForeground",
    label: "Overview Ruler Warning Marker",
    description: "Overview ruler tick marker for warning diagnostics",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "editorOverviewRuler.infoForeground",
    label: "Overview Ruler Info Marker",
    description: "Overview ruler tick marker for info diagnostics",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },

  // ── 15. Breadcrumbs & Peek View Tokens ─────────────────────────────────────
  {
    id: "breadcrumb.foreground",
    label: "Breadcrumb Item Text",
    description: "Text color of breadcrumb navigation items",
    category: "text",
    contrastPairId: "breadcrumb.background",
    deriveDefault: (c) => alpha(c.foreground, 0.7),
  },
  {
    id: "breadcrumb.background",
    label: "Breadcrumb Bar Background",
    description: "Background color of breadcrumb header strip",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "breadcrumb.focusForeground",
    label: "Breadcrumb Focused Item",
    description: "Text color of focused breadcrumb item",
    category: "text",
    contrastPairId: "breadcrumb.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "breadcrumb.activeSelectionForeground",
    label: "Breadcrumb Active Dropdown Item",
    description: "Text color of active selection in breadcrumb menu",
    category: "text",
    contrastPairId: "breadcrumb.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "breadcrumbPicker.background",
    label: "Breadcrumb Dropdown Surface",
    description: "Background color of breadcrumb dropdown popover menu",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "peekView.border",
    label: "Peek View Frame Border",
    description: "Border frame around inline Peek View (Peek Definition)",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "peekViewEditor.background",
    label: "Peek View Canvas Background",
    description: "Background color of embedded editor inside Peek View",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "peekViewEditorGutter.background",
    label: "Peek View Gutter Background",
    description: "Gutter background inside Peek View embedded editor",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "peekViewEditor.matchHighlightBackground",
    label: "Peek View Match Highlight",
    description: "Match highlight background inside Peek View editor",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.3),
  },
  {
    id: "peekViewResult.background",
    label: "Peek View Results List Bg",
    description: "Background of right-hand reference list in Peek View",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.background, 0.95),
  },
  {
    id: "peekViewResult.fileForeground",
    label: "Peek View File Header Text",
    description: "File header text color in Peek View results list",
    category: "text",
    contrastPairId: "peekViewResult.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "peekViewResult.lineForeground",
    label: "Peek View Line Content Text",
    description: "Line preview text color in Peek View results list",
    category: "text",
    contrastPairId: "peekViewResult.background",
    deriveDefault: (c) => alpha(c.foreground, 0.6),
  },
  {
    id: "peekViewResult.matchHighlightBackground",
    label: "Peek View List Search Match",
    description: "Search match highlight in Peek View results list",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.3),
  },
  {
    id: "peekViewResult.selectionBackground",
    label: "Peek View List Selected Item",
    description: "Selected item background in Peek View results list",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "peekViewResult.selectionForeground",
    label: "Peek View List Selected Text",
    description: "Selected item text color in Peek View results list",
    category: "text",
    contrastPairId: "peekViewResult.selectionBackground",
    deriveDefault: (c) => c.foreground,
  },

  // ── 16. Comments, Git, Controls & Symbol Icons ─────────────────────────────
  {
    id: "commentsView.resolvedIcon",
    label: "Resolved Comment Check Icon",
    description: "Icon color for resolved comments",
    category: "accents",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "commentsView.unresolvedIcon",
    label: "Unresolved Comment Icon",
    description: "Icon color for unresolved comment threads",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "commentThread.replyInputBackground",
    label: "Comment Thread Reply Field",
    description: "Background of reply text box in comment threads",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "editorCommentsWidget.resolvedBorder",
    label: "Resolved Comment Widget Border",
    description: "Border around resolved inline comment widget",
    category: "borders",
    deriveDefault: () => "#4ade80",
  },
  {
    id: "editorCommentsWidget.unresolvedBorder",
    label: "Unresolved Comment Widget Border",
    description: "Border around unresolved inline comment widget",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "editorCommentsWidget.rangeBackground",
    label: "Commented Code Range Bg",
    description: "Highlight background over commented code range",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.1),
  },
  {
    id: "editorCommentsWidget.rangeActiveBackground",
    label: "Active Commented Code Range",
    description: "Active highlight background over focused comment range",
    category: "accents",
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "scm.historyItemAdditionsForeground",
    label: "SCM History Insertions",
    description: "Color for added lines count in SCM history list",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#34d399" : "#16a34a"),
  },
  {
    id: "scm.historyItemDeletionsForeground",
    label: "SCM History Deletions",
    description: "Color for deleted lines count in SCM history list",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "scm.historyItemSelectedBorder",
    label: "SCM History Selected Border",
    description: "Border around selected item in SCM graph list",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "gitDecoration.stageModifiedResourceForeground",
    label: "Staged Modified File",
    description: "Tree view text color for staged modified files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "gitDecoration.stageDeletedResourceForeground",
    label: "Staged Deleted File",
    description: "Tree view text color for staged deleted files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (_, isDark) => (isDark ? "#f87171" : "#dc2626"),
  },
  {
    id: "gitDecoration.renamedResourceForeground",
    label: "Git Renamed File",
    description: "Tree view text color for renamed files",
    category: "git",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "button.border",
    label: "Primary Button Border",
    description: "Border outline around primary buttons",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "button.secondaryBorder",
    label: "Secondary Button Border",
    description: "Border outline around secondary buttons",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "inputOption.activeBackground",
    label: "Input Regex Toggle Active Bg",
    description: "Background of active option button inside text inputs (e.g. Regex, Match Case)",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.2),
  },
  {
    id: "inputOption.activeBorder",
    label: "Input Option Active Border",
    description: "Border around active option toggle in search/find inputs",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "inputOption.activeForeground",
    label: "Input Option Active Text",
    description: "Text/icon color inside active option toggle in text inputs",
    category: "text",
    contrastPairId: "inputOption.activeBackground",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "inputOption.hoverBackground",
    label: "Input Option Hover Bg",
    description: "Background of option toggle on hover in search inputs",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "inputValidation.errorBackground",
    label: "Input Error Tooltip Bg",
    description: "Background of validation error tooltip under inputs",
    category: "widgets",
    isBg: true,
    deriveDefault: () => "#b91c1c22",
  },
  {
    id: "inputValidation.errorBorder",
    label: "Input Error Tooltip Border",
    description: "Border of validation error tooltip under text inputs",
    category: "borders",
    deriveDefault: () => "#f87171",
  },
  {
    id: "inputValidation.warningBackground",
    label: "Input Warning Tooltip Bg",
    description: "Background of validation warning tooltip under inputs",
    category: "widgets",
    isBg: true,
    deriveDefault: () => "#ca8a0422",
  },
  {
    id: "inputValidation.warningBorder",
    label: "Input Warning Tooltip Border",
    description: "Border of validation warning tooltip under text inputs",
    category: "borders",
    deriveDefault: (_, isDark) => (isDark ? "#facc15" : "#ca8a04"),
  },
  {
    id: "statusBar.focusBorder",
    label: "Status Bar Focus Ring",
    description: "Border around status bar when focused via keyboard",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "statusBar.noFolderBorder",
    label: "Status Bar No-Folder Border",
    description: "Border separating status bar when no workspace folder is open",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "statusBarItem.focusBorder",
    label: "Status Item Focus Ring",
    description: "Border outline around status bar items when focused",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "statusBarItem.hoverForeground",
    label: "Status Item Hover Text",
    description: "Text color of status bar item on hover",
    category: "text",
    contrastPairId: "statusBarItem.hoverBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "statusBarItem.prominentHoverBackground",
    label: "Status Item Prominent Hover",
    description: "Background of prominent status bar item on hover",
    category: "accents",
    deriveDefault: (c) => alpha(c.foreground, 0.15),
  },
  {
    id: "statusBarItem.prominentHoverForeground",
    label: "Status Prominent Hover Text",
    description: "Text color of prominent status bar item on hover",
    category: "text",
    contrastPairId: "statusBarItem.prominentHoverBackground",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "statusBarItem.errorBackground",
    label: "Status Item Error Background",
    description: "Background color of status bar error indicators",
    category: "accents",
    isBg: true,
    deriveDefault: () => "#b91c1c",
  },
  {
    id: "statusBarItem.errorForeground",
    label: "Status Item Error Text",
    description: "Text color inside status bar error indicators",
    category: "text",
    contrastPairId: "statusBarItem.errorBackground",
    deriveDefault: () => "#ffffff",
  },
  {
    id: "statusBarItem.warningBackground",
    label: "Status Item Warning Bg",
    description: "Background color of status bar warning indicators",
    category: "accents",
    isBg: true,
    deriveDefault: (_, isDark) => (isDark ? "#ca8a04" : "#eab308"),
  },
  {
    id: "statusBarItem.warningForeground",
    label: "Status Item Warning Text",
    description: "Text color inside status bar warning indicators",
    category: "text",
    contrastPairId: "statusBarItem.warningBackground",
    deriveDefault: () => "#ffffff",
  },
  {
    id: "statusBarItem.offlineBackground",
    label: "Status Item Offline Bg",
    description: "Background color of status bar indicator when offline",
    category: "accents",
    isBg: true,
    deriveDefault: () => "#6c1717",
  },
  {
    id: "statusBarItem.offlineForeground",
    label: "Status Item Offline Text",
    description: "Text color of status bar indicator when offline",
    category: "text",
    contrastPairId: "statusBarItem.offlineBackground",
    deriveDefault: () => "#ffffff",
  },
  {
    id: "activityBar.activeFocusBorder",
    label: "Activity Bar Active Focus",
    description: "Focus ring border around active activity bar item",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "activityBar.dropBorder",
    label: "Activity Bar Drop Highlight",
    description: "Border highlight when dragging views into activity bar",
    category: "borders",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "activityBarTop.background",
    label: "Activity Bar Top Background",
    description: "Background of horizontal top activity bar row",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "activityBarTop.foreground",
    label: "Activity Bar Top Active Icon",
    description: "Icon color of active item in top activity bar",
    category: "text",
    contrastPairId: "activityBarTop.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "activityBarTop.inactiveForeground",
    label: "Activity Bar Top Inactive",
    description: "Icon color of unselected item in top activity bar",
    category: "text",
    contrastPairId: "activityBarTop.background",
    deriveDefault: (c) => alpha(c.foreground, 0.5),
  },
  {
    id: "activityBarTop.activeBorder",
    label: "Activity Bar Top Active Line",
    description: "Active indicator line under item in top activity bar",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "sideBar.dropBackground",
    label: "Side Bar Drag Drop Overlay",
    description: "Background highlight when dragging views into sidebar panel",
    category: "accents",
    isBg: true,
    deriveDefault: (c) => alpha(c.primary, 0.15),
  },
  {
    id: "banner.background",
    label: "Banner Message Background",
    description: "Background of top notification banner bar",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "banner.foreground",
    label: "Banner Message Text",
    description: "Text color inside top notification banner bar",
    category: "text",
    contrastPairId: "banner.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "banner.iconForeground",
    label: "Banner Message Icon",
    description: "Icon color inside top notification banner bar",
    category: "accents",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "notificationCenterHeader.background",
    label: "Notification Center Header",
    description: "Header background of notification center drawer",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "notificationCenterHeader.foreground",
    label: "Notification Center Text",
    description: "Header text color in notification center drawer",
    category: "text",
    contrastPairId: "notificationCenterHeader.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "notificationsKeybinding.foreground",
    label: "Notification Shortcut Text",
    description: "Keyboard shortcut text color inside notification toasts",
    category: "text",
    contrastPairId: "notifications.background",
    deriveDefault: (c) => c.primary,
  },
  {
    id: "keybindingLabel.background",
    label: "Keybinding Badge Background",
    description: "Background of keyboard shortcut badges across UI",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "keybindingLabel.foreground",
    label: "Keybinding Badge Text",
    description: "Text color of keyboard shortcut badges across UI",
    category: "text",
    contrastPairId: "keybindingLabel.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "keybindingLabel.border",
    label: "Keybinding Badge Border",
    description: "Border outline around keyboard shortcut badges",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "keybindingLabel.bottomBorder",
    label: "Keybinding Badge Shadow Line",
    description: "Bottom border shadow line under keyboard shortcut badges",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "settings.dropdownBackground",
    label: "Settings Dropdown Surface",
    description: "Background color of dropdown select boxes in settings view",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "settings.dropdownBorder",
    label: "Settings Dropdown Border",
    description: "Border outline around dropdown select boxes in settings view",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "settings.checkboxBackground",
    label: "Settings Checkbox Surface",
    description: "Background color of checkbox toggles in settings view",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "settings.textInputBackground",
    label: "Settings Text Input Surface",
    description: "Background color of text input boxes in settings view",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "settings.numberInputBackground",
    label: "Settings Number Input Surface",
    description: "Background color of number input boxes in settings view",
    category: "widgets",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "symbolIcon.classForeground",
    label: "Symbol Class Icon",
    description: "Icon color for Class symbols in outline and auto-complete",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#ee9d28" : "#d67e00"),
  },
  {
    id: "symbolIcon.constructorForeground",
    label: "Symbol Constructor Icon",
    description: "Icon color for Constructor symbols in code views",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#b180d7" : "#652d90"),
  },
  {
    id: "symbolIcon.enumForeground",
    label: "Symbol Enum Icon",
    description: "Icon color for Enum symbols in outline view",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#ee9d28" : "#d67e00"),
  },
  {
    id: "symbolIcon.eventForeground",
    label: "Symbol Event Icon",
    description: "Icon color for Event symbols in outline view",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#ee9d28" : "#d67e00"),
  },
  {
    id: "symbolIcon.fieldForeground",
    label: "Symbol Field Icon",
    description: "Icon color for Field symbols in outline view",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#75beff" : "#006fff"),
  },
  {
    id: "symbolIcon.fileForeground",
    label: "Symbol File Icon",
    description: "Icon color for File symbols in file search and outline",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.folderForeground",
    label: "Symbol Folder Icon",
    description: "Icon color for Folder symbols in breadcrumbs and explorer",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.functionForeground",
    label: "Symbol Function Icon",
    description: "Icon color for Function symbols in outline and suggest popup",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#b180d7" : "#652d90"),
  },
  {
    id: "symbolIcon.interfaceForeground",
    label: "Symbol Interface Icon",
    description: "Icon color for Interface symbols in outline view",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#75beff" : "#006fff"),
  },
  {
    id: "symbolIcon.methodForeground",
    label: "Symbol Method Icon",
    description: "Icon color for Method symbols in outline and suggest popup",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#b180d7" : "#652d90"),
  },
  {
    id: "symbolIcon.moduleForeground",
    label: "Symbol Module Icon",
    description: "Icon color for Module symbols in outline view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.namespaceForeground",
    label: "Symbol Namespace Icon",
    description: "Icon color for Namespace symbols in outline view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.numberForeground",
    label: "Symbol Number Icon",
    description: "Icon color for Number constant symbols",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.objectForeground",
    label: "Symbol Object Icon",
    description: "Icon color for Object symbols in outline view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.propertyForeground",
    label: "Symbol Property Icon",
    description: "Icon color for Property symbols in outline and suggest popup",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#75beff" : "#006fff"),
  },
  {
    id: "symbolIcon.stringForeground",
    label: "Symbol String Icon",
    description: "Icon color for String constant symbols",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.structForeground",
    label: "Symbol Struct Icon",
    description: "Icon color for Struct symbols in outline view",
    category: "text",
    contrastPairId: "sideBar.background",
    deriveDefault: (c) => c.foreground,
  },
  {
    id: "symbolIcon.variableForeground",
    label: "Symbol Variable Icon",
    description: "Icon color for Variable symbols in outline and suggest popup",
    category: "accents",
    deriveDefault: (_, isDark) => (isDark ? "#75beff" : "#006fff"),
  },
  {
    id: "welcomePage.background",
    label: "Welcome Page Background",
    description: "Background canvas color of welcome start page",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.background,
  },
  {
    id: "welcomePage.tileBackground",
    label: "Welcome Page Tile Surface",
    description: "Background color of feature cards/tiles on welcome page",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.card,
  },
  {
    id: "welcomePage.tileHoverBackground",
    label: "Welcome Page Tile Hover",
    description: "Hover state background of feature cards on welcome page",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => alpha(c.foreground, 0.08),
  },
  {
    id: "welcomePage.tileBorder",
    label: "Welcome Page Tile Border",
    description: "Border outline around feature cards on welcome page",
    category: "borders",
    deriveDefault: (c) => c.border,
  },
  {
    id: "welcomePage.progress.background",
    label: "Welcome Progress Bar Surface",
    description: "Track background of setup progress bar on welcome page",
    category: "surfaces",
    isBg: true,
    deriveDefault: (c) => c.primary,
  },
  {
    id: "welcomePage.progress.foreground",
    label: "Welcome Progress Bar Fill",
    description: "Fill indicator color of setup progress bar on welcome page",
    category: "text",
    contrastPairId: "welcomePage.progress.background",
    deriveDefault: (c) => getOptimalPrimaryForeground(c.primary),
  },
];

// Keep one canonical entry per VS Code color id. Feature-oriented sections can overlap.
export const VSCODE_TOKEN_REGISTRY: TokenMetadata[] = Array.from(
  new Map(VSCODE_TOKEN_REGISTRY_ENTRIES.map((token) => [token.id, token])).values(),
);

/**
 * Returns the derived default value for a single token key given primary colors and dark mode variant.
 */
export function getDerivedTokenValue(
  tokenId: string,
  colors: CustomThemeColors,
  baseVariant: "dark" | "light" = "dark",
): string {
  const token = VSCODE_TOKEN_REGISTRY.find((t) => t.id === tokenId);
  if (token) {
    return token.deriveDefault(colors, baseVariant === "dark");
  }
  return "#000000";
}

/**
 * Evaluates the full dictionary of ~95 VS Code & App Shell color tokens for a given CustomThemeConfig.
 * Explicit overrides in config.tokenOverrides take precedence over derived defaults.
 * Automatic contrast clamping is systematically applied across all foreground tokens.
 */
export function evaluateThemeTokens(
  config: CustomThemeConfig,
  diffColorSchemeOverride?: "red-green" | "blue-orange",
): Record<string, string> {
  const isDark = config.baseVariant === "dark";
  const diffColorScheme = diffColorSchemeOverride ?? config.diffColorScheme ?? "red-green";
  const isBlueOrange = diffColorScheme === "blue-orange";
  const colors: CustomThemeColors = {
    ...config.colors,
    foreground: ensureMinContrast(config.colors.foreground, config.colors.background, 4.5),
  };
  const overrides = config.tokenOverrides ?? {};

  const result: Record<string, string> = {};

  // Pass 1: Resolve all tokens (from overrides or derived defaults)
  for (const token of VSCODE_TOKEN_REGISTRY) {
    const overrideVal = overrides[token.id];
    if (overrideVal && typeof overrideVal === "string" && overrideVal.trim().length > 0) {
      result[token.id] = overrideVal.trim();
    } else if (isBlueOrange && token.id.startsWith("diffEditor")) {
      switch (token.id) {
        case "diffEditor.insertedTextBackground":
          result[token.id] = isDark ? "#60a5fa33" : "#2563eb33";
          break;
        case "diffEditor.removedTextBackground":
          result[token.id] = isDark ? "#fb923c40" : "#ea580c33";
          break;
        case "diffEditor.insertedLineBackground":
          result[token.id] = isDark ? "#60a5fa1f" : "#2563eb1a";
          break;
        case "diffEditor.removedLineBackground":
          result[token.id] = isDark ? "#fb923c1f" : "#ea580c1a";
          break;
        case "diffEditorGutter.insertedLineBackground":
          result[token.id] = isDark ? "#60a5fa4d" : "#2563eb4d";
          break;
        case "diffEditorGutter.removedLineBackground":
          result[token.id] = isDark ? "#fb923c4d" : "#ea580c4d";
          break;
        case "diffEditorOverview.insertedForeground":
          result[token.id] = isDark ? "#60a5fab3" : "#2563ebb3";
          break;
        case "diffEditorOverview.removedForeground":
          result[token.id] = isDark ? "#fb923cb3" : "#ea580cb3";
          break;
        default:
          result[token.id] = token.deriveDefault(colors, isDark);
          break;
      }
    } else {
      result[token.id] = token.deriveDefault(colors, isDark);
    }
  }

  // Pass 2: Automatic Contrast Enforcement Pass
  for (const token of VSCODE_TOKEN_REGISTRY) {
    if (token.contrastPairId && result[token.contrastPairId]) {
      const fgVal = result[token.id];
      const bgVal = result[token.contrastPairId];
      if (fgVal && bgVal) {
        let minRatio = 4.5;
        if (
          token.id.includes("disabled") ||
          token.id.includes("LineNumber") ||
          token.id.includes("ignored") ||
          token.id.includes("Whitespace")
        ) {
          minRatio = 1.5;
        } else if (
          token.id.includes("description") ||
          token.id.includes("placeholder") ||
          token.id.includes("inactive")
        ) {
          minRatio = 1.8;
        } else if (
          token.id === "extensionButton.prominentForeground" ||
          token.id === "activityBarBadge.foreground" ||
          token.id === "badge.foreground"
        ) {
          minRatio = 3.5;
        }
        result[token.id] = ensureMinContrast(
          fgVal,
          bgVal,
          minRatio,
          result["editor.background"] || colors.background,
        );
      }
    }
  }

  // Pass 3: Ensure all tokens are valid hex colors. VS Code's Color parser only supports
  // #RRGGBB and #RRGGBBAA. If it encounters rgba() or 'transparent', it falls back to red.
  for (const key of Object.keys(result)) {
    result[key] = toHexColor(result[key]);
  }

  return result;
}

/**
 * Evaluates WCAG contrast checks across all foreground/background token pairs.
 */
export function runThemeWcagCheck(
  configOrTokens: CustomThemeConfig | Record<string, string>,
): WcagCheckResult[] {
  const resolvedTokens: Record<string, string> =
    "colors" in configOrTokens
      ? evaluateThemeTokens(configOrTokens as CustomThemeConfig)
      : (configOrTokens as Record<string, string>);

  const canvasBg = resolvedTokens["editor.background"] || "#121824";

  // Comprehensive audit pairs covering all UI, editor, widget, statusbar & git surfaces
  const checkPairs: { fgToken: string; bgToken: string }[] = VSCODE_TOKEN_REGISTRY.filter((t) =>
    Boolean(t.contrastPairId),
  ).map((t) => ({
    fgToken: t.id,
    bgToken: t.contrastPairId!,
  }));

  const results: WcagCheckResult[] = [];

  for (const pair of checkPairs) {
    const fgHex = toHexColor(resolvedTokens[pair.fgToken]);
    const bgHex = resolvedTokens[pair.bgToken] || canvasBg;

    const fgMeta = VSCODE_TOKEN_REGISTRY.find((t) => t.id === pair.fgToken);
    const bgMeta = VSCODE_TOKEN_REGISTRY.find((t) => t.id === pair.bgToken);

    let minRatio = 4.5;
    if (
      pair.fgToken.includes("disabled") ||
      pair.fgToken.includes("LineNumber") ||
      pair.fgToken.includes("ignored") ||
      pair.fgToken.includes("Whitespace") ||
      pair.fgToken.includes("commentRange") ||
      pair.fgToken.includes("editorHint")
    ) {
      minRatio = 1.5;
    } else if (
      pair.fgToken.includes("description") ||
      pair.fgToken.includes("placeholder") ||
      pair.fgToken.includes("inactive") ||
      pair.fgToken.includes("breadcrumb") ||
      pair.fgToken.includes("lineForeground")
    ) {
      minRatio = 1.8;
    }

    const { ratio } = calculateContrastRatio(fgHex, bgHex, canvasBg);
    const isLowContrast = ratio < minRatio;

    results.push({
      fgToken: pair.fgToken,
      bgToken: pair.bgToken,
      fgLabel: fgMeta?.label ?? pair.fgToken,
      bgLabel: bgMeta?.label ?? pair.bgToken,
      fgHex,
      bgHex,
      ratio,
      isLowContrast,
      recommendedFg: isLowContrast
        ? ensureMinContrast(fgHex, bgHex, minRatio, canvasBg)
        : undefined,
    });
  }

  return results;
}
