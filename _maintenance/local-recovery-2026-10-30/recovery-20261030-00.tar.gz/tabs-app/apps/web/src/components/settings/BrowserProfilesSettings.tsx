import {
  DEFAULT_BROWSER_LINK_TARGET,
  type BrowserLinkTarget,
  type BrowserProfileDefinition,
} from "@tabs/contracts/settings";
import {
  type BrowserProfileDomainInfo,
  type BrowserProfileInspection,
  type BrowserProfilePermissionInfo,
} from "@tabs/contracts";
import {
  FingerprintIcon,
  PlusIcon,
  DownloadIcon,
  PencilIcon,
  Trash2Icon,
  RotateCcwIcon,
  LayersIcon,
  CheckIcon,
  GlobeIcon,
  ExternalLinkIcon,
  XIcon,
  ShieldCheckIcon,
  LoaderCircleIcon,
} from "lucide-react";
import type { BrowserImportSourceId, BrowserImportSource } from "@tabs/contracts";
import { BROWSER_IMPORT_FAILURE_COPY } from "@tabs/contracts";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSettings, useUpdateSettings } from "../../hooks/useSettings";
import { useAtomValue } from "@effect/atom-react";
import { projectsAtom } from "../../state/threads";
import { workspaceShellActions, workspaceShellAtom } from "../../state/workspaceShell";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Badge } from "../ui/badge";
import { SettingsSection, SettingsSectionHeader, SettingsRow } from "./SettingsLayout";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogPanel,
  DialogDetails,
  DialogTitle,
} from "../ui/dialog";
import { Select, SelectItem, SelectPopup, SelectTrigger, SelectValue } from "../ui/select";
import { useConfirm } from "../../hooks/useConfirm";
import { toastManager } from "../ui/toast";
import { cn } from "../../lib/utils";
import { removeBrowserProfileAssignments } from "./browserProfileAssignments";

const PRESET_COLORS = [
  "#3b82f6", // Blue
  "#10b981", // Emerald
  "#8b5cf6", // Purple
  "#f59e0b", // Amber
  "#ec4899", // Pink
  "#06b6d4", // Cyan
  "#f43f5e", // Rose
  "#6366f1", // Indigo
];

interface QuickPortal {
  name: string;
  url: string;
}

const DEFAULT_PORTALS: QuickPortal[] = [
  { name: "Google", url: "https://accounts.google.com" },
  { name: "ChatGPT", url: "https://chatgpt.com" },
  { name: "Figma", url: "https://www.figma.com/login" },
  { name: "GitHub", url: "https://github.com/login" },
  { name: "Linear", url: "https://linear.app/login" },
];

export type ProfileInspectionStatus = "idle" | "loading" | "loaded" | "failed";

export interface ProfileInspectionState {
  status: ProfileInspectionStatus;
  data: BrowserProfileInspection | null;
  error: string | null;
}

function slugifyProfileId(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9-_]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function BrowserProfilesSettings() {
  const settings = useSettings();
  const { updateSettings } = useUpdateSettings();
  const { confirm, confirmDialog } = useConfirm();
  const projects = useAtomValue(projectsAtom);
  const shellState = useAtomValue(workspaceShellAtom);

  const profiles: readonly BrowserProfileDefinition[] = useMemo(() => {
    return settings.browserProfiles && settings.browserProfiles.length > 0
      ? settings.browserProfiles
      : [
          { id: "personal", label: "Personal", color: "#3b82f6", createdAt: 0 },
          { id: "work", label: "Work", color: "#10b981", createdAt: 0 },
        ];
  }, [settings.browserProfiles]);

  // Compute live usage across all projects in the workspace
  const usageByProfileId = useMemo(() => {
    const map = new Map<string, Array<{ projectName: string; tabName: string }>>();
    for (const project of projects) {
      const pSettings = shellState.projectSettingsByProjectId[project.id];
      if (!pSettings) continue;

      // Check default browser tool
      if (pSettings.browser.partitionMode === "profile") {
        const profileId = (pSettings.browser.partitionProfile ?? "").trim();
        if (profileId) {
          const list = map.get(profileId) ?? [];
          list.push({ projectName: project.name || "Untitled Project", tabName: "Browser" });
          map.set(profileId, list);
        }
      }

      // Check custom embeds
      for (const embed of pSettings.customEmbeds ?? []) {
        if (embed.partitionMode === "profile") {
          const profileId = (embed.partitionProfile ?? "").trim();
          if (profileId) {
            const list = map.get(profileId) ?? [];
            list.push({
              projectName: project.name || "Untitled Project",
              tabName: embed.label || "Custom Tab",
            });
            map.set(profileId, list);
          }
        }
      }
    }
    return map;
  }, [projects, shellState.projectSettingsByProjectId]);
  const hasNamedProfileAssignments = useMemo(
    () => Array.from(usageByProfileId.values()).some((assignments) => assignments.length > 0),
    [usageByProfileId],
  );

  // Live domain & auth inspection per profile
  const [profileInspections, setProfileInspections] = useState<
    Record<string, ProfileInspectionState>
  >({});
  const inspectionGenerationRef = useRef<Record<string, number>>({});

  const inspectSingleProfile = useCallback(async (profileId: string) => {
    if (
      !window.desktopBridge?.inspectBrowserProfile &&
      !window.desktopBridge?.getBrowserProfileDomains
    ) {
      return;
    }
    const generation = (inspectionGenerationRef.current[profileId] ?? 0) + 1;
    inspectionGenerationRef.current[profileId] = generation;
    setProfileInspections((prev) => ({
      ...prev,
      [profileId]: {
        status: "loading",
        data: prev[profileId]?.data ?? null,
        error: null,
      },
    }));
    try {
      let inspection: BrowserProfileInspection;
      if (window.desktopBridge.inspectBrowserProfile) {
        inspection = await window.desktopBridge.inspectBrowserProfile({ profileId });
      } else {
        const domains = await window.desktopBridge.getBrowserProfileDomains({ profileId });
        inspection = {
          profileId,
          partition: `persist:tabs-browser:profile:${profileId}`,
          isPersistent: true,
          storagePath: null,
          totalDomains: domains.length,
          totalCookies: domains.reduce((sum, d) => sum + d.cookieCount, 0),
          domains,
          inspectedAt: Date.now(),
        };
      }
      if (inspectionGenerationRef.current[profileId] !== generation) return;
      setProfileInspections((prev) => ({
        ...prev,
        [profileId]: {
          status: "loaded",
          data: inspection,
          error: null,
        },
      }));
    } catch (err) {
      if (inspectionGenerationRef.current[profileId] !== generation) return;
      const errorMsg =
        err instanceof Error ? err.message : "Failed to inspect profile cookie domains";
      setProfileInspections((prev) => ({
        ...prev,
        [profileId]: {
          status: "failed",
          data: null,
          error: errorMsg,
        },
      }));
    }
  }, []);

  const refreshDomains = useCallback(async () => {
    await Promise.all(profiles.map((profile) => inspectSingleProfile(profile.id)));
  }, [profiles, inspectSingleProfile]);

  const profileDomains = useMemo(() => {
    const res: Record<string, BrowserProfileDomainInfo[]> = {};
    for (const [id, state] of Object.entries(profileInspections)) {
      if (state.data) res[id] = state.data.domains;
    }
    return res;
  }, [profileInspections]);

  const [profilePermissions, setProfilePermissions] = useState<
    Record<string, BrowserProfilePermissionInfo[]>
  >({});
  const [isLoadingPermissions, setIsLoadingPermissions] = useState(false);
  const permissionRequestIdRef = useRef(0);
  const refreshPermissions = useCallback(async () => {
    if (!window.desktopBridge?.getBrowserProfilePermissions) return;
    const requestId = ++permissionRequestIdRef.current;
    setIsLoadingPermissions(true);
    try {
      const entries = await Promise.all(
        profiles.map(async (profile) => {
          try {
            const permissions = await window.desktopBridge!.getBrowserProfilePermissions!({
              profileId: profile.id,
            });
            return [profile.id, permissions] as const;
          } catch {
            return [profile.id, []] as const;
          }
        }),
      );
      if (permissionRequestIdRef.current === requestId) {
        setProfilePermissions(Object.fromEntries(entries));
      }
    } finally {
      if (permissionRequestIdRef.current === requestId) {
        setIsLoadingPermissions(false);
      }
    }
  }, [profiles]);

  const handleRevokePermission = async (profileId: string, origin: string, permission: string) => {
    if (!window.desktopBridge?.revokeBrowserProfilePermission) return;
    try {
      await window.desktopBridge.revokeBrowserProfilePermission({ profileId, origin, permission });
      toastManager.add({
        type: "success",
        title: "Permission revoked",
        description: `Revoked ${permission} for ${origin}.`,
      });
      await refreshPermissions();
    } catch {
      toastManager.add({
        type: "error",
        title: "Failed to revoke permission",
        description: `Could not revoke ${permission} for ${origin}.`,
      });
    }
  };

  useEffect(() => {
    refreshDomains();
    refreshPermissions();
  }, [refreshDomains, refreshPermissions]);

  useEffect(() => {
    const subscribe = window.desktopBridge?.onBrowserProfileDataChanged;
    if (!subscribe) return;
    return subscribe((profileId) => {
      if (profiles.some((profile) => profile.id === profileId)) {
        void inspectSingleProfile(profileId);
      }
    });
  }, [inspectSingleProfile, profiles]);

  // Quick portals customized by user
  const [customPortals, setCustomPortals] = useState<QuickPortal[]>(() => {
    try {
      const raw = localStorage.getItem("tabs:custom-login-portals:v1");
      return raw ? JSON.parse(raw) : DEFAULT_PORTALS;
    } catch {
      return DEFAULT_PORTALS;
    }
  });

  const [isAddingPortal, setIsAddingPortal] = useState(false);
  const portalOpener = useRef<HTMLElement | null>(null);
  const [newPortalName, setNewPortalName] = useState("");
  const [newPortalUrl, setNewPortalUrl] = useState("");

  const handleAddCustomPortal = () => {
    const name = newPortalName.trim();
    let url = newPortalUrl.trim();
    if (!name || !url) return;
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      url = "https://" + url;
    }
    const updated = [...customPortals, { name, url }];
    setCustomPortals(updated);
    try {
      localStorage.setItem("tabs:custom-login-portals:v1", JSON.stringify(updated));
    } catch {}
    setIsAddingPortal(false);
    setNewPortalName("");
    setNewPortalUrl("");
  };

  // Create / Edit modal state
  const [modalOpen, setModalOpen] = useState(false);
  const profileDialogOpener = useRef<HTMLElement | null>(null);
  const [editingProfile, setEditingProfile] = useState<BrowserProfileDefinition | null>(null);
  const [labelDraft, setLabelDraft] = useState("");
  const [idDraft, setIdDraft] = useState("");
  const [descriptionDraft, setDescriptionDraft] = useState("");
  const [colorDraft, setColorDraft] = useState("#3b82f6");
  const [clearingProfileId, setClearingProfileId] = useState<string | null>(null);
  const [deletingProfileId, setDeletingProfileId] = useState<string | null>(null);

  // In-Dialog Interactive Login & Session Tester
  const [testingProfile, setTestingProfile] = useState<BrowserProfileDefinition | null>(null);
  const [testUrl, setTestUrl] = useState<string>("https://accounts.google.com");
  const [selectedLoginUrl, setSelectedLoginUrl] = useState<string>("https://accounts.google.com");
  const [loginWindowOpen, setLoginWindowOpen] = useState(false);

  const openCreateModal = () => {
    profileDialogOpener.current =
      document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setEditingProfile(null);
    setLabelDraft("");
    setIdDraft("");
    setDescriptionDraft("");
    setColorDraft(PRESET_COLORS[Math.floor(Math.random() * PRESET_COLORS.length)] ?? "#3b82f6");
    setModalOpen(true);
  };

  const openEditModal = (profile: BrowserProfileDefinition) => {
    profileDialogOpener.current =
      document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setEditingProfile(profile);
    setLabelDraft(profile.label);
    setIdDraft(profile.id);
    setDescriptionDraft(profile.description ?? "");
    setColorDraft(profile.color ?? "#3b82f6");
    setModalOpen(true);
  };

  // Browser import modal state
  const [importModalOpen, setImportModalOpen] = useState(false);
  const [isLoadingImportSources, setIsLoadingImportSources] = useState(false);
  const [importSources, setImportSources] = useState<BrowserImportSource[]>([]);
  const [selectedSourceId, setSelectedSourceId] = useState<BrowserImportSourceId | "">("");
  const [selectedProfileDir, setSelectedProfileDir] = useState<string>("Default");
  const [importTargetProfileId, setImportTargetProfileId] = useState<string>("");
  const importRequestId = useRef<string | null>(null);
  const closeImport = () => {
    if (importRequestId.current)
      void window.desktopBridge?.cancelBrowserImport?.(importRequestId.current);
    setImportModalOpen(false);
  };
  useEffect(
    () => () => {
      if (importRequestId.current)
        void window.desktopBridge?.cancelBrowserImport?.(importRequestId.current);
    },
    [],
  );
  const [importing, setImporting] = useState(false);

  const openImportModal = async () => {
    if (isLoadingImportSources) return;
    if (!window.desktopBridge?.listBrowserImportSources) {
      toastManager.add({
        type: "error",
        title: "Desktop build required",
        description: "Browser session import is only supported in the native desktop app.",
      });
      return;
    }
    setIsLoadingImportSources(true);
    try {
      const sources = await window.desktopBridge.listBrowserImportSources();
      setImportSources(sources);
      if (sources.length > 0) {
        setSelectedSourceId(sources[0]?.id ?? "");
        setSelectedProfileDir(sources[0]?.profiles[0]?.directory ?? "Default");
      }
      setImportTargetProfileId(profiles[0]?.id ?? "personal");
      setImportModalOpen(true);
    } catch (error) {
      toastManager.add({
        type: "error",
        title: "Could not scan installed browsers",
        description: error instanceof Error ? error.message : "Try again in a moment.",
      });
    } finally {
      setIsLoadingImportSources(false);
    }
  };

  const handleRunImport = async () => {
    if (!window.desktopBridge?.importBrowserCookies || selectedSourceId === "") return;
    setImporting(true);
    importRequestId.current = crypto.randomUUID();
    try {
      const result = await window.desktopBridge.importBrowserCookies({
        requestId: importRequestId.current,
        sourceId: selectedSourceId,
        sourceProfileDirectory: selectedProfileDir,
        targetProfileId: importTargetProfileId,
      });
      if (result.cancelled) {
        toastManager.add({
          title: "Import cancelled",
          description: `${result.imported} cookies were imported before cancellation. Existing destination cookies have been retained.`,
        });
        return;
      }
      if (result.imported === 0) {
        throw new Error(
          result.warnings?.join(" ") ||
            (result.skipped > 0
              ? `No cookies imported; ${result.skipped} cookies were unsupported or could not be read.`
              : BROWSER_IMPORT_FAILURE_COPY.noCookies),
        );
      }
      toastManager.add({
        type: "success",
        title: "Browser session imported",
        description: `Imported ${result.imported} cookies; skipped ${result.skipped}. ${result.warnings?.join(" ") ?? ""}`,
      });
      setImportModalOpen(false);
      if (window.desktopBridge) {
        await inspectSingleProfile(importTargetProfileId);
      }
    } catch (err: any) {
      toastManager.add({
        type: "error",
        title: "Import failed",
        description: err.message || "Failed to import browser session.",
      });
    } finally {
      importRequestId.current = null;
      setImporting(false);
    }
  };

  const handleSaveProfile = () => {
    const trimmedLabel = labelDraft.trim();
    if (!trimmedLabel) return;

    const finalId = (editingProfile ? idDraft : idDraft.trim() || slugifyProfileId(trimmedLabel))
      .toLowerCase()
      .trim();

    if (!finalId) return;

    if (!editingProfile && profiles.some((p) => p.id === finalId)) {
      toastManager.add({
        type: "error",
        title: "Profile ID already exists",
        description: `A profile with ID "${finalId}" already exists. Please choose a different name or ID.`,
      });
      return;
    }

    const nextProfile: BrowserProfileDefinition = {
      id: finalId,
      label: trimmedLabel,
      ...(descriptionDraft.trim() ? { description: descriptionDraft.trim() } : {}),
      color: colorDraft,
      createdAt: editingProfile?.createdAt || Date.now(),
    };

    const nextProfiles = editingProfile
      ? profiles.map((p) => (p.id === editingProfile.id ? nextProfile : p))
      : [...profiles, nextProfile];

    updateSettings({ browserProfiles: nextProfiles });
    setModalOpen(false);
    toastManager.add({
      type: "success",
      title: editingProfile ? "Profile updated" : "Profile created",
      description: `Browser profile "${trimmedLabel}" has been saved.`,
    });
  };

  const handleDeleteProfile = async (profile: BrowserProfileDefinition) => {
    const usage = usageByProfileId.get(profile.id) ?? [];
    const message =
      usage.length > 0
        ? `Delete profile "${profile.label}"?\n\nThis profile is currently used in ${usage.length} tab(s) across your projects. Deleting it will leave those tabs using fallback sessions.`
        : `Delete profile "${profile.label}"?\n\nAre you sure you want to delete this browser profile? This cannot be undone.`;

    const confirmed = await confirm(message);
    if (!confirmed) return;

    setDeletingProfileId(profile.id);
    try {
      for (const project of projects) {
        const current = shellState.projectSettingsByProjectId[project.id];
        if (!current) continue;
        const browserUsesProfile =
          current.browser.partitionMode === "profile" &&
          current.browser.partitionProfile === profile.id;
        const embedsUseProfile = current.customEmbeds.some(
          (embed) => embed.partitionMode === "profile" && embed.partitionProfile === profile.id,
        );
        if (!browserUsesProfile && !embedsUseProfile) continue;
        workspaceShellActions.upsertProjectSettings(project.id, (settings) =>
          removeBrowserProfileAssignments(settings, profile.id),
        );
      }
      await window.desktopBridge?.clearBrowserProfileData?.({ profileId: profile.id });
      const nextProfiles = profiles.filter((p) => p.id !== profile.id);
      updateSettings({ browserProfiles: nextProfiles });
      toastManager.add({
        type: "success",
        title: "Profile deleted",
        description: `Profile "${profile.label}" was cleared and its assigned tabs now use their project session.`,
      });
    } catch {
      toastManager.add({
        type: "error",
        title: "Could not delete profile",
        description: "The profile was kept because its session data could not be cleared safely.",
      });
    } finally {
      setDeletingProfileId(null);
    }
  };

  const handleClearSessionData = async (profile: BrowserProfileDefinition) => {
    const confirmed = await confirm(
      `Clear all session data for "${profile.label}"?\n\nThis will log out all accounts, clear cookies, LocalStorage, and cache for all browser tabs assigned to the "${profile.label}" profile. Other profiles will not be affected.`,
    );

    if (!confirmed) return;

    setClearingProfileId(profile.id);
    try {
      if (window.desktopBridge?.clearBrowserProfileData) {
        await window.desktopBridge.clearBrowserProfileData({ profileId: profile.id });
      }
      toastManager.add({
        type: "success",
        title: "Session data cleared",
        description: `Successfully logged out and cleared all cookies for "${profile.label}".`,
      });
      await refreshDomains();
    } catch {
      toastManager.add({
        type: "error",
        title: "Failed to clear session data",
        description: "An error occurred while communicating with the desktop session manager.",
      });
    } finally {
      setClearingProfileId(null);
    }
  };

  const handleClearSingleDomain = async (profile: BrowserProfileDefinition, domain: string) => {
    const confirmed = await confirm(
      `Log out of ${domain} for profile "${profile.label}"?\n\nThis will clear cookies and session data for ${domain} only. Other logins (e.g. Google, Figma) will stay logged in.`,
    );
    if (!confirmed) return;

    try {
      if (window.desktopBridge?.clearBrowserProfileDomain) {
        await window.desktopBridge.clearBrowserProfileDomain({
          profileId: profile.id,
          domain,
        });
        toastManager.add({
          type: "success",
          title: `Logged out of ${domain}`,
          description: `Session cleared for ${domain} in "${profile.label}".`,
        });
        await inspectSingleProfile(profile.id);
      }
    } catch {
      toastManager.add({
        type: "error",
        title: "Failed to clear domain session",
        description: `Could not remove cookies for ${domain}.`,
      });
    }
  };

  const openLoginModal = (
    profile: BrowserProfileDefinition,
    initialUrl = "https://accounts.google.com",
  ) => {
    setTestingProfile(profile);
    setTestUrl(initialUrl);
    setSelectedLoginUrl(initialUrl);
    void refreshDomains();
  };

  const openNativeProfileWindow = async (profile: BrowserProfileDefinition, rawUrl: string) => {
    let url = rawUrl.trim();
    if (!url) return;
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      url = `https://${url}`;
    }
    setTestUrl(url);
    setSelectedLoginUrl(url);
    setLoginWindowOpen(true);
    try {
      await window.desktopBridge?.openBrowserProfileLoginWindow?.({ profileId: profile.id, url });
      await refreshDomains();
      toastManager.add({
        type: "success",
        title: "Profile window closed",
        description: `Stored-site information for "${profile.label}" has been refreshed.`,
      });
    } catch {
      toastManager.add({
        type: "error",
        title: "Could not open profile window",
        description: "The native browser session could not be opened.",
      });
    } finally {
      setLoginWindowOpen(false);
    }
  };

  useEffect(() => {
    if (!testingProfile) return;
    const timer = window.setInterval(() => void refreshDomains(), 2_000);
    return () => window.clearInterval(timer);
  }, [refreshDomains, testingProfile]);

  return (
    <div className="space-y-6">
      {confirmDialog}

      <div className="[&>div>div:first-child]:flex-wrap [&>div>div:first-child]:gap-4">
        <SettingsSectionHeader
          title="Browser Profiles"
          description="Keep separate accounts across tabs and projects."
          actions={
            <div className="flex items-center gap-2 shrink-0">
              <Button
                variant="outline"
                onClick={openImportModal}
                title="Import cookies from installed desktop browsers"
                disabled={isLoadingImportSources}
                aria-busy={isLoadingImportSources}
                className="gap-1.5 cursor-pointer"
              >
                {isLoadingImportSources ? (
                  <LoaderCircleIcon className="size-4 animate-spin" aria-hidden="true" />
                ) : (
                  <DownloadIcon className="size-4" aria-hidden="true" />
                )}
                {isLoadingImportSources ? "Scanning browsers…" : "Import Sessions"}
              </Button>
              <Button onClick={openCreateModal} className="gap-1.5 cursor-pointer">
                <PlusIcon className="size-4" />
                Create Profile
              </Button>
            </div>
          }
        />
      </div>

      <SettingsSection title="Browsing">
        <SettingsRow
          title="Open links in"
          description="Choose where links from chat open."
          control={
            <Select
              value={settings.browserLinkTarget ?? DEFAULT_BROWSER_LINK_TARGET}
              onValueChange={(value) => {
                if (value) {
                  updateSettings({ browserLinkTarget: value as BrowserLinkTarget });
                }
              }}
            >
              <SelectTrigger
                aria-label="Open chat links in"
                title="Hold Command or Control while clicking a link to use your system browser."
                className="h-9 w-full sm:w-48"
              >
                <SelectValue>
                  {settings.browserLinkTarget === "app" ? "Tabs browser" : "System browser"}
                </SelectValue>
              </SelectTrigger>
              <SelectPopup>
                <SelectItem value="system">Default system browser</SelectItem>
                <SelectItem value="app">Tabs integrated browser</SelectItem>
              </SelectPopup>
            </Select>
          }
        />
      </SettingsSection>

      <SettingsSection
        title="Profiles"
        description={
          !hasNamedProfileAssignments
            ? "Tabs use separate project sessions until you assign a profile."
            : undefined
        }
      >
        <div className="divide-y divide-border">
          {profiles.map((profile) => {
            const usage = usageByProfileId.get(profile.id) ?? [];
            const inspectionState = profileInspections[profile.id] ?? {
              status: "idle",
              data: null,
              error: null,
            };
            const inspection = inspectionState.data;
            const domains = inspection?.domains ?? profileDomains[profile.id] ?? [];
            const permissions = profilePermissions[profile.id] ?? [];
            const sessionHintDomains = domains.filter((d) => d.hasSessionHint);
            const otherDomains = domains.filter((d) => !d.hasSessionHint);
            const isClearing = clearingProfileId === profile.id;
            const isDeleting = deletingProfileId === profile.id;

            return (
              <div key={profile.id} className="px-4 py-4 sm:px-5">
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className="size-3.5 rounded-full shrink-0 ring-1 ring-border"
                        style={{ backgroundColor: profile.color || "#3b82f6" }}
                      />
                      <h3 className="text-[14.5px] font-bold truncate">{profile.label}</h3>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button
                        size="icon-xs"
                        variant="ghost"
                        onClick={() => openEditModal(profile)}
                        title="Edit Profile"
                        aria-label={`Edit profile ${profile.label}`}
                        disabled={deletingProfileId !== null}
                        className="text-muted-foreground hover:text-foreground cursor-pointer"
                      >
                        <PencilIcon className="size-3.5" />
                      </Button>
                      <Button
                        size="icon-xs"
                        variant="ghost"
                        onClick={() => handleDeleteProfile(profile)}
                        title="Delete Profile"
                        aria-label={
                          isDeleting
                            ? `Deleting profile ${profile.label}`
                            : `Delete profile ${profile.label}`
                        }
                        aria-busy={isDeleting}
                        disabled={deletingProfileId !== null || isClearing}
                        className="text-muted-foreground hover:text-destructive cursor-pointer"
                      >
                        {isDeleting ? (
                          <LoaderCircleIcon className="size-3.5 animate-spin" aria-hidden="true" />
                        ) : (
                          <Trash2Icon className="size-3.5" aria-hidden="true" />
                        )}
                      </Button>
                    </div>
                  </div>
                  {profile.description && (
                    <p className="text-xs text-muted-foreground">{profile.description}</p>
                  )}
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>
                        {usage.length} {usage.length === 1 ? "tab" : "tabs"}
                      </span>
                      <span aria-hidden="true" className="size-1 rounded-full bg-border" />
                      <span role="status">
                        {inspectionState.status === "loading"
                          ? "Checking sites..."
                          : inspectionState.status === "failed"
                            ? "Could not load sites"
                            : inspectionState.status === "idle" && !inspection
                              ? "Sites unavailable"
                              : `${domains.length} ${domains.length === 1 ? "stored site" : "stored sites"}`}
                      </span>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openLoginModal(profile)}
                      disabled={deletingProfileId !== null}
                      aria-label={`Open profile ${profile.label}`}
                      className="gap-1.5 cursor-pointer"
                    >
                      <GlobeIcon className="size-3.5" aria-hidden="true" />
                      Open profile
                    </Button>
                  </div>
                </div>

                <details className="group mt-3">
                  <summary className="w-fit cursor-pointer rounded-md text-xs text-muted-foreground hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring focus-visible:outline-offset-4">
                    Profile details<span className="sr-only"> for {profile.label}</span>
                  </summary>
                  <div className="mt-3 space-y-3">
                    {/* Assigned tabs */}
                    <div className="rounded-lg bg-muted/40 border border-border/50 p-2.5 text-xs space-y-1.5">
                      <div className="font-medium text-foreground flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-muted-foreground">
                          <LayersIcon className="size-3.5 text-foreground/70" />
                          Assigned tabs
                        </span>
                        <span className="font-mono text-[11px]">
                          {usage.length} {usage.length === 1 ? "tab" : "tabs"}
                        </span>
                      </div>
                      {usage.length > 0 ? (
                        <div className="flex flex-wrap gap-1.5 pt-0.5">
                          {usage.map((u) => (
                            <span
                              key={`${u.projectName}:${u.tabName}`}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-background/80 border border-border/60 text-[11px] text-foreground"
                            >
                              <span className="font-medium">{u.projectName}:</span>
                              <span className="text-muted-foreground">{u.tabName}</span>
                            </span>
                          ))}
                        </div>
                      ) : (
                        <div className="text-[11px] text-muted-foreground/70">
                          No assigned tabs.
                        </div>
                      )}
                    </div>

                    {/* Cookie Domains & Heuristic Sessions */}
                    <div className="rounded-lg bg-muted/30 border border-border/50 p-2.5 text-xs space-y-2">
                      <div className="font-medium text-foreground flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-muted-foreground">
                          <ShieldCheckIcon className="size-3.5 text-foreground" />
                          Stored sites
                        </span>
                        {inspection && (
                          <span className="font-mono text-[11px] text-muted-foreground">
                            {inspection.totalDomains}{" "}
                            {inspection.totalDomains === 1 ? "domain" : "domains"} (
                            {inspection.totalCookies}{" "}
                            {inspection.totalCookies === 1 ? "cookie" : "cookies"})
                          </span>
                        )}
                      </div>

                      {/* Partition Metadata */}
                      <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground font-mono">
                        <span className="break-all bg-background/80 px-1.5 py-0.5 rounded border border-border/60">
                          Partition:{" "}
                          {inspection?.partition ?? `persist:tabs-browser:profile:${profile.id}`}
                        </span>
                        {inspection && (
                          <span className="break-all bg-background/80 px-1.5 py-0.5 rounded border border-border/60">
                            {inspection.isPersistent
                              ? "Persistent partition"
                              : "In-memory partition"}
                          </span>
                        )}
                        {inspection?.inspectedAt && (
                          <span className="text-[10px] text-muted-foreground/70 not-italic font-sans">
                            Refreshed: {new Date(inspection.inspectedAt).toLocaleTimeString()}
                          </span>
                        )}
                      </div>

                      {/* State: Loading */}
                      {inspectionState.status === "loading" && (
                        <div className="py-2 text-center text-xs text-muted-foreground">
                          Inspecting cookie domains...
                        </div>
                      )}

                      {/* State: Failed */}
                      {inspectionState.status === "failed" && (
                        <div className="flex items-center justify-between p-2 rounded-md bg-destructive/10 border border-destructive/30 text-destructive text-xs">
                          <span>Inspection failed: {inspectionState.error ?? "Unknown error"}</span>
                          <Button
                            size="xs"
                            variant="outline"
                            className="h-6 px-2 text-xs border-destructive/40 hover:bg-destructive/20 text-foreground"
                            onClick={() => inspectSingleProfile(profile.id)}
                            disabled={deletingProfileId !== null}
                          >
                            Retry
                          </Button>
                        </div>
                      )}

                      {/* State: Loaded */}
                      {(inspectionState.status === "loaded" ||
                        (inspectionState.status === "idle" && domains.length > 0)) && (
                        <>
                          {domains.length === 0 ? (
                            <div className="text-[11px] text-muted-foreground/70">
                              No stored sites in this profile.
                            </div>
                          ) : (
                            <div className="space-y-2">
                              {sessionHintDomains.length > 0 && (
                                <div className="space-y-1">
                                  <div className="text-[10px] uppercase font-semibold text-muted-foreground/80 tracking-wider">
                                    Session cookies (sign-in unverified):
                                  </div>
                                  <div className="flex flex-wrap gap-1.5">
                                    {sessionHintDomains.map((item) => (
                                      <span
                                        key={item.domain}
                                        className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-primary/10 border border-primary/30 text-[11px] text-foreground group"
                                        title="A session cookie was detected, but this is a heuristic and does not guarantee that an account is active or signed in."
                                      >
                                        <span
                                          className="size-1.5 rounded-full bg-amber-500 shrink-0"
                                          aria-hidden="true"
                                        />
                                        <span className="font-medium">{item.domain}</span>
                                        <span className="text-[10px] text-muted-foreground">
                                          ({item.cookieCount})
                                        </span>
                                        <button
                                          type="button"
                                          onClick={() =>
                                            handleClearSingleDomain(profile, item.domain)
                                          }
                                          disabled={deletingProfileId !== null}
                                          title={`Clear cookies for ${item.domain}`}
                                          aria-label={`Clear cookies for ${item.domain} in ${profile.label}`}
                                          className="text-muted-foreground hover:text-destructive cursor-pointer opacity-70 hover:opacity-100"
                                        >
                                          <XIcon className="size-3" />
                                        </button>
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {otherDomains.length > 0 && (
                                <div className="space-y-1">
                                  {sessionHintDomains.length > 0 && (
                                    <div className="text-[10px] uppercase font-semibold text-muted-foreground/80 tracking-wider pt-1">
                                      Other sites:
                                    </div>
                                  )}
                                  <div className="flex flex-wrap gap-1.5">
                                    {otherDomains.map((item) => (
                                      <span
                                        key={item.domain}
                                        className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-background/90 border border-border/70 text-[11px] text-muted-foreground group"
                                      >
                                        <span>{item.domain}</span>
                                        <span className="text-[10px] opacity-60 font-mono">
                                          ({item.cookieCount})
                                        </span>
                                        <button
                                          type="button"
                                          onClick={() =>
                                            handleClearSingleDomain(profile, item.domain)
                                          }
                                          disabled={deletingProfileId !== null}
                                          title={`Clear cookies for ${item.domain}`}
                                          aria-label={`Clear cookies for ${item.domain} in ${profile.label}`}
                                          className="text-muted-foreground hover:text-destructive cursor-pointer opacity-70 hover:opacity-100"
                                        >
                                          <XIcon className="size-3" />
                                        </button>
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </>
                      )}
                    </div>

                    {/* Remembered Website Permissions */}
                    <div className="pt-2 border-t border-border/40">
                      <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                        <ShieldCheckIcon className="size-3 text-foreground" />
                        Website Permissions
                      </div>
                      {permissions.length > 0 ? (
                        <div className="flex flex-wrap gap-1.5">
                          {permissions.map((perm) => (
                            <span
                              key={`${perm.origin}-${perm.permission}`}
                              className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-background/90 border border-border/70 text-[11px] text-foreground group"
                            >
                              <span className="font-mono text-[10px]">{perm.origin}</span>
                              <span className="text-[10px] font-medium text-foreground">
                                {perm.permission}
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  void handleRevokePermission(
                                    profile.id,
                                    perm.origin,
                                    perm.permission,
                                  )
                                }
                                disabled={deletingProfileId !== null}
                                title={`Revoke ${perm.permission} for ${perm.origin}`}
                                aria-label={`Revoke ${perm.permission} for ${perm.origin}`}
                                className="text-muted-foreground hover:text-destructive cursor-pointer opacity-70 hover:opacity-100"
                              >
                                <XIcon className="size-3" />
                              </button>
                            </span>
                          ))}
                        </div>
                      ) : isLoadingPermissions ? (
                        <div
                          className="flex items-center gap-1.5 text-[11px] text-muted-foreground"
                          role="status"
                        >
                          <LoaderCircleIcon className="size-3 animate-spin" aria-hidden="true" />
                          Checking permissions…
                        </div>
                      ) : (
                        <div className="text-[11px] text-muted-foreground/70">
                          No saved permissions.
                        </div>
                      )}
                    </div>

                    <div className="flex justify-end">
                      <Button
                        size="xs"
                        variant="outline"
                        onClick={() => handleClearSessionData(profile)}
                        disabled={isClearing || deletingProfileId !== null}
                        className="h-7 text-xs text-muted-foreground hover:text-foreground cursor-pointer gap-1.5"
                        title="Clear cookies, storage, and log out of all tabs using this profile"
                      >
                        <RotateCcwIcon className={cn("size-3", isClearing && "animate-spin")} />
                        Clear All Sessions
                      </Button>
                    </div>
                  </div>
                </details>
              </div>
            );
          })}
        </div>
      </SettingsSection>

      {/* Native profile-window launcher and stored-site inspector */}
      <Dialog
        open={testingProfile !== null}
        onOpenChange={(open) => {
          if (!open) {
            setTestingProfile(null);
            refreshDomains();
          }
        }}
      >
        <DialogContent showCloseButton={false} className="p-5 space-y-3 sm:max-w-3xl">
          <DialogHeader className="p-0 space-y-1">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className="size-3.5 rounded-full shrink-0 ring-1 ring-border"
                  style={{ backgroundColor: testingProfile?.color || "#3b82f6" }}
                />
                <DialogTitle className="text-base font-semibold truncate">
                  {testingProfile?.label}
                </DialogTitle>
                <Badge variant="outline" className="text-[11px] font-mono shrink-0">
                  profile:{testingProfile?.id}
                </Badge>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <Button
                  size="icon-xs"
                  variant="ghost"
                  onClick={() => {
                    setTestingProfile(null);
                    refreshDomains();
                  }}
                  className="size-7 text-muted-foreground hover:text-foreground cursor-pointer rounded-md hover:bg-accent/60 transition-colors"
                  title="Close"
                  aria-label="Close profile session dialog"
                >
                  <XIcon className="size-4" />
                </Button>
              </div>
            </div>
            <DialogDescription className="text-xs">
              Sign in to websites using this profile’s separate session.
            </DialogDescription>
          </DialogHeader>

          <div
            className="flex items-start gap-2 px-3 py-2.5 bg-muted/30 border border-border/50 rounded-lg text-xs"
            role="note"
          >
            <ShieldCheckIcon
              className="mt-0.5 size-3.5 text-foreground shrink-0"
              aria-hidden="true"
            />
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-muted-foreground text-[11px] leading-relaxed">
                Stored cookies do not confirm sign-in. Some providers require their Tabs
                integration.
              </span>
            </div>
          </div>

          {/* Websites Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              <span>Websites</span>
              <button
                type="button"
                onClick={(event) => {
                  portalOpener.current = event.currentTarget;
                  setIsAddingPortal(true);
                }}
                className="text-xs text-foreground hover:underline font-normal normal-case flex items-center gap-1 cursor-pointer"
              >
                <PlusIcon className="size-3" />
                Add website
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {customPortals.map((item) => (
                <Button
                  key={item.name}
                  size="xs"
                  variant={selectedLoginUrl === item.url ? "default" : "outline"}
                  className="text-xs h-7 gap-1.5 cursor-pointer"
                  onClick={() => {
                    setTestUrl(item.url);
                    setSelectedLoginUrl(item.url);
                  }}
                >
                  <ExternalLinkIcon className="size-3 opacity-70" />
                  {item.name}
                </Button>
              ))}
            </div>

            <Dialog open={isAddingPortal} onOpenChange={setIsAddingPortal}>
              <DialogContent
                className="max-w-sm"
                bottomStickOnMobile={false}
                finalFocus={portalOpener}
              >
                <form
                  onSubmit={(event) => {
                    event.preventDefault();
                    handleAddCustomPortal();
                  }}
                >
                  <DialogHeader>
                    <DialogTitle>Add website</DialogTitle>
                    <DialogDescription>
                      Save a shortcut for signing in with this browser profile.
                    </DialogDescription>
                  </DialogHeader>
                  <DialogPanel className="space-y-4">
                    <label className="block space-y-2 text-sm">
                      <span>Website name</span>
                      <Input
                        value={newPortalName}
                        onChange={(event) => setNewPortalName(event.target.value)}
                        placeholder="Notion"
                        autoFocus
                        required
                      />
                    </label>
                    <label className="block space-y-2 text-sm">
                      <span>Website address</span>
                      <Input
                        value={newPortalUrl}
                        onChange={(event) => setNewPortalUrl(event.target.value)}
                        placeholder="notion.so/login"
                        required
                      />
                    </label>
                  </DialogPanel>
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsAddingPortal(false)}
                    >
                      Cancel
                    </Button>
                    <Button type="submit" disabled={!newPortalName.trim() || !newPortalUrl.trim()}>
                      Save website
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Address Bar */}
          <div className="flex items-center gap-2">
            <Input
              value={testUrl}
              onChange={(e) => setTestUrl(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  if (testingProfile) void openNativeProfileWindow(testingProfile, testUrl);
                }
              }}
              placeholder="Enter URL to log in (e.g. https://chatgpt.com)..."
              className="h-8 text-xs font-mono"
            />
            <Button
              size="xs"
              className="h-8 px-3 text-xs cursor-pointer shrink-0"
              onClick={() =>
                testingProfile && void openNativeProfileWindow(testingProfile, testUrl)
              }
              disabled={loginWindowOpen}
            >
              <ExternalLinkIcon className="size-3.5" />
              {loginWindowOpen ? "Window open…" : "Open native window"}
            </Button>
          </div>

          <div className="rounded-lg border border-border/60 bg-muted/20 p-3 text-xs space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="font-medium text-foreground">Cookie domains</span>
              <span className="text-[11px] text-muted-foreground" aria-live="polite">
                {loginWindowOpen ? "Watching for session changes…" : "Up to date"}
              </span>
            </div>
            {testingProfile && (profileDomains[testingProfile.id]?.length ?? 0) > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {(profileDomains[testingProfile.id] ?? []).map((item) => (
                  <span
                    key={item.domain}
                    className={cn(
                      "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px]",
                      item.hasSessionHint
                        ? "bg-amber-500/10 border border-amber-500/30 text-foreground font-medium"
                        : "bg-background border border-border/70 text-muted-foreground",
                    )}
                  >
                    {item.hasSessionHint && (
                      <span
                        className="size-1.5 rounded-full bg-amber-500 shrink-0"
                        aria-hidden="true"
                      />
                    )}
                    <span>{item.domain}</span>
                    <span className="text-[10px] opacity-70">{item.cookieCount} cookies</span>
                    <button
                      type="button"
                      onClick={() => handleClearSingleDomain(testingProfile, item.domain)}
                      title={`Clear cookies for ${item.domain}`}
                      aria-label={`Clear cookies for ${item.domain}`}
                      className="text-muted-foreground hover:text-destructive cursor-pointer"
                    >
                      <XIcon className="size-3" />
                    </button>
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-[11px] text-muted-foreground">
                No cookie domains detected for this profile.
              </p>
            )}
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-border/40">
            <Button
              size="sm"
              onClick={() => {
                setTestingProfile(null);
                refreshDomains();
              }}
            >
              Done
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create / Edit Profile Dialog */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-sm" finalFocus={profileDialogOpener}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 pr-8">
              <FingerprintIcon className="size-4 text-muted-foreground" aria-hidden="true" />
              {editingProfile ? "Edit profile" : "New browser profile"}
            </DialogTitle>
            <DialogDescription>Keep a separate set of browser logins.</DialogDescription>
          </DialogHeader>
          <DialogPanel className="space-y-4">
            <div className="space-y-1.5">
              <label htmlFor="browser-profile-name" className="text-xs font-medium">
                Name
              </label>
              <Input
                id="browser-profile-name"
                value={labelDraft}
                onChange={(e) => {
                  setLabelDraft(e.target.value);
                  if (!editingProfile) setIdDraft(slugifyProfileId(e.target.value));
                }}
                placeholder="Work, Personal…"
                className="text-xs h-9"
                autoFocus
              />
            </div>
            <fieldset className="space-y-2">
              <legend className="text-xs font-medium">Color</legend>
              <div className="flex flex-wrap items-center gap-2">
                {PRESET_COLORS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    aria-label={`Profile color ${color}`}
                    aria-pressed={colorDraft === color}
                    onClick={() => setColorDraft(color)}
                    className={cn(
                      "size-7 rounded-full transition-shadow cursor-pointer flex items-center justify-center ring-offset-2 ring-offset-background focus-visible:outline-2 focus-visible:outline-ring focus-visible:outline-offset-4",
                      colorDraft === color
                        ? "ring-2 ring-foreground/60"
                        : "hover:ring-2 hover:ring-border",
                    )}
                    style={{ backgroundColor: color }}
                  >
                    {colorDraft === color && (
                      <CheckIcon
                        aria-hidden="true"
                        className="size-3.5 text-white drop-shadow-md"
                      />
                    )}
                  </button>
                ))}
              </div>
            </fieldset>
            <DialogDetails title="More options">
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <label htmlFor="browser-profile-id" className="text-xs font-medium">
                    Identifier
                  </label>
                  <Input
                    id="browser-profile-id"
                    value={idDraft}
                    onChange={(e) => setIdDraft(slugifyProfileId(e.target.value))}
                    disabled={Boolean(editingProfile)}
                    placeholder="work"
                    className="text-xs h-9 font-mono"
                  />
                  <p className="text-[11px] text-muted-foreground">
                    Generated from the name. Cannot change after creation.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <label htmlFor="browser-profile-note" className="text-xs font-medium">
                    Note <span className="text-muted-foreground">(optional)</span>
                  </label>
                  <Input
                    id="browser-profile-note"
                    value={descriptionDraft}
                    onChange={(e) => setDescriptionDraft(e.target.value)}
                    placeholder="What this profile is for"
                    className="text-xs h-9"
                  />
                </div>
              </div>
            </DialogDetails>
          </DialogPanel>
          <DialogFooter variant="bare">
            <Button variant="ghost" size="sm" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleSaveProfile} disabled={!labelDraft.trim()}>
              {editingProfile ? "Save" : "Create profile"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Import Browser Sessions Modal */}
      <Dialog
        open={importModalOpen}
        onOpenChange={(open) => (open ? setImportModalOpen(true) : closeImport())}
      >
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm font-semibold flex items-center gap-2">
              <DownloadIcon className="size-4 text-foreground" />
              Import Browser Session
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              Copy login cookies from an installed browser. Passwords and history stay untouched.
            </DialogDescription>
          </DialogHeader>

          <DialogPanel className="space-y-3 py-2 text-xs">
            {importSources.length === 0 ? (
              <div className="p-4 border rounded-md border-dashed text-center text-muted-foreground">
                No supported desktop browsers detected on this system.
              </div>
            ) : (
              <>
                <div>
                  <label className="text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground block mb-1.5">
                    Source Browser
                  </label>
                  <Select
                    value={selectedSourceId}
                    onValueChange={(nextId) => {
                      if (!nextId) return;
                      const s = importSources.find((src) => src.id === nextId);
                      if (!s) return;
                      setSelectedSourceId(s.id);
                      if (s.profiles.length > 0) {
                        setSelectedProfileDir(s.profiles[0]?.directory ?? "Default");
                      }
                    }}
                  >
                    <SelectTrigger className="w-full h-9 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectPopup>
                      {importSources.map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.name}{" "}
                          {s.unavailable
                            ? `(${s.unavailable === "browserRunning" ? "Running" : "Locked"})`
                            : ""}
                        </SelectItem>
                      ))}
                    </SelectPopup>
                  </Select>
                </div>

                {(() => {
                  const s = importSources.find((src) => src.id === selectedSourceId);
                  if (!s) return null;

                  if (s.unavailable) {
                    const copy =
                      BROWSER_IMPORT_FAILURE_COPY[s.unavailable] ??
                      "Source is currently unavailable.";
                    return (
                      <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-md text-amber-600 dark:text-amber-400 space-y-1">
                        <div className="font-medium flex items-center gap-1.5">
                          Browser database unavailable
                        </div>
                        <div className="text-[11px] leading-relaxed">{copy}</div>
                      </div>
                    );
                  }

                  return (
                    <>
                      {s.profiles.length > 1 && (
                        <div>
                          <label className="text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground block mb-1.5">
                            Browser Profile
                          </label>
                          <Select
                            value={selectedProfileDir}
                            onValueChange={(val) => {
                              if (val) setSelectedProfileDir(val);
                            }}
                          >
                            <SelectTrigger className="w-full h-9 text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectPopup>
                              {s.profiles.map((p) => (
                                <SelectItem key={p.directory} value={p.directory}>
                                  {p.name}
                                </SelectItem>
                              ))}
                            </SelectPopup>
                          </Select>
                        </div>
                      )}

                      <div>
                        <label className="text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground block mb-1.5">
                          Target Tabs Profile
                        </label>
                        <Select
                          value={importTargetProfileId}
                          onValueChange={(val) => {
                            if (val) setImportTargetProfileId(val);
                          }}
                        >
                          <SelectTrigger className="w-full h-9 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectPopup>
                            {profiles.map((p) => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.label} ({p.id})
                              </SelectItem>
                            ))}
                          </SelectPopup>
                        </Select>
                      </div>
                    </>
                  );
                })()}
              </>
            )}

            <p className="text-xs text-muted-foreground">
              Only supported cookies are copied. Passkeys, passwords and local storage stay in the
              source browser.
            </p>
            <DialogDetails title="Import compatibility">
              <p className="pt-2 leading-relaxed">
                Linux requires secret-tool and an unlocked keyring. Windows App-Bound (v20) cookies
                are skipped.
              </p>
            </DialogDetails>
          </DialogPanel>

          <DialogFooter>
            <Button variant="ghost" size="sm" onClick={closeImport}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleRunImport}
              disabled={
                importing ||
                importSources.length === 0 ||
                Boolean(importSources.find((s) => s.id === selectedSourceId)?.unavailable)
              }
            >
              {importing ? "Importing..." : "Import Cookies"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
