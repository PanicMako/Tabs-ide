import { DiagnosticsOverview as ResourcesExplorerOverview } from "./DiagnosticsOverview";
import "./diagnostics.css";
import { OrbitGroup } from "../ui/orbit-group";
import type {
  BackgroundActivityProfile,
  ResourceTelemetryHistory,
  ResourceTelemetryProcess,
  ResourceTelemetrySnapshot,
  ServerProcessDiagnosticsEntry,
  ServerProcessDiagnosticsResult,
  ServerProcessResourceHistoryResult,
  ServerProcessResourceHistorySummary,
  ServerProcessSignal,
  ServerTraceDiagnosticsResult,
} from "@tabs/contracts";
import * as DateTime from "effect/DateTime";
import * as Option from "effect/Option";
import {
  ActivityIcon,
  AlertTriangleIcon,
  CheckIcon,
  ChevronDownIcon,
  ChevronRightIcon,
  ClockIcon,
  CopyIcon,
  CpuIcon,
  DownloadIcon,
  ExternalLinkIcon,
  FileTextIcon,
  FolderOpenIcon,
  GitBranchIcon,
  HardDriveIcon,
  InfoIcon,
  RefreshCwIcon,
  XIcon,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";

import { useConfirm } from "../../hooks/useConfirm";
import { useTheme } from "../../hooks/useTheme";
import { getActiveFontCombo, getFontComboPageHeading } from "../../lib/themes";
import { cn, getHashAwareSearchParams, isPopoutMode } from "../../lib/utils";
import { ensureNativeApi } from "../../nativeApi";
import { formatRelativeTime } from "../../timestampFormat";
import { Button } from "../ui/button";
import { ScrollArea } from "../ui/scroll-area";
import { SegmentedControl, type SegmentOption } from "../ui/segmented-control";
import { Tooltip, TooltipPopup, TooltipTrigger } from "../ui/tooltip";
import { SettingsRow, SettingsSection } from "./SettingsLayout";
import { RendererResponsivenessDiagnostics } from "./RendererResponsivenessDiagnostics";
import { ExpandableText } from "./ExpandableText";
import {
  AttributionTable,
  formatBytes,
  formatCpuTime,
  HISTORY_WINDOWS,
  HistoryProcessTable,
  HostAndCollectionSection,
  ProcessTable,
  ResourceHistoryChart,
  ResourceMonitorHeaderSection,
  safeIsoString,
} from "./ResourceTelemetryDiagnostics";

export type DiagnosticsTabId =
  | "overview"
  | "timeline"
  | "process-tree"
  | "application-io"
  | "live-processes"
  | "traces";

export const TAB_TITLES: Record<DiagnosticsTabId, string> = {
  overview: "Overview",
  timeline: "Resource Timeline",
  "process-tree": "Process Tree",
  "application-io": "Application I/O",
  "live-processes": "Live Processes",
  traces: "Traces",
};

const DIAGNOSTICS_TABS: ReadonlyArray<SegmentOption<DiagnosticsTabId>> = [
  {
    value: "overview",
    label: (
      <span className="flex items-center gap-1.5">
        <ActivityIcon className="size-3.5" />
        <span>Overview</span>
      </span>
    ),
  },
  {
    value: "timeline",
    label: (
      <span className="flex items-center gap-1.5">
        <ClockIcon className="size-3.5" />
        <span>Timeline</span>
      </span>
    ),
  },
  {
    value: "process-tree",
    label: (
      <span className="flex items-center gap-1.5">
        <GitBranchIcon className="size-3.5" />
        <span>Process Tree</span>
      </span>
    ),
  },
  {
    value: "application-io",
    label: (
      <span className="flex items-center gap-1.5">
        <HardDriveIcon className="size-3.5" />
        <span>App I/O</span>
      </span>
    ),
  },
  {
    value: "live-processes",
    label: (
      <span className="flex items-center gap-1.5">
        <CpuIcon className="size-3.5" />
        <span>Processes</span>
      </span>
    ),
  },
  {
    value: "traces",
    label: (
      <span className="flex items-center gap-1.5">
        <FileTextIcon className="size-3.5" />
        <span>Traces</span>
      </span>
    ),
  },
];

export const PRIMARY_POPOUT_TABS: ReadonlyArray<{ id: DiagnosticsTabId; label: string }> = [
  { id: "overview", label: "Overview" },
  { id: "timeline", label: "Timeline" },
  { id: "application-io", label: "App I/O" },
  { id: "traces", label: "Traces" },
  { id: "process-tree", label: "Process Tree" },
  { id: "live-processes", label: "Processes" },
];

function formatCount(value: number): string {
  return value.toLocaleString();
}

function formatDuration(valueMs: number): string {
  if (valueMs < 1_000) return `${Math.round(valueMs)} ms`;
  return `${(valueMs / 1_000).toFixed(valueMs >= 10_000 ? 1 : 2)} s`;
}

function formatRelative(value: unknown): string {
  const iso = safeIsoString(value);
  if (!iso) return "No trace records";
  const { value: val, suffix } = formatRelativeTime(iso);
  return suffix ? `${val} ${suffix}` : val;
}

function formatRelativeNoWrap(value: unknown): string {
  return formatRelative(value).replaceAll(" ", "\u00a0");
}

function shortenTraceId(traceId: string): string {
  if (traceId.length <= 32) return traceId;
  return `${traceId.slice(0, 18)}...${traceId.slice(-10)}`;
}

function StatBlock({
  label,
  value,
  tooltip,
  tone = "default",
}: {
  label: string;
  value: string;
  tooltip?: ReactNode;
  tone?: "default" | "warning" | "danger";
}) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-2xl border border-border/60 bg-card/85 p-3.5 shadow-xs/5 transition-all duration-200 hover:border-border hover:shadow-xs",
        "before:pointer-events-none before:absolute before:inset-0 before:rounded-[calc(var(--radius-2xl)-1px)] before:shadow-[0_1px_--theme(--color-black/4%)] dark:before:shadow-[0_-1px_--theme(--color-white/6%)]",
      )}
    >
      <div className="flex min-w-0 items-center justify-between gap-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/75">
        <span className="min-w-0 truncate">{label}</span>
        {tooltip ? (
          <Tooltip>
            <TooltipTrigger
              render={
                <button
                  type="button"
                  tabIndex={0}
                  className="cursor-help inline-flex size-3.5 shrink-0 items-center justify-center rounded-full text-muted-foreground/60 hover:text-foreground"
                  aria-label={`${label} details`}
                >
                  <InfoIcon className="size-3" />
                </button>
              }
            />
            <TooltipPopup side="top" className="max-w-xs text-left text-xs leading-relaxed">
              {tooltip}
            </TooltipPopup>
          </Tooltip>
        ) : null}
      </div>
      <div
        className={cn(
          "mt-2 truncate font-mono text-2xl font-bold tabular-nums text-foreground tracking-tight",
          tone === "warning" && "text-amber-600 dark:text-amber-400",
          tone === "danger" && "text-destructive",
        )}
      >
        {value}
      </div>
    </div>
  );
}

function StatsGrid({ children }: { children: ReactNode }) {
  return <div className="grid grid-cols-2 gap-3 p-4 sm:grid-cols-4">{children}</div>;
}

function EmptyRows({ label }: { label: string }) {
  return <div className="px-4 py-6 text-center text-xs text-muted-foreground sm:px-5">{label}</div>;
}

function TraceIdCell({ traceId }: { traceId: string }) {
  const [copied, setCopied] = useState(false);

  const copy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(traceId);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {
      // Ignore clipboard error
    }
  }, [traceId]);

  return (
    <div className="flex w-full min-w-0 max-w-full items-center gap-2">
      <Tooltip>
        <TooltipTrigger
          render={
            <span className="min-w-0 flex-1 truncate font-mono text-[11px]">
              {shortenTraceId(traceId)}
            </span>
          }
        />
        <TooltipPopup
          side="top"
          className="flex items-center gap-2 font-mono text-xs text-foreground"
        >
          <span>{traceId}</span>
          <button
            type="button"
            onClick={copy}
            className="cursor-pointer text-muted-foreground hover:text-foreground"
            title="Copy trace ID"
          >
            {copied ? (
              <CheckIcon className="size-3 text-emerald-500" />
            ) : (
              <CopyIcon className="size-3" />
            )}
          </button>
        </TooltipPopup>
      </Tooltip>
      <Tooltip>
        <TooltipTrigger
          render={
            <Button
              size="icon-xs"
              variant="ghost"
              aria-label={copied ? "Copied trace ID" : "Copy trace ID"}
              onClick={() => void copy()}
            >
              {copied ? (
                <CheckIcon className="size-3 text-emerald-500" />
              ) : (
                <CopyIcon className="size-3" />
              )}
            </Button>
          }
        />
        <TooltipPopup side="top">{copied ? "Copied" : "Copy full trace ID"}</TooltipPopup>
      </Tooltip>
    </div>
  );
}

function TraceFilePathPill({ path }: { path: string }) {
  const [copied, setCopied] = useState(false);

  const copy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(path);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Ignore clipboard error
    }
  }, [path]);

  return (
    <span className="inline-flex max-w-full items-center gap-2 rounded-full border border-border/60 bg-muted/40 px-3 py-1 font-mono text-xs text-muted-foreground shadow-2xs">
      <span className="text-muted-foreground/75 shrink-0 uppercase tracking-wider text-[9px] font-semibold font-sans">
        Log
      </span>
      <span className="truncate text-foreground/85 font-mono">{path}</span>
      <button
        type="button"
        onClick={copy}
        className="inline-flex size-4 shrink-0 items-center justify-center rounded text-muted-foreground/70 hover:text-foreground hover:bg-muted/60 transition-colors cursor-pointer"
        title={copied ? "Copied!" : "Copy log file path"}
        aria-label="Copy log file path"
      >
        {copied ? (
          <CheckIcon className="size-3 text-emerald-500" />
        ) : (
          <CopyIcon className="size-3" />
        )}
      </button>
    </span>
  );
}

function DiagnosticsTable({
  headers,
  children,
  minTableWidth = "min-w-[640px]",
  columnWidths,
}: {
  headers: ReadonlyArray<string>;
  children: ReactNode;
  minTableWidth?: string;
  columnWidths?: ReadonlyArray<string>;
}) {
  return (
    <ScrollArea scrollFade className="w-full max-w-full">
      <table className={cn("w-full text-left text-xs", minTableWidth)}>
        {columnWidths ? (
          <colgroup>
            {columnWidths.map((w, idx) => (
              <col key={idx} className={w} />
            ))}
          </colgroup>
        ) : null}
        <thead className="border-b border-border/60 bg-muted/30 text-[11px] uppercase tracking-[0.08em] text-muted-foreground/70">
          <tr>
            {headers.map((header, index) => (
              <th
                key={header}
                scope="col"
                className={cn(
                  "whitespace-nowrap px-4 py-2.5 font-semibold first:sm:pl-5 last:sm:pr-5",
                  !columnWidths && index === headers.length - 1 && "w-px",
                )}
              >
                {header.replaceAll(" ", "\u00a0")}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border/60">{children}</tbody>
      </table>
    </ScrollArea>
  );
}

function formatProcessName(command: string): string {
  const firstToken = command.trim().split(/\s+/)[0];
  if (!firstToken) return command;
  const normalized = firstToken.replace(/^['"]|['"]$/g, "");
  const segments = normalized.split(/[\\/]/).filter(Boolean);
  return segments.at(-1) ?? normalized;
}

function formatProcessType(process: ServerProcessDiagnosticsEntry): string {
  if (process.depth > 0) return "Subprocess";
  if (/\b(codex|claude|opencode|cursor)\b/i.test(process.command)) return "Agent";
  return "Process";
}

function ProcessNameCell({
  process,
  isExpanded,
  onToggle,
}: {
  process: ServerProcessDiagnosticsEntry;
  isExpanded: boolean;
  onToggle: (pid: number) => void;
}) {
  const name = formatProcessName(process.command);
  const hasChildren = process.childPids.length > 0;
  const ChevronIcon = isExpanded ? ChevronDownIcon : ChevronRightIcon;

  return (
    <div
      className="grid min-w-0 grid-cols-[1.25rem_0.375rem_minmax(0,1fr)] items-center gap-2"
      style={{ paddingLeft: `${Math.min(process.depth, 6) * 10}px` }}
    >
      {hasChildren ? (
        <Button
          size="icon-xs"
          variant="ghost"
          aria-label={isExpanded ? `Collapse ${name}` : `Expand ${name}`}
          onClick={() => onToggle(process.pid)}
        >
          <ChevronIcon className="size-3.5" />
        </Button>
      ) : (
        <span className="size-5 shrink-0" aria-hidden="true" />
      )}
      <span className="size-1.5 shrink-0 rounded-full bg-emerald-500/80" />
      <Tooltip>
        <TooltipTrigger
          render={<span className="min-w-0 truncate font-medium text-foreground">{name}</span>}
        />
        <TooltipPopup
          side="top"
          className="max-w-[min(440px,calc(100vw-2rem))] whitespace-normal break-words text-left font-mono text-[11px] leading-relaxed text-wrap"
        >
          {process.command}
        </TooltipPopup>
      </Tooltip>
    </div>
  );
}

function ProcessSignalActions({
  process,
  isSignaling,
  onSignal,
}: {
  process: ServerProcessDiagnosticsEntry;
  isSignaling: boolean;
  onSignal: (pid: number, signal: ServerProcessSignal) => void;
}) {
  return (
    <div className="inline-flex items-center justify-end gap-1.5 shrink-0 whitespace-nowrap">
      <Tooltip>
        <TooltipTrigger
          render={
            <button
              type="button"
              disabled={isSignaling}
              className="cursor-pointer rounded border border-border/60 bg-muted/40 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-muted-foreground/80 hover:border-border hover:bg-muted hover:text-foreground disabled:pointer-events-none disabled:opacity-50 active:scale-95 transition-all"
              onClick={() => onSignal(process.pid, "SIGINT")}
            >
              INT
            </button>
          }
        />
        <TooltipPopup side="top">Send SIGINT (Interrupt) to process {process.pid}</TooltipPopup>
      </Tooltip>
      <Tooltip>
        <TooltipTrigger
          render={
            <button
              type="button"
              disabled={isSignaling}
              className="cursor-pointer rounded border border-destructive/25 bg-destructive/10 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-destructive hover:border-destructive/40 hover:bg-destructive/20 disabled:pointer-events-none disabled:opacity-50 active:scale-95 transition-all"
              onClick={() => onSignal(process.pid, "SIGKILL")}
            >
              KILL
            </button>
          }
        />
        <TooltipPopup side="top">Terminate process {process.pid} with SIGKILL</TooltipPopup>
      </Tooltip>
    </div>
  );
}

function ProcessDiagnosticsTable({
  processes,
  signalingPid,
  onSignal,
  emptyLabel,
}: {
  processes: ReadonlyArray<ServerProcessDiagnosticsEntry>;
  signalingPid: number | null;
  onSignal: (pid: number, signal: ServerProcessSignal) => void;
  emptyLabel?: string;
}) {
  const [collapsedPids, setCollapsedPids] = useState<ReadonlySet<number>>(() => new Set());
  const visibleProcesses = useMemo(() => {
    const visible: ServerProcessDiagnosticsEntry[] = [];
    let hiddenChildDepth: number | null = null;

    for (const process of processes) {
      if (hiddenChildDepth !== null) {
        if (process.depth > hiddenChildDepth) continue;
        hiddenChildDepth = null;
      }

      visible.push(process);
      if (collapsedPids.has(process.pid)) {
        hiddenChildDepth = process.depth;
      }
    }

    return visible;
  }, [collapsedPids, processes]);

  const toggleProcess = useCallback((pid: number) => {
    setCollapsedPids((previous) => {
      const next = new Set(previous);
      if (next.has(pid)) {
        next.delete(pid);
      } else {
        next.add(pid);
      }
      return next;
    });
  }, []);

  return (
    <ScrollArea
      scrollFade
      className="max-h-[min(64vh,44rem)] w-full max-w-full rounded-none border-t border-border/60"
    >
      <table className="w-full min-w-[960px] table-fixed text-left text-xs">
        <colgroup>
          <col className="w-[22%]" />
          <col className="w-[8%]" />
          <col className="w-[10%]" />
          <col className="w-[29%]" />
          <col className="w-[8%]" />
          <col className="w-[11%]" />
          <col className="w-[12%]" />
        </colgroup>
        <thead className="sticky top-0 z-10 border-b border-border/60 bg-muted/40 text-[11px] uppercase tracking-[0.08em] text-muted-foreground/70">
          <tr>
            <th className="px-4 py-2.5 font-semibold sm:pl-5">Name</th>
            <th className="px-3 py-2.5 text-right font-semibold">CPU</th>
            <th className="px-3 py-2.5 text-right font-semibold">Memory</th>
            <th className="px-3 py-2.5 font-semibold">Command</th>
            <th className="px-3 py-2.5 text-right font-semibold">PID</th>
            <th className="px-3 py-2.5 font-semibold">Type</th>
            <th className="p-2.5 text-right font-semibold sm:pr-4">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border/50">
          {visibleProcesses.length === 0 ? (
            <tr>
              <td
                colSpan={7}
                className="px-4 py-6 text-center text-xs text-muted-foreground sm:px-5"
              >
                {emptyLabel ?? "No live descendant processes found."}
              </td>
            </tr>
          ) : null}
          {visibleProcesses.map((process) => (
            <tr key={process.pid} className="hover:bg-muted/20">
              <td className="px-4 py-2 align-middle sm:pl-5">
                <ProcessNameCell
                  process={process}
                  isExpanded={!collapsedPids.has(process.pid)}
                  onToggle={toggleProcess}
                />
              </td>
              <td className="px-3 py-2 text-right align-middle font-mono tabular-nums whitespace-nowrap">
                {process.cpuPercent.toFixed(1)}%
              </td>
              <td className="px-3 py-2 text-right align-middle font-mono tabular-nums whitespace-nowrap">
                {formatBytes(process.rssBytes)}
              </td>
              <td className="px-3 py-2 align-middle text-muted-foreground">
                <Tooltip>
                  <TooltipTrigger
                    render={
                      <span className="block truncate font-mono text-[11px]">
                        {process.command}
                      </span>
                    }
                  />
                  <TooltipPopup
                    side="top"
                    className="max-w-[min(440px,calc(100vw-2rem))] whitespace-normal break-words text-left font-mono text-[11px] leading-relaxed text-wrap"
                  >
                    {process.command}
                  </TooltipPopup>
                </Tooltip>
              </td>
              <td className="px-3 py-2 text-right align-middle font-mono tabular-nums text-muted-foreground whitespace-nowrap">
                {process.pid}
              </td>
              <td className="truncate px-3 py-2 align-middle text-muted-foreground">
                {formatProcessType(process)}
              </td>
              <td className="p-2 align-middle sm:pr-4 whitespace-nowrap">
                <ProcessSignalActions
                  process={process}
                  isSignaling={signalingPid === process.pid}
                  onSignal={onSignal}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </ScrollArea>
  );
}

function ProcessResourceHistoryChart({
  buckets,
}: {
  buckets: ReadonlyArray<{
    readonly startedAt: DateTime.Utc;
    readonly avgCpuPercent: number;
    readonly maxCpuPercent: number;
  }>;
}) {
  if (!buckets || buckets.length === 0) return null;
  const maxCpuPercent = Math.max(1, ...buckets.map((bucket) => bucket.maxCpuPercent));

  return (
    <div className="border-t border-border/60 px-4 py-3 sm:px-5">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground/70">
          Historical CPU Activity
        </span>
        <span className="font-mono text-xs text-muted-foreground">
          Peak {maxCpuPercent.toFixed(1)}%
        </span>
      </div>
      <div className="flex h-24 items-end gap-1 overflow-hidden rounded-md bg-muted/20 p-2">
        {buckets.map((bucket, index) => {
          const peakHeight = Math.max(2, (bucket.maxCpuPercent / maxCpuPercent) * 100);
          const averageHeight = Math.max(2, (bucket.avgCpuPercent / maxCpuPercent) * 100);
          return (
            <Tooltip key={index}>
              <TooltipTrigger
                render={
                  <div className="flex h-full min-w-1 flex-1 items-end">
                    <div
                      className="relative h-full w-full"
                      aria-label={`Average CPU ${bucket.avgCpuPercent.toFixed(1)}%, peak CPU ${bucket.maxCpuPercent.toFixed(1)}%`}
                    >
                      <div
                        className="absolute inset-x-0 bottom-0 rounded-t-xs bg-primary/20 transition-all hover:bg-primary/30"
                        style={{ height: `${peakHeight}%` }}
                      />
                      <div
                        className="absolute inset-x-0 bottom-0 rounded-t-xs bg-primary/70 transition-all hover:bg-primary/90"
                        style={{ height: `${averageHeight}%` }}
                      />
                    </div>
                  </div>
                }
              />
              <TooltipPopup side="top" className="font-mono text-xs">
                Avg {bucket.avgCpuPercent.toFixed(1)}%, peak {bucket.maxCpuPercent.toFixed(1)}%
              </TooltipPopup>
            </Tooltip>
          );
        })}
      </div>
    </div>
  );
}

function ProcessResourceHistoryTable({
  processes,
  emptyLabel,
}: {
  processes: ReadonlyArray<ServerProcessResourceHistorySummary>;
  emptyLabel: string;
}) {
  return (
    <ScrollArea
      scrollFade
      className="max-h-[min(64vh,44rem)] w-full max-w-full border-t border-border/60"
    >
      <table className="w-full min-w-[960px] table-fixed text-left text-xs">
        <colgroup>
          <col className="w-[28%]" />
          <col className="w-[10%]" />
          <col className="w-[10%]" />
          <col className="w-[12%]" />
          <col className="w-[10%]" />
          <col className="w-[10%]" />
          <col className="w-[20%]" />
        </colgroup>
        <thead className="sticky top-0 z-10 border-b border-border/60 bg-muted/40 text-[11px] uppercase tracking-[0.08em] text-muted-foreground/70">
          <tr>
            <th className="px-4 py-2.5 font-semibold sm:pl-5">Process</th>
            <th className="px-3 py-2.5 text-right font-semibold">Avg CPU</th>
            <th className="px-3 py-2.5 text-right font-semibold">Peak CPU</th>
            <th className="px-3 py-2.5 text-right font-semibold">Peak Mem</th>
            <th className="px-3 py-2.5 text-right font-semibold">Samples</th>
            <th className="px-3 py-2.5 text-right font-semibold">PID</th>
            <th className="px-4 py-2.5 font-semibold sm:pr-5">Command</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border/50">
          {processes.length === 0 ? (
            <tr>
              <td
                colSpan={7}
                className="px-4 py-6 text-center text-xs text-muted-foreground sm:px-5"
              >
                {emptyLabel}
              </td>
            </tr>
          ) : null}
          {processes.map((proc) => {
            const name = formatProcessName(proc.command);
            return (
              <tr key={`${proc.pid}:${proc.command}`} className="hover:bg-muted/20">
                <td className="px-4 py-2 font-medium text-foreground sm:pl-5">
                  <div className="flex items-center gap-1.5 truncate">
                    <span
                      className={cn(
                        "size-1.5 shrink-0 rounded-full",
                        proc.isServerRoot ? "bg-amber-500" : "bg-emerald-500",
                      )}
                    />
                    <span className="truncate">{name}</span>
                  </div>
                </td>
                <td className="px-3 py-2 text-right font-mono tabular-nums">
                  {proc.avgCpuPercent.toFixed(1)}%
                </td>
                <td className="px-3 py-2 text-right font-mono tabular-nums">
                  {proc.maxCpuPercent.toFixed(1)}%
                </td>
                <td className="px-3 py-2 text-right font-mono tabular-nums">
                  {formatBytes(proc.maxRssBytes)}
                </td>
                <td className="px-3 py-2 text-right font-mono tabular-nums text-muted-foreground">
                  {proc.sampleCount}
                </td>
                <td className="px-3 py-2 text-right font-mono tabular-nums text-muted-foreground">
                  {proc.pid}
                </td>
                <td className="px-4 py-2 font-mono text-[11px] text-muted-foreground truncate sm:pr-5">
                  <Tooltip>
                    <TooltipTrigger
                      render={<span className="block truncate">{proc.command}</span>}
                    />
                    <TooltipPopup
                      side="top"
                      className="max-w-[min(440px,calc(100vw-2rem))] whitespace-normal break-words text-left font-mono text-[11px] leading-relaxed text-wrap"
                    >
                      {proc.command}
                    </TooltipPopup>
                  </Tooltip>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </ScrollArea>
  );
}

export function DiagnosticsSettings() {
  const { confirm, confirmDialog } = useConfirm();

  // Tab State & Deep-linking
  const [activeTab, setActiveTab] = useState<DiagnosticsTabId>(() => {
    if (typeof window !== "undefined") {
      const urlTab = getHashAwareSearchParams().get("tab") as DiagnosticsTabId | null;
      if (urlTab && DIAGNOSTICS_TABS.some((t) => t.value === urlTab)) {
        return urlTab;
      }
    }
    return "overview";
  });

  const handleTabChange = useCallback((nextTab: DiagnosticsTabId) => {
    setActiveTab(nextTab);
    if (typeof window !== "undefined") {
      const url = new URL(window.location.href);
      url.searchParams.set("tab", nextTab);
      window.history.replaceState(null, "", url.toString());
    }
  }, []);

  // Listen to popstate for browser back/forward
  useEffect(() => {
    const handlePopState = () => {
      const urlTab = getHashAwareSearchParams().get("tab") as DiagnosticsTabId | null;
      if (urlTab && DIAGNOSTICS_TABS.some((t) => t.value === urlTab)) {
        setActiveTab(urlTab);
      }
    };
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  const { fontPreferences } = useTheme();
  const activeFontCombo = useMemo(() => getActiveFontCombo(fontPreferences), [fontPreferences]);
  const isPopout = isPopoutMode();

  const isDarwin = useMemo(() => {
    if (typeof window === "undefined") return false;
    if (window.desktopBridge?.getClientPlatform?.() === "darwin") return true;
    return /Mac|iPhone|iPod|iPad/.test(navigator.platform || navigator.userAgent);
  }, []);

  // Data States
  const [telemetry, setTelemetry] = useState<ResourceTelemetrySnapshot | null>(null);
  const [telemetryHistory, setTelemetryHistory] = useState<ResourceTelemetryHistory | null>(null);
  const [processes, setProcesses] = useState<ServerProcessDiagnosticsResult | null>(null);
  const [history, setHistory] = useState<ServerProcessResourceHistoryResult | null>(null);
  const [traces, setTraces] = useState<ServerTraceDiagnosticsResult | null>(null);
  const [backgroundProfile, setBackgroundProfile] = useState<BackgroundActivityProfile>("balanced");

  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [signalingPid, setSignalingPid] = useState<number | null>(null);
  const [historyWindowIndex, setHistoryWindowIndex] = useState(1); // default 15m

  const [resourceAssessment, setResourceAssessment] = useState<{
    status: "healthy" | "warning" | "unavailable";
    summary: string;
    details: string[];
  } | null>(null);

  const handleQuickResourceCheck = useCallback(() => {
    const resourceSample = telemetry?.groups.allT3;
    if (!resourceSample) {
      setResourceAssessment({
        status: "unavailable",
        summary: "No backend resource sample is available yet.",
        details: [
          "Refresh diagnostics and run this check again when resource metrics have loaded.",
        ],
      });
      return;
    }

    const allCpu = resourceSample.currentCpuPercent;
    const allMemBytes = resourceSample.currentRssBytes;
    const allMemMb = allMemBytes / (1024 * 1024);
    const isHighCpu = allCpu > 70;
    const isHighMem = allMemMb > 2048;

    if (isHighCpu || isHighMem) {
      setResourceAssessment({
        status: "warning",
        summary: "Elevated backend resource footprint detected in the latest sample.",
        details: [
          isHighCpu
            ? `Tabs CPU usage is elevated at ${allCpu.toFixed(1)}%.`
            : "Backend CPU usage is within the configured threshold.",
          isHighMem
            ? `Reported process memory is ${formatBytes(allMemBytes)}. Consider terminating inactive terminal or agent sessions.`
            : "Reported process memory is within the configured threshold.",
          "Renderer interaction and main-thread measurements are shown in the section below.",
        ],
      });
      return;
    }

    setResourceAssessment({
      status: "healthy",
      summary: "No elevated backend CPU or memory use was detected in the latest sample.",
      details: [
        `Reported backend CPU usage is ${allCpu.toFixed(1)}%.`,
        processes
          ? `Reported process memory is ${formatBytes(allMemBytes)} across ${processes.processes.length} active processes.`
          : `Reported process memory is ${formatBytes(allMemBytes)}; process details are unavailable.`,
        "Renderer responsiveness is measured separately below; this check does not assess click latency or UI-thread stalls.",
      ],
    });
  }, [telemetry, processes]);

  const currentHistoryConfig = HISTORY_WINDOWS[historyWindowIndex] ?? HISTORY_WINDOWS[1];

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const api = ensureNativeApi();
      const [
        telemetryResult,
        telemetryHistoryResult,
        processesResult,
        historyResult,
        tracesResult,
        settingsResult,
      ] = await Promise.allSettled([
        api.server.getResourceTelemetry(),
        api.server.getResourceTelemetryHistory({
          windowMs: currentHistoryConfig.windowMs,
          bucketMs: currentHistoryConfig.bucketMs,
        }),
        api.server.getProcessDiagnostics(),
        api.server.getProcessResourceHistory({
          windowMs: currentHistoryConfig.windowMs,
          bucketMs: currentHistoryConfig.bucketMs,
        }),
        api.server.getTraceDiagnostics(),
        api.server.getSettings(),
      ]);

      const failureReasons: string[] = [];

      if (telemetryResult.status === "fulfilled") {
        setTelemetry(telemetryResult.value);
      } else {
        failureReasons.push(
          telemetryResult.reason instanceof Error
            ? telemetryResult.reason.message
            : String(telemetryResult.reason),
        );
      }

      if (telemetryHistoryResult.status === "fulfilled") {
        setTelemetryHistory(telemetryHistoryResult.value);
      }

      if (processesResult.status === "fulfilled") {
        setProcesses(processesResult.value);
      } else {
        failureReasons.push(
          processesResult.reason instanceof Error
            ? processesResult.reason.message
            : String(processesResult.reason),
        );
      }

      if (historyResult.status === "fulfilled") {
        setHistory(historyResult.value);
      }

      if (tracesResult.status === "fulfilled") {
        setTraces(tracesResult.value);
      } else {
        failureReasons.push(
          tracesResult.reason instanceof Error
            ? tracesResult.reason.message
            : String(tracesResult.reason),
        );
      }

      if (settingsResult.status === "fulfilled") {
        const settings = settingsResult.value;
        setBackgroundProfile(
          settings.backgroundActivity.profile === "custom"
            ? (settings.backgroundActivity.baseProfile ?? "balanced")
            : settings.backgroundActivity.profile,
        );
      }

      if (
        telemetryResult.status === "rejected" &&
        processesResult.status === "rejected" &&
        tracesResult.status === "rejected"
      ) {
        setError(failureReasons[0] ?? "Diagnostics could not be loaded.");
      } else {
        setError(null);
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Diagnostics could not be loaded.");
    } finally {
      setLoading(false);
    }
  }, [currentHistoryConfig.bucketMs, currentHistoryConfig.windowMs]);

  // Initial load and periodic refresh every 5s
  useEffect(() => {
    void refresh();
    const interval = setInterval(() => {
      if (typeof document !== "undefined" && document.visibilityState === "visible") {
        void refresh();
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [refresh]);

  const exportSupportBundle = useCallback(async () => {
    setExporting(true);
    try {
      const bundle = await ensureNativeApi().server.createSupportBundle();
      const url = URL.createObjectURL(new Blob([bundle.content], { type: bundle.mediaType }));
      const link = document.createElement("a");
      link.href = url;
      link.download = bundle.filename;
      link.click();
      URL.revokeObjectURL(url);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "The support bundle could not be created.");
    } finally {
      setExporting(false);
    }
  }, []);

  const handleSignalProcess = useCallback(
    async (pid: number, signal: ServerProcessSignal) => {
      if (signal === "SIGKILL") {
        const confirmed = await confirm(
          `Are you sure you want to force terminate process PID ${pid}?`,
        );
        if (!confirmed) return;
      }
      setSignalingPid(pid);
      try {
        await ensureNativeApi().server.signalProcess({ pid, signal });
        await refresh();
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : `Failed to signal process ${pid}.`);
      } finally {
        setSignalingPid(null);
      }
    },
    [confirm, refresh],
  );

  const handleRetrySidecar = useCallback(async () => {
    try {
      await ensureNativeApi().server.retryResourceTelemetry();
      await refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to retry telemetry monitor.");
    }
  }, [refresh]);

  const openLogsDirectory = useCallback(() => {
    if (!traces?.traceFilePath) return;
    const dir = traces.traceFilePath.replace(/[\\/][^\\/]+$/, "");
    if (typeof window !== "undefined" && window.desktopBridge?.openExternal) {
      void window.desktopBridge.openExternal(`file://${dir}`);
    }
  }, [traces?.traceFilePath]);

  const openPopoutWindow = useCallback(() => {
    const width = 780;
    const height = 560;
    const targetUrl = `/settings?section=diagnostics&tab=${activeTab}&popout=true`;
    if (typeof window !== "undefined" && window.desktopBridge?.openPopoutWindow) {
      void window.desktopBridge.openPopoutWindow({
        url: targetUrl,
        title: "Tabs Diagnostics",
        width,
        height,
      });
      return;
    }
    const left = Math.max(0, Math.round((window.screen.width - width) / 2));
    const top = Math.max(0, Math.round((window.screen.height - height) / 2));
    window.open(
      `${window.location.origin}/#${targetUrl}`,
      "tabs_diagnostics_popout",
      `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes`,
    );
  }, [activeTab]);

  useEffect(() => {
    if (isPopout) {
      document.title = `Tabs Diagnostics — ${TAB_TITLES[activeTab] ?? "Overview"}`;
    }
  }, [isPopout, activeTab]);

  return (
    <div
      className={cn(
        "diagnostics-page",
        isPopout ? "diagnostics-popout min-h-screen bg-background text-foreground" : "space-y-5",
      )}
    >
      {/* Native Desktop Popout Window Header (Resources Explorer) */}
      {isPopout ? (
        <header className="drag-region sticky top-0 z-50 flex flex-col w-full border-b border-border/60 bg-background/90 backdrop-blur-md">
          {/* Top Bar: Title & Window Clearance + Action Buttons */}
          <div className="flex h-10 w-full items-center justify-between px-3.5">
            {/* Left: macOS traffic light clearance (pl-[72px] matching traffic lights x:14 y:14) + Title */}
            <div className={cn("flex items-center gap-2", isDarwin ? "pl-[72px]" : "pl-1")}>
              <ActivityIcon className="size-3.5 text-foreground/80 shrink-0" />
              <span className="text-xs font-semibold tracking-tight text-foreground leading-none select-none">
                Diagnostics
              </span>
            </div>

            {/* Right: Actions (no-drag) */}
            <div className="no-drag flex items-center gap-1.5">
              <Button
                size="xs"
                variant="outline"
                onClick={handleQuickResourceCheck}
                className="h-6.5 px-2 text-[11px] cursor-pointer border-primary/40 bg-primary/10 text-foreground hover:bg-primary/20 hover:text-foreground transition-all font-medium"
              >
                <ActivityIcon className="mr-1 size-3" aria-hidden="true" />
                Quick check
              </Button>
              <Button
                size="xs"
                variant="outline"
                disabled={exporting}
                onClick={() => void exportSupportBundle()}
                className="h-6.5 px-2 text-[11px]"
              >
                <DownloadIcon className="mr-1 size-3" />
                {exporting ? "Exporting…" : "Export"}
              </Button>
              <Button
                size="xs"
                variant="outline"
                disabled={loading}
                onClick={() => void refresh()}
                className="h-6.5 px-2 text-[11px]"
              >
                <RefreshCwIcon className={cn("mr-1 size-3", loading && "animate-spin")} />
                Refresh
              </Button>
            </div>
          </div>

          {/* Sub-bar: Trae-style Tab Switcher */}
          <div
            className="no-drag flex items-center gap-1 px-3 py-1.5 border-t border-border/40 bg-muted/15 overflow-x-auto"
            role="group"
            aria-label="Diagnostics section"
          >
            <SegmentedControl
              value={activeTab}
              onValueChange={handleTabChange}
              orbitKind="spotlight"
              options={PRIMARY_POPOUT_TABS.map((tab) => ({ value: tab.id, label: tab.label }))}
              aria-label="Diagnostics section"
              size="sm"
              className="diagnostics-navigation"
            />
          </div>
        </header>
      ) : null}

      <div className={cn("space-y-4", isPopout ? "p-3.5 sm:p-4 w-full" : "space-y-6")}>
        {/* Normal In-Settings Header (Only shown when not in popout) */}
        {!isPopout ? (
          <div data-slot="settings-page-header">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2.5">
                  <h2
                    data-slot="settings-page-title"
                    className={cn(
                      "text-[28px] leading-relaxed pb-1 text-foreground mb-2 font-bold",
                      getFontComboPageHeading(activeFontCombo, fontPreferences).className,
                    )}
                    style={{
                      fontFamily: getFontComboPageHeading(activeFontCombo, fontPreferences)
                        .fontFamily,
                      textTransform: "capitalize",
                    }}
                  >
                    Diagnostics
                  </h2>
                </div>
                <p className="text-sm text-muted-foreground">
                  Find resource-heavy processes and investigate errors.
                </p>
              </div>

              {/* Header Right Actions */}
              <div className="flex items-center gap-2 pt-1">
                <Button
                  size="xs"
                  variant="outline"
                  disabled={exporting}
                  onClick={() => void exportSupportBundle()}
                >
                  <DownloadIcon className="mr-1.5 size-3.5" />
                  {exporting ? "Exporting…" : "Export report"}
                </Button>
                <Button
                  size="xs"
                  variant="outline"
                  disabled={loading}
                  onClick={() => void refresh()}
                >
                  <RefreshCwIcon className={cn("mr-1.5 size-3.5", loading && "animate-spin")} />
                  Refresh
                </Button>
                <div className="h-4 w-px bg-border/60 mx-1" />
                <Tooltip>
                  <TooltipTrigger
                    render={
                      <Button
                        size="xs"
                        variant="outline"
                        onClick={openPopoutWindow}
                        aria-label="Open Diagnostics in new window"
                        className="text-muted-foreground hover:text-foreground hover:border-foreground/30"
                      >
                        <ExternalLinkIcon className="mr-1.5 size-3.5" />
                        Pop out
                      </Button>
                    }
                  />
                  <TooltipPopup side="bottom">Open Diagnostics in a standalone window</TooltipPopup>
                </Tooltip>
              </div>
            </div>

            {/* Canonical Tabs 5px Dual Gradient Divider Line */}
            <div
              data-slot="settings-divider"
              className="h-[5px] w-full my-5 rounded-full dark:block hidden"
              style={{
                background: "linear-gradient(to right, rgba(255,255,255,0.25), transparent)",
              }}
            />
            <div
              data-slot="settings-divider"
              className="h-[5px] w-full my-5 rounded-full dark:hidden block"
              style={{
                background: "linear-gradient(to right, rgba(0,0,0,0.12), transparent)",
              }}
            />

            {/* Reorganized Segmented Navigation */}
            <div className="mt-4 pb-2">
              <SegmentedControl
                value={activeTab}
                onValueChange={(tab) => handleTabChange(tab as DiagnosticsTabId)}
                options={DIAGNOSTICS_TABS}
                aria-label="Diagnostics navigation tabs"
                orbitKind="spotlight"
                className="diagnostics-navigation"
                itemClassName="rounded-xl px-3.5 py-1.5 text-xs transition-all font-medium"
              />
            </div>
          </div>
        ) : null}

        {resourceAssessment ? (
          <div
            className={cn(
              "rounded-xl border p-4 shadow-sm transition-all",
              resourceAssessment.status === "healthy"
                ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-950 dark:text-emerald-100"
                : resourceAssessment.status === "warning"
                  ? "border-amber-500/40 bg-amber-500/10 text-amber-950 dark:text-amber-100"
                  : "border-border bg-muted/30 text-foreground",
            )}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <ActivityIcon
                  className={cn(
                    "size-4 shrink-0 mt-0.5",
                    resourceAssessment.status === "healthy"
                      ? "text-emerald-500"
                      : resourceAssessment.status === "warning"
                        ? "text-amber-500"
                        : "text-muted-foreground",
                  )}
                />
                <div>
                  <div className="text-xs font-semibold tracking-tight">
                    Quick check —{" "}
                    {resourceAssessment.status === "healthy"
                      ? "Within Thresholds"
                      : resourceAssessment.status === "warning"
                        ? "Attention Recommended"
                        : "Metrics Unavailable"}
                  </div>
                  <p className="mt-1 text-xs leading-relaxed opacity-90">
                    {resourceAssessment.summary}
                  </p>
                  <details className="mt-2 text-xs">
                    <summary className="cursor-pointer">Details</summary>
                    <ul className="mt-2 space-y-1 text-[11.5px] opacity-80 list-disc list-inside">
                      {resourceAssessment.details.map((detail, idx) => (
                        <li key={idx}>{detail}</li>
                      ))}
                    </ul>
                  </details>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setResourceAssessment(null)}
                className="text-muted-foreground hover:text-foreground p-1 rounded cursor-pointer"
                aria-label="Dismiss diagnosis"
              >
                <XIcon className="size-3.5" />
              </button>
            </div>
          </div>
        ) : null}

        {error ? (
          <div
            role="alert"
            className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive flex items-center gap-2"
          >
            <AlertTriangleIcon className="size-4 shrink-0" />
            <span>{error}</span>
          </div>
        ) : null}

        {/* TAB 1: OVERVIEW (Sections 1 & 2 + Background Activity Profile) */}
        {activeTab === "overview" ? (
          <div className="space-y-6">
            {/* Trae-style Resources Explorer Cards */}
            <ResourcesExplorerOverview
              snapshot={telemetry}
              onNavigateTab={handleTabChange}
              onQuickCheck={handleQuickResourceCheck}
            />

            <details className="diagnostics-details">
              <summary>
                Collector & host details <span>Sampling, power & monitor status</span>
              </summary>
              {/* Section 1: Resource monitor header section */}
              <ResourceMonitorHeaderSection
                snapshot={telemetry}
                isRefreshing={loading}
                onRefresh={() => void refresh()}
              />

              {/* Section 2: Host & collection section */}
              <HostAndCollectionSection
                snapshot={telemetry}
                isRetrying={loading}
                onRetry={() => void handleRetrySidecar()}
              />
            </details>
            <details className="diagnostics-details">
              <summary>
                Slow interactions <span>Renderer responsiveness</span>
              </summary>
              <RendererResponsivenessDiagnostics />
            </details>
            <details className="diagnostics-details">
              <summary>
                Background activity <span>Power & polling preferences</span>
              </summary>
              {/* Background Activity Profile Settings */}
              <SettingsSection
                title="Background activity"
                description="Balance provider checks and repository refreshes against power consumption for this environment."
              >
                <SettingsRow
                  title="Activity Profile"
                  description="Choose how actively Tabs refreshes in the background."
                  control={
                    <SegmentedControl
                      value={backgroundProfile}
                      onValueChange={async (profile) => {
                        await ensureNativeApi().server.updateSettings({
                          backgroundActivity: { schemaVersion: 1, profile, overrides: {} },
                          backgroundActivityProfile: profile,
                        });
                        setBackgroundProfile(profile);
                      }}
                      options={[
                        { value: "battery-saver", label: "Battery saver" },
                        { value: "balanced", label: "Balanced" },
                        { value: "performance", label: "Performance" },
                      ]}
                      aria-label="Background activity profile"
                    />
                  }
                />
              </SettingsSection>
            </details>
          </div>
        ) : null}

        {/* TAB 2: RESOURCE TIMELINE (Sections 3 & 7) */}
        {activeTab === "timeline" ? (
          <div className="space-y-6">
            {/* Section 3: Resource timeline */}
            <SettingsSection
              title="Resource timeline"
              description="Multi-metric CPU average, I/O read throughput, and I/O write throughput history."
              headerAction={
                <div className="flex items-center gap-1.5">
                  <OrbitGroup
                    className="tabs-segmented inline-flex items-center text-xs rounded-full w-fit"
                    role="group"
                    aria-label="Resource timeline window"
                  >
                    {HISTORY_WINDOWS.map((win, idx) => (
                      <button
                        key={win.label}
                        type="button"
                        onClick={() => setHistoryWindowIndex(idx)}
                        aria-pressed={historyWindowIndex === idx}
                        className={cn(
                          "rounded-full px-2 py-0.5 text-[11px] font-medium transition-colors cursor-pointer",
                          historyWindowIndex === idx
                            ? "bg-background text-foreground shadow-xs font-semibold"
                            : "text-muted-foreground hover:text-foreground",
                        )}
                      >
                        {win.label}
                      </button>
                    ))}
                  </OrbitGroup>
                  <Button size="icon-xs" variant="ghost" onClick={() => void refresh()}>
                    <RefreshCwIcon className={cn("size-3.5", loading && "animate-spin")} />
                  </Button>
                </div>
              }
            >
              <ResourceHistoryChart buckets={telemetryHistory?.buckets ?? []} />
              <HistoryProcessTable processes={telemetryHistory?.topProcesses ?? []} />
            </SettingsSection>

            {/* Section 7: Resource History (Server Root Process Diagnostics History) */}
            <SettingsSection
              title="Server Process History"
              description="Active CPU time and retained in-memory samples for the Tabs backend server root process."
            >
              <StatsGrid>
                <StatBlock
                  label="CPU Time"
                  value={history ? formatCpuTime(history.totalCpuSecondsApprox * 1000) : "—"}
                  tooltip="Approximate active CPU time for the Tabs server root process and its descendants during the window."
                />
                <StatBlock
                  label="Samples"
                  value={history ? formatCount(history.retainedSampleCount) : "—"}
                  tooltip="In-memory process samples retained by the server. Resets when server restarts."
                />
                <StatBlock
                  label="Interval"
                  value={history ? formatDuration(history.sampleIntervalMs) : "—"}
                />
                <StatBlock
                  label="Processes"
                  value={history ? formatCount(history.topProcesses.length) : "—"}
                />
              </StatsGrid>
              {history && history.buckets.length > 0 ? (
                <ProcessResourceHistoryChart buckets={history.buckets} />
              ) : null}
              {history ? (
                <ProcessResourceHistoryTable
                  processes={history.topProcesses}
                  emptyLabel="No process resource samples found for this window."
                />
              ) : null}
            </SettingsSection>
          </div>
        ) : null}

        {/* TAB 3: PROCESS TREE (Section 4) */}
        {activeTab === "process-tree" ? (
          <div className="space-y-6">
            <SettingsSection
              title="Live process tree"
              description="Monitored processes and their children."
              headerAction={
                <Button size="icon-xs" variant="ghost" onClick={() => void refresh()}>
                  <RefreshCwIcon className={cn("size-3.5", loading && "animate-spin")} />
                </Button>
              }
            >
              <ProcessTable
                processes={telemetry?.processes ?? []}
                onSignal={(process: ResourceTelemetryProcess, signal: ServerProcessSignal) => {
                  void handleSignalProcess(process.identity.pid, signal);
                }}
              />
            </SettingsSection>
          </div>
        ) : null}

        {/* TAB 4: APPLICATION I/O (Section 5) */}
        {activeTab === "application-io" ? (
          <div className="space-y-6">
            <SettingsSection
              title="Instrumented application I/O"
              description="Reads and writes attributed to Tabs operations."
              headerAction={
                <Button size="icon-xs" variant="ghost" onClick={() => void refresh()}>
                  <RefreshCwIcon className={cn("size-3.5", loading && "animate-spin")} />
                </Button>
              }
            >
              <AttributionTable entries={telemetry?.attribution?.entries ?? []} />
            </SettingsSection>
          </div>
        ) : null}

        {/* TAB 5: LIVE PROCESSES (Section 6) */}
        {activeTab === "live-processes" ? (
          <div className="space-y-6">
            <SettingsSection
              title="Live Processes"
              description="Processes started by the active server."
              headerAction={
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-muted-foreground font-mono">
                    Checked {formatRelative(processes?.readAt ?? null)}
                  </span>
                  <Button size="icon-xs" variant="ghost" onClick={() => void refresh()}>
                    <RefreshCwIcon className={cn("size-3.5", loading && "animate-spin")} />
                  </Button>
                </div>
              }
            >
              <StatsGrid>
                <StatBlock
                  label="Child Processes"
                  value={processes ? formatCount(processes.processCount) : "—"}
                />
                <StatBlock
                  label="Aggregate CPU"
                  value={processes ? `${processes.totalCpuPercent.toFixed(1)}%` : "—"}
                />
                <StatBlock
                  label="Aggregate Memory"
                  value={processes ? formatBytes(processes.totalRssBytes) : "—"}
                />
                <StatBlock
                  label="Server PID"
                  value={processes ? String(processes.serverPid) : "—"}
                />
              </StatsGrid>
              {processes && Option.isSome(processes.error) ? (
                <p
                  role="alert"
                  className="border-t border-border/60 px-4 py-3 text-xs text-destructive sm:px-5"
                >
                  {processes.error.value.message}
                </p>
              ) : null}
              <ProcessDiagnosticsTable
                processes={processes?.processes ?? []}
                signalingPid={signalingPid}
                onSignal={(pid, signal) => void handleSignalProcess(pid, signal)}
                emptyLabel="No live descendant processes found."
              />
            </SettingsSection>
          </div>
        ) : null}

        {/* TAB 6: TRACES (Section 8) */}
        {activeTab === "traces" ? (
          <div className="space-y-6">
            <SettingsSection
              title="Trace Diagnostics"
              description={
                traces?.traceFilePath ? (
                  <TraceFilePathPill path={traces.traceFilePath} />
                ) : (
                  "Trace storage is loading…"
                )
              }
              headerAction={
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-muted-foreground font-mono">
                    Checked {formatRelative(traces?.readAt ?? null)}
                  </span>
                  <Tooltip>
                    <TooltipTrigger
                      render={
                        <Button
                          size="icon-xs"
                          variant="ghost"
                          disabled={!traces?.traceFilePath}
                          onClick={openLogsDirectory}
                          aria-label="Open logs folder"
                        >
                          <FolderOpenIcon className="size-3.5" />
                        </Button>
                      }
                    />
                    <TooltipPopup side="top">Open logs folder</TooltipPopup>
                  </Tooltip>
                  <Button size="icon-xs" variant="ghost" onClick={() => void refresh()}>
                    <RefreshCwIcon className={cn("size-3.5", loading && "animate-spin")} />
                  </Button>
                </div>
              }
            >
              <StatsGrid>
                <StatBlock label="Spans" value={traces ? formatCount(traces.recordCount) : "—"} />
                <StatBlock
                  label="Failures"
                  value={traces ? formatCount(traces.failureCount) : "—"}
                  tone={traces && traces.failureCount > 0 ? "danger" : "default"}
                />
                <StatBlock
                  label="Slow Spans"
                  value={traces ? formatCount(traces.slowSpanCount) : "—"}
                  tooltip={
                    traces
                      ? `Spans with a duration of ${formatDuration(traces.slowSpanThresholdMs)} or longer.`
                      : "Spans at or above the configured slow-span threshold."
                  }
                  tone={traces && traces.slowSpanCount > 0 ? "warning" : "default"}
                />
                <StatBlock
                  label="Parse Errors"
                  value={traces ? formatCount(traces.parseErrorCount) : "—"}
                  tone={traces && traces.parseErrorCount > 0 ? "warning" : "default"}
                />
              </StatsGrid>
              {traces && Option.isSome(traces.error) ? (
                <p
                  role="alert"
                  className="border-t border-border/60 px-4 py-3 text-xs text-destructive sm:px-5"
                >
                  {traces.error.value.message}
                </p>
              ) : null}
              {traces && Option.isSome(traces.partialFailure) ? (
                <p
                  role="status"
                  className="border-t border-border/60 px-4 py-3 text-xs text-amber-500 sm:px-5"
                >
                  Some rotated trace files could not be read, so these diagnostics may be
                  incomplete.
                </p>
              ) : null}
            </SettingsSection>

            {/* Latest Failures Table with Expandable Full Error Stack */}
            <details className="diagnostics-details">
              <summary>Latest Failures</summary>
              <SettingsSection title="Latest Failures">
                {traces && traces.latestFailures.length > 0 ? (
                  <DiagnosticsTable headers={["Span", "Cause", "Duration", "Ended"]}>
                    {traces.latestFailures.map((failure) => (
                      <tr key={`${failure.traceId}:${failure.spanId}`}>
                        <td className="px-4 py-3 align-top text-xs font-medium text-foreground first:sm:pl-5">
                          {failure.name}
                        </td>
                        <td className="max-w-[420px] px-4 py-3 align-top text-muted-foreground">
                          <ExpandableText text={failure.cause} />
                        </td>
                        <td className="px-4 py-3 align-top font-mono tabular-nums">
                          {formatDuration(failure.durationMs)}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3 align-top font-mono tabular-nums text-muted-foreground last:sm:pr-5">
                          {formatRelativeNoWrap(failure.endedAt)}
                        </td>
                      </tr>
                    ))}
                  </DiagnosticsTable>
                ) : (
                  <EmptyRows label={loading ? "Loading failures..." : "No failed spans found."} />
                )}
              </SettingsSection>
            </details>

            {/* Most Common Failures */}
            <details className="diagnostics-details">
              <summary>Most Common Failures</summary>
              <SettingsSection title="Most Common Failures">
                {traces && traces.commonFailures.length > 0 ? (
                  <DiagnosticsTable
                    headers={["Span", "Count", "Cause", "Last Seen"]}
                    minTableWidth="min-w-[760px]"
                  >
                    {traces.commonFailures.map((failure) => (
                      <tr key={`${failure.name}:${failure.cause}`}>
                        <td className="px-4 py-3 align-top text-xs font-medium text-foreground first:sm:pl-5">
                          {failure.name}
                        </td>
                        <td className="px-4 py-3 align-top font-mono tabular-nums">
                          {formatCount(failure.count)}
                        </td>
                        <td className="max-w-[420px] px-4 py-3 align-top text-muted-foreground">
                          <ExpandableText text={failure.cause} />
                        </td>
                        <td className="w-px whitespace-nowrap px-4 py-3 align-top font-mono tabular-nums text-muted-foreground last:sm:pr-5">
                          {formatRelativeNoWrap(failure.lastSeenAt)}
                        </td>
                      </tr>
                    ))}
                  </DiagnosticsTable>
                ) : (
                  <EmptyRows
                    label={loading ? "Loading failure groups..." : "No repeated failures found."}
                  />
                )}
              </SettingsSection>
            </details>

            {/* Slowest Spans */}
            <details className="diagnostics-details">
              <summary>Slowest Spans</summary>
              <SettingsSection title="Slowest Spans">
                {traces && traces.slowestSpans.length > 0 ? (
                  <DiagnosticsTable
                    headers={["Span", "Duration", "Ended", "Trace"]}
                    minTableWidth="min-w-[900px]"
                    columnWidths={["w-[40%]", "w-[15%]", "w-[15%]", "w-[30%]"]}
                  >
                    {traces.slowestSpans.map((span) => (
                      <tr key={`${span.traceId}:${span.spanId}`}>
                        <td className="px-4 py-3 align-top text-xs font-medium text-foreground first:sm:pl-5">
                          {span.name}
                        </td>
                        <td className="px-4 py-3 align-top font-mono tabular-nums">
                          {formatDuration(span.durationMs)}
                        </td>
                        <td className="w-px whitespace-nowrap px-4 py-3 align-top font-mono tabular-nums text-muted-foreground">
                          {formatRelativeNoWrap(span.endedAt)}
                        </td>
                        <td className="min-w-0 whitespace-nowrap px-4 py-3 align-top text-muted-foreground last:sm:pr-5">
                          <TraceIdCell traceId={span.traceId} />
                        </td>
                      </tr>
                    ))}
                  </DiagnosticsTable>
                ) : (
                  <EmptyRows label={loading ? "Loading slow spans..." : "No slow spans found."} />
                )}
              </SettingsSection>
            </details>

            {/* Top Span Names */}
            <details className="diagnostics-details">
              <summary>Top Span Names</summary>
              <SettingsSection title="Top Span Names">
                {traces && traces.topSpansByCount.length > 0 ? (
                  <DiagnosticsTable headers={["Span", "Count", "Failures", "Average Duration"]}>
                    {traces.topSpansByCount.map((span) => (
                      <tr key={span.name} className="hover:bg-muted/20">
                        <td className="px-4 py-2.5 font-mono text-foreground/90 first:sm:pl-5">
                          {span.name}
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums">
                          {formatCount(span.count)}
                        </td>
                        <td
                          className={cn(
                            "px-3 py-2.5 text-right font-mono tabular-nums",
                            span.failureCount > 0 && "font-medium text-destructive",
                          )}
                        >
                          {span.failureCount}
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono tabular-nums text-muted-foreground last:sm:pr-5">
                          {span.averageDurationMs.toFixed(1)} ms
                        </td>
                      </tr>
                    ))}
                  </DiagnosticsTable>
                ) : (
                  <EmptyRows label={loading ? "Loading span counts..." : "No spans recorded."} />
                )}
              </SettingsSection>
            </details>
          </div>
        ) : null}
      </div>
      {/* useConfirm Modal Dialog */}
      {confirmDialog}
    </div>
  );
}
