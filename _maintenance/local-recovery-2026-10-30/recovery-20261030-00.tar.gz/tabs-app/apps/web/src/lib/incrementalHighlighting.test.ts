import { toHtml } from "hast-util-to-html";
import { disposeHighlighter, getSharedHighlighter } from "@pierre/diffs";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

import { createIncrementalHighlightedDocument } from "./incrementalHighlighting";

const samples = {
  typescript: "/* multi\nline comment */\nconst x = `template\n${1 + 2}`;\nconst re = /abc/;\n",
  python: '#!/usr/bin/python\nx = """multi\nline"""\nprint(x)\n',
  bash: "#!/bin/bash\ncat <<EOF\nhello\nEOF\necho hi\n",
  html: "<script>\nconst x = 1;\n</script>\n<style>\np {color:red;}\n</style>\n",
  markdown: "# heading\n\n```ts\nconst a = 1;\n```\n\ntext\n",
  rust: 'fn main() {\n let x = r#"multi\nline"#;\n}\n',
  tsx: 'const element = <div\n className="x">\n{value}\n</div>;\n',
  json: '{\n "value": [1,\n 2, 3]\n}\n',
  yaml: "key: |\n  multiline\n  value\nnext: true\n",
  css: '/* comment\n continued */\np::before {\n content: "text";\n}\n',
  sql: "SELECT 'multi\nline'\nFROM table_name;\n",
} as const;

const highlighterOptions = {
  langs: Object.keys(samples) as Array<keyof typeof samples>,
  themes: ["pierre-dark", "pierre-light"],
};

describe.each(["shiki-wasm", "highlights"] as const)(
  "incremental code highlighting (%s)",
  (engine) => {
    beforeAll(() => disposeHighlighter());
    afterAll(() => disposeHighlighter());
    it.each(Object.entries(samples))(
      "matches full HTML at every streaming prefix in %s",
      async (language, code) => {
        const highlighter = await getSharedHighlighter({
          ...highlighterOptions,
          preferredHighlighter: engine,
        });
        for (const theme of ["pierre-dark", "pierre-light"] as const) {
          const highlight = createIncrementalHighlightedDocument(highlighter, language, theme);
          for (let end = 0; end <= code.length; end++) {
            const text = code.slice(0, end);
            expect(toHtml(highlight(text)), `${theme}, prefix ${end}`).toBe(
              highlighter.codeToHtml(text, { lang: language, theme }),
            );
          }
          highlight.dispose();
        }
      },
    );

    it("resets after edits and truncation, including edits to a completed line", async () => {
      const highlighter = await getSharedHighlighter({
        ...highlighterOptions,
        preferredHighlighter: engine,
      });
      const highlight = createIncrementalHighlightedDocument(
        highlighter,
        "typescript",
        "pierre-dark",
      );
      const inputs = [
        "/* open\ncomment\n",
        "/* open\ncomment\n*/\nconst x = 1;",
        "const edited = 2;\nconst x = 1;",
        "const edited = 2;\nconst x = 10;",
        "const edited = 2;\n",
        "",
        "\n\n\nconst fresh = true;\n",
      ];
      for (const text of inputs) {
        expect(toHtml(highlight(text))).toBe(
          highlighter.codeToHtml(text, { lang: "typescript", theme: "pierre-dark" }),
        );
      }
      highlight.dispose();
    });

    // MarkdownCodeBlock creates the document outside its plain-text fallback.
    it("creates a document for a language the highlighter has not loaded", async () => {
      const highlighter = await getSharedHighlighter({
        ...highlighterOptions,
        preferredHighlighter: engine,
      });
      expect(() =>
        createIncrementalHighlightedDocument(highlighter, "cobol", "pierre-dark").dispose(),
      ).not.toThrow();
    });

    it("preserves partial CRLF and CR line endings", async () => {
      const highlighter = await getSharedHighlighter({
        ...highlighterOptions,
        preferredHighlighter: engine,
      });
      const highlight = createIncrementalHighlightedDocument(
        highlighter,
        "typescript",
        "pierre-dark",
      );
      const code = "/* multi\r\nline */\r\nconst x = 1;\r\n";
      for (let end = 0; end <= code.length; end++) {
        const text = code.slice(0, end);
        expect(toHtml(highlight(text))).toBe(
          highlighter.codeToHtml(text, { lang: "typescript", theme: "pierre-dark" }),
        );
      }
    });
  },
);
