import type { DesktopInstalledExtension, ProjectToolDefinition } from "@tabs/contracts";
import { isExtensionEnabledForProject } from "@tabs/shared/extensions";

/** A toolbar preference belongs to the package's source, not merely its name. */
export function extensionToolbarToolId(
  extension: Pick<DesktopInstalledExtension, "id" | "source" | "registryOrigin">,
  toolId: string,
): string {
  const origin = extension.registryOrigin ?? extension.source;
  return `ext:${encodeURIComponent(origin)}:${extension.id}:${toolId}`;
}

/** Keep the saved order and visibility, but take identity and labels from verified packages. */
export function mergeExtensionToolbarTools(
  savedTools: readonly ProjectToolDefinition[],
  installedExtensions: readonly DesktopInstalledExtension[],
  projectId: string,
  includeUnassigned = false,
): ProjectToolDefinition[] {
  const available = new Map<string, ProjectToolDefinition>();
  for (const extension of installedExtensions) {
    const enabled =
      !extension.revoked &&
      !extension.disabled &&
      isExtensionEnabledForProject(extension.assignment, projectId);
    if (!includeUnassigned && !enabled) continue;
    for (const tool of extension.manifest.contributes.tools) {
      const definition: ProjectToolDefinition = {
        id: extensionToolbarToolId(extension, tool.id),
        kind: "extension",
        label: tool.label,
        visible: enabled,
        extensionId: extension.id,
        extensionToolId: tool.id,
      };
      available.set(definition.id, definition);
    }
  }

  const merged: ProjectToolDefinition[] = [];
  for (const saved of savedTools) {
    if (saved.kind !== "extension") {
      merged.push(saved);
      continue;
    }
    const verified = available.get(saved.id);
    if (
      !verified ||
      saved.extensionId !== verified.extensionId ||
      saved.extensionToolId !== verified.extensionToolId
    )
      continue;
    available.delete(saved.id);
    merged.push({ ...verified, visible: saved.visible && verified.visible });
  }
  return [...merged, ...available.values()];
}

/** Keep preferences for temporarily disabled tools when another toolbar item is edited. */
export function preserveUnavailableExtensionTools(
  original: readonly ProjectToolDefinition[],
  available: readonly ProjectToolDefinition[],
): ProjectToolDefinition[] {
  const availableIds = new Set(available.map((tool) => tool.id));
  return [
    ...available,
    ...original.filter((tool) => tool.kind === "extension" && !availableIds.has(tool.id)),
  ];
}
