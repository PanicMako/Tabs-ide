import { readFileSync } from "node:fs";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { loadConfig } from "./config";

beforeEach(() => {
  for (const [key, value] of Object.entries({
    EXCHANGE_ORIGIN: "http://localhost:8787",
    GITHUB_CLIENT_ID: "test-client",
    GITHUB_CLIENT_SECRET: "test-secret",
    S3_BUCKET: "test-bucket",
    EXCHANGE_OPERATOR_GITHUB_IDS: "",
    EXCHANGE_ADMIN_GITHUB_IDS: "",
    EXCHANGE_ALLOWED_GITHUB_IDS: "",
    EXCHANGE_VISIBILITY: "public",
    EXCHANGE_PUBLISHING_ENABLED: "false",
  }))
    vi.stubEnv(key, value);
});
afterEach(() => vi.unstubAllEnvs());
it("permits an operator without granting legacy reviewer access and normalizes explicit numeric identities", () => {
  vi.stubEnv("EXCHANGE_OPERATOR_GITHUB_IDS", " 123,456,123 ");
  const config = loadConfig();
  expect([...config.operatorGithubIds!]).toEqual(["123", "456"]);
  expect(config.adminGithubIds.size).toBe(0);
  expect(config.publishingEnabled).toBe(false);
  vi.stubEnv("EXCHANGE_ADMIN_GITHUB_IDS", " 789, 987 ");
  expect([...loadConfig().adminGithubIds]).toEqual(["789", "987"]);
});
it("rejects ambiguous account identifiers in every configured role", () => {
  for (const name of [
    "EXCHANGE_OPERATOR_GITHUB_IDS",
    "EXCHANGE_ADMIN_GITHUB_IDS",
    "EXCHANGE_ALLOWED_GITHUB_IDS",
  ]) {
    for (const value of ["username", "0", "-1", "01", "1.5", "12,username"]) {
      vi.stubEnv(name, value);
      expect(() => loadConfig()).toThrow(`${name} requires numeric GitHub IDs.`);
    }
    vi.stubEnv(name, "");
  }
});
it("requires a private registry allowlist independently of operator privileges", () => {
  vi.stubEnv("EXCHANGE_VISIBILITY", "private");
  vi.stubEnv("EXCHANGE_OPERATOR_GITHUB_IDS", "123");
  expect(() => loadConfig()).toThrow("explicit GitHub numeric ID allowlist");
  vi.stubEnv("EXCHANGE_ALLOWED_GITHUB_IDS", "123");
  expect(loadConfig().allowedGithubIds?.has("123")).toBe(true);
});
it("accepts canonical HTTPS origins and rejects credentials, subpaths, and non-HTTP localhost schemes", () => {
  vi.stubEnv("EXCHANGE_ORIGIN", "https://exchange.example.test");
  expect(loadConfig().origin).toBe("https://exchange.example.test");
  for (const origin of [
    "https://private:secret@example.test",
    "https://example.test/exchange",
    "https://example.test?q=x",
    "https://example.test#x",
    "ftp://localhost",
    "http://example.test",
  ]) {
    vi.stubEnv("EXCHANGE_ORIGIN", origin);
    expect(() => loadConfig()).toThrow(/EXCHANGE_ORIGIN/);
  }
});
it("passes operator and reviewer settings to both deployed registry processes", () => {
  const compose = readFileSync(new URL("../compose.yaml", import.meta.url), "utf8");
  for (const service of ["api", "worker"]) {
    const block = compose.split(`\n  ${service}:`)[1]!.split(/\n(?:  \w|volumes:)/)[0]!;
    expect(block).toContain("EXCHANGE_OPERATOR_GITHUB_IDS: ${EXCHANGE_OPERATOR_GITHUB_IDS:-}");
    expect(block).toContain("EXCHANGE_ADMIN_GITHUB_IDS: ${EXCHANGE_ADMIN_GITHUB_IDS:-}");
    expect(block).toContain("EXCHANGE_PUBLISHING_ENABLED: ${EXCHANGE_PUBLISHING_ENABLED:-false}");
  }
});
