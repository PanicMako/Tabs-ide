# Tabs IDE — Upstream T3 Parity Code Handoff for Codex

> **Purpose**: Authoritative review entry point, architectural change map, and independent inspection guide for Codex.  
> **Pinned Upstream Commit**: [`76d3c96fd5b89cca2c06aeaceaea16100c75084a`](https://github.com/pingdotgg/t3code)  
> **Tabs Implementation Baseline**: `117643e40e33ee3a897bd00571186f9c674c25a7`  
> **Dedicated Task Worktree**: `/Users/rushil.dev/Desktop/tabs/.worktrees/t3-parity-goal-2026-10-06/tabs-app`  
> **Dedicated Task Branch**: `codex/t3-parity-goal-2026-10-06`  
> **Review Diff Base**: `117643e40e33ee3a897bd00571186f9c674c25a7`  
> **Inherited Dirty Baseline**: `.logs/antigravity-audit/claude-handoff-baseline/`  
> **Branch HEAD**: `bb89383e8516d6ee6c730579be3e353a8e43a0e9`  
> **Status**: Ready for Codex Independent Audit Verification

---

## 1. Branch, Inherited Baseline & Changes Made

### 1.1 Inherited Work (Preserved from Baseline)

The inherited worktree contained substantial completed repairs by Codex, preserved intact:

- Single Effect `4.0.0-rc.112` runtime migration across monorepo packages.
- Modern per-instance Codex, Claude, Cursor, Grok, and OpenCode driver assemblies.
- Published migrations 1–57 preserved; additive migration 58 (`ProjectionCompatibilityRepairs`) added.
- Modern HTTP MCP transport and extension broker integration.
- Secondary environment PTY isolation foundations.
- All 52 Testing RPC operations implemented on modern RPC.

### 1.2 Continuation Changes Made in This Assignment

Every change made in this session was targeted and validated without indiscriminate commits or destructive operations:

1. **Track 0 (Copilot V2 ACP Protocol Repair)**:
   - `apps/server/src/provider/acp/CopilotAcpSupport.ts`: Replaced fictitious `runtime.getProtocolVersion` with explicit `protocolVersion?: number` parameter; handled Protocol 1 (`options.modelSelection`) vs Protocol 2 (`options.model`) selection cleanly.
   - Callers updated in `CopilotAdapter.ts`, `CopilotDriver.ts`, and `CopilotAdapterV2.ts`.
2. **Track 1 (V2 Runtime Shipped End-to-End)**:
   - Verified `bin.mjs` and `binCli.ts` V2 entrypoint cutover.
   - `apps/web/src/wsTransport.ts`: Handled resumable WebSocket RPC streams and chunk validation.
3. **Track 2 (Durable Composer Queue & Client Store Migration)**:
   - `apps/server/src/orchestration-v2/ComposerQueueWorker.ts`: Validated server queue worker (scheduling, dead-letter recovery, idempotency).
   - `apps/web/src/stores/messageQueueStore.ts`: Implemented queue store migration for legacy local entries, attachments, and scheduled states.
4. **Track 3 (Full V2 Provider Integrations)**:
   - `apps/server/src/orchestration-v2/Adapters/OpenCodeAdapterV2.ts`: Parameterized engine and provider identity for OpenCode, Kilo, and Droid.
   - `apps/server/src/orchestration-v2/Adapters/KiloAdapterV2.ts` & `KiloAdapterV2.test.ts`: Created Kilo V2 adapter and tests.
   - `apps/server/src/orchestration-v2/Adapters/DroidAdapterV2.ts` & `DroidAdapterV2.test.ts`: Created Droid V2 adapter and tests.
   - `apps/server/src/orchestration-v2/builtInProviderAdapterDrivers.ts`: Registered `CopilotAdapterV2Driver`, `OpenCodeAdapterV2Driver`, `KiloAdapterV2Driver`, and `DroidAdapterV2Driver`.
   - Preserved text-generation-only behavior for `GeminiDriver` and `OpenRouterDriver`.
5. **Track 4 (Ownership, Security, PTY Isolation, Shutdown & Acceptance)**:
   - `apps/server/src/terminal/SecondaryEnvironmentPty.integration.test.ts`: Verified real environment PTY isolation.
   - `apps/server/src/testing/{execution.ts, generator.ts, TestingService.ts, TestingRuntime.ts}`: Added abort controllers and async cleanup awaiting to prevent late writes to closed stores.
   - `apps/server/src/provider/acp/AntigravityClientFiles.ts` & `AntigravityClientFiles.test.ts`: Hardened with `O_NOFOLLOW` and post-open `dev`/`ino` verification against re-resolved canonical root path. Added negative race tests.
   - `apps/server/src/workspace/WorkspaceFileSystem.ts`: Hardened `readFile` and `writeFile` with `O_NOFOLLOW` and post-open `dev`/`ino` verification.
   - Packaged desktop build & smoke test verified via `apps/desktop/scripts/smoke-test.mjs`.
6. **Track 5 (Audit Ledgers & Pre-Flight Gates)**:
   - Updated `docs/t3-parity/independent-audit/scope.json`, `file-review.json` (954 entries with SHA256 hashes), `production-repair-status.json`, and `production-decision.md`.

---

## 2. Requirement-to-Evidence Matrix

| Requirement Area                     | Status    | Concrete Verification Evidence                                                                                                                                                                                        |
| ------------------------------------ | --------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Effect rc.112 runtime**            | Completed | `bun run check:effect-versions` exits 0; single resolved `4.0.0-rc.112`.                                                                                                                                              |
| **Copilot V2 ACP Protocol**          | Completed | 18/18 tests pass (`CopilotAcpSupport.test.ts`, `CopilotAdapterV2.test.ts`). Log: `.logs/antigravity-audit/claude-copilot-typecheck-fix.log`.                                                                          |
| **V2 Entrypoint & Transport**        | Completed | `ws.test.ts` passes 8/8; `bin.mjs` / `binCli.ts` V2 entrypoint clean.                                                                                                                                                 |
| **Durable Composer Queue**           | Completed | `ComposerQueueWorker.test.ts` passes 6/6; `messageQueueStore.test.ts` passes 11/11; Web test suite passes 1563/1563.                                                                                                  |
| **Kilo / Droid V2 Adapters**         | Completed | `KiloAdapterV2.test.ts` passes 2/2; `DroidAdapterV2.test.ts` passes 4/4; `OpenCodeAdapterV2.test.ts` passes 47/47. Log: `.logs/antigravity-audit/claude-provider-integrations.log`.                                   |
| **Gemini / OpenRouter Preservation** | Completed | Text-generation-only preserved in `builtInProviderAdapterDrivers.ts` without unsupported agent tool execution.                                                                                                        |
| **Secondary PTY Isolation**          | Completed | `SecondaryEnvironmentPty.integration.test.ts` passes 1/1 with process/cwd isolation.                                                                                                                                  |
| **Testing Service Shutdown**         | Completed | `execution.test.ts` and `generator.test.ts` pass 11/11; `TestingService.close()` awaits active browser sessions.                                                                                                      |
| **Filesystem Race Hardening**        | Completed | `O_NOFOLLOW` + post-open dev/ino check in `AntigravityClientFiles.ts` (6/6 tests pass) and `WorkspaceFileSystem.ts` (13/13 tests pass).                                                                               |
| **Database Migrations 1–58**         | Completed | `ProjectSettingsUpgrade.integration.test.ts` (migrations 1–58 pass), `reconcileV2PreviewMigration.test.ts` (5/5 pass), `LegacyV1Cutover.integration.test.ts` (1/1 pass).                                              |
| **Claude Provider Continuation**     | Completed | `ClaudeAdapterV2.test.ts` passes 143/143 tests (wake handling, subagent continuation, approval buffering).                                                                                                            |
| **Packaged Desktop Acceptance**      | Completed | Electron build clean; `smoke-test.mjs` exit 0; readiness probes pass 8/8 (`browserReadiness.test.ts`); clean shutdown passes 6/6; 0 orphaned processes. Log: `.logs/antigravity-audit/claude-desktop-acceptance.log`. |
| **Pre-Flight Gates**                 | Completed | `vp check` exit 0 (0 errors); `vp run typecheck` exit 0 (14/14 packages passed).                                                                                                                                      |
| **Labs / Native Mobile**             | Excluded  | Excluded per task specification.                                                                                                                                                                                      |

---

## 3. Exact Commands, Exit Codes & Test Totals

1. **Effect Versions Check**:
   - Command: `bun run check:effect-versions`
   - Exit Code: `0`
   - Output: `Resolved Effect version: 4.0.0-rc.112`
2. **Repository Lint & Formatting**:
   - Command: `vp check`
   - Exit Code: `0`
   - Output: `0 errors, 659 warnings across 3431 files; pass: Formatting completed`
3. **Workspace Typecheck**:
   - Command: `vp run typecheck`
   - Exit Code: `0`
   - Output: `14 packages in scope; Tasks: 14 successful, 14 total. Time: 1m31.146s`
4. **Desktop Smoke Acceptance**:
   - Command: `node apps/desktop/scripts/smoke-test.mjs`
   - Exit Code: `0`
   - Output: `Desktop smoke test passed.`
5. **Provider V2 Tests**:
   - Command: `bun scripts/test.ts src/orchestration-v2/Adapters/{Copilot,OpenCode,Kilo,Droid}AdapterV2.test.ts`
   - Exit Code: `0`
   - Output: `4 test files, 66 passed (Copilot: 13, OpenCode: 47, Kilo: 2, Droid: 4)`
6. **Filesystem Hardening Tests**:
   - Command: `bun scripts/test.ts src/provider/acp/AntigravityClientFiles.test.ts src/workspace/WorkspaceFileSystem.test.ts`
   - Exit Code: `0`
   - Output: `2 test files, 19 passed (AntigravityClientFiles: 6, WorkspaceFileSystem: 13)`
7. **Web Client Tests**:
   - Command: `bun run test` (in `apps/web`)
   - Exit Code: `0`
   - Output: `212 test files passed, 1563 passed (messageQueueStore.test.ts: 11 passed)`
8. **Desktop Readiness & Shutdown Tests**:
   - Command: `vitest run src/browserReadiness.test.ts src/nativeCodeHostShutdown.test.ts src/settingsFlushShutdown.test.ts`
   - Exit Code: `0`
   - Output: `3 test files, 14 passed (readiness: 8, nativeCodeHostShutdown: 3, settingsFlushShutdown: 3)`

---

## 4. Real Electron & Integration Evidence (Separated from Mocks)

- **Real Desktop Electron Shell**:
  - `apps/desktop` bundled with `tsdown` (producing `dist-electron/main.js`, `preload.js`, `extensionPreload.js`, `notificationPreload.js`, `extensionLogicWorker.js`).
  - `apps/server` bundled with `cli.ts build` (producing `dist/bin.mjs`, `dist/index.mjs`, and `dist/client/`).
  - Executed Electron binary with `dist-electron/main.js` via `smoke-test.mjs`. Verified no fatal exceptions, missing modules, or conversion errors.
- **Real Loopback Probing**:
  - `probeBrowserReadiness` tested with live HTTP HEAD/GET against local and non-local targets; enforces security isolation (rejects non-loopback URLs, credentials, and follows).
- **Real Inode In-Kernel Race Hardening**:
  - `AntigravityClientFiles.ts` and `WorkspaceFileSystem.ts` open file descriptors with `O_NOFOLLOW` flag.
  - After acquiring the file descriptor, `handle.stat()` compares `dev` and `ino` against re-resolved `realpath` and re-read `stat` from disk to prevent symlink swaps between check and open.
- **Process Cleanup**:
  - Verified with `ps aux | grep -iE "tabs-dev-root|dist-electron|apps/server/dist" | grep -v grep`. Exactly 0 lingering processes remaining.

---

## 5. Architectural Overview

1. **Active Shipped Entrypoint**:
   - Server launches through `dist/bin.mjs` (`apps/server/src/bin.ts`), which delegates to modern `server.ts` and `ws.ts`.
2. **WebSocket & Projection Ownership**:
   - Single authoritative WebSocket handler in `ws.ts`.
   - Resumable streams with watermarked event positions. Clients commit watermarks only after state application and request replays on reconnect.
3. **Composer Queue Architecture**:
   - Server owns queue state through SQLite persistence and `ComposerQueueWorker`.
   - Client (`messageQueueStore.ts`) migrates existing local queue items upon connection with stable idempotency keys.
   - Attachments are claimed on the server before message promotion.
4. **Provider Routing**:
   - `ProviderRuntimeGeneration` governs generation routing.
   - V2 agent providers (Codex, Claude, Cursor, Grok, OpenCode, Copilot, Kilo, Droid) operate via their respective V2 adapters.
   - Non-agent providers (Gemini, OpenRouter) remain strictly text-generation-only.

---

## 6. Production Decision & Status

**Status**: `READY FOR CODEX INDEPENDENT VERIFICATION`  
All concrete deliverables and work tracks (0 through 5) have been completed. Pre-flight verification gates (`bun run check:effect-versions`, `vp check`, `vp run typecheck`) are passing with exit code 0.
