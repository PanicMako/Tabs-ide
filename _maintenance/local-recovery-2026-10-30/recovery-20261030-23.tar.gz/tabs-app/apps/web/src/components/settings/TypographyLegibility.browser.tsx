import "../../index.css";
import "../../localFonts.css";
import { expect, it } from "vitest";
import { page } from "vitest/browser";
import { render } from "vitest-browser-react";
import { useTheme, snapshotThemeState, restoreThemeSnapshot } from "../../hooks/useTheme";
import { CURATED_FONT_COMBOS, selectFontCombo } from "../../lib/themes";
import { SettingsRow, SettingsSection, SettingsSectionHeader } from "./SettingsLayout";
import { Button } from "../ui/button";

function LegibilityProbe() {
  const { setTheme, setFontPreferences } = useTheme();
  return (
    <div
      style={{
        width: "min(100%, 1000px)",
        padding: 24,
        background: "var(--background)",
        color: "var(--foreground)",
      }}
    >
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 24 }}>
        {["hebdomadal-shift", "pavot-motion", "otez-contrast", "culont-curve"].map((id) => {
          const combo = CURATED_FONT_COMBOS.find((item) => item.id === id)!;
          return (
            <button
              key={id}
              onClick={() => {
                setTheme("tabs-dark");
                setFontPreferences((fonts) =>
                  selectFontCombo({ ...fonts, fontSizeInterface: 12 }, combo),
                );
              }}
            >
              {combo.name}
            </button>
          );
        })}
      </div>
      <button onClick={() => setTheme("tabs-light")}>Light appearance</button>
      <SettingsSectionHeader
        title="Themes"
        description="Customize the appearance of your workspace."
      />
      <nav
        aria-label="Settings"
        style={{ display: "flex", gap: 20, flexWrap: "wrap", margin: "24px 0" }}
      >
        {["General", "Notifications", "Themes", "Providers"].map((name) => (
          <button key={name} className="text-sm font-medium">
            {name}
          </button>
        ))}
      </nav>
      <SettingsSection title="Typography & Fonts">
        <SettingsRow
          title="Interface Font"
          description="Font for UI tabs, sidebar, dialogs, cards, and controls."
          control={<Button>Choose interface font</Button>}
        />
        <SettingsRow
          title="Workspace preferences"
          description="Keep your projects and tools organized."
          control={<Button>Open workspace</Button>}
        />
        <SettingsRow
          title="Editor Font"
          description="Monospace font for code, terminals, and diff views."
          control={<code>const index = 12;</code>}
        />
      </SettingsSection>
    </div>
  );
}

it("keeps the flagged interface pairings legible at the smallest interface preference", async () => {
  const theme = snapshotThemeState();
  const stored = localStorage.getItem("tabs:font-preferences");
  await page.viewport(1200, 900);
  const view = await render(<LegibilityProbe />);
  try {
    for (const name of ["Hebdomadal Shift", "Exotica Motion", "Moche Urbanist", "Culont Curve"]) {
      await page.getByRole("button", { name, exact: true }).click();
      await document.fonts.ready;
      const label = page.getByRole("heading", { name: "Interface Font", exact: true }).element();
      const expected = {
        "Hebdomadal Shift": { family: "Seenonim", tracking: "0.005em", weight: "400" },
        "Exotica Motion": { family: "Seenonim", tracking: "0.005em", weight: "400" },
        "Moche Urbanist": { family: "Konstant Grotesk", tracking: "0.005em", weight: "400" },
        "Culont Curve": { family: "ZT Glora Pro", tracking: "0.015em", weight: "400" },
      }[name]!;
      expect(getComputedStyle(label).fontFamily).toContain(expected.family);
      expect(getComputedStyle(label).fontWeight).toBe(expected.weight);
      const code = page.getByText("const index = 12;", { exact: true }).element();
      expect(getComputedStyle(code).letterSpacing).toBe("normal");
      expect(getComputedStyle(code).fontFamily).toContain("Mono");
      {
        const loaded = await document.fonts.load(`400 14px "${expected.family}"`);
        expect(loaded.length).toBeGreaterThan(0);
        expect(loaded[0]!.weight).toBe("400");
        if (expected.tracking === "normal") {
          expect(getComputedStyle(label).letterSpacing).toBe("normal");
        } else {
          expect(parseFloat(getComputedStyle(label).letterSpacing)).toBeCloseTo(
            parseFloat(expected.tracking) * parseFloat(getComputedStyle(label).fontSize),
            4,
          );
        }
      }
      for (const control of view.container.querySelectorAll<HTMLElement>("button")) {
        expect(control.scrollWidth).toBeLessThanOrEqual(control.clientWidth + 1);
      }
      await page.screenshot({
        element: view.container,
        path: `__screenshots__/typography-legibility/${name.replaceAll(" ", "-")}.png`,
      });
      await page.viewport(390, 844);
      expect(view.container.scrollWidth).toBeLessThanOrEqual(window.innerWidth);
      await page.getByRole("button", { name: "Light appearance", exact: true }).click();
      await page.screenshot({
        element: view.container,
        path: `__screenshots__/typography-legibility/${name.replaceAll(" ", "-")}-mobile-light.png`,
      });
      await page.viewport(1200, 900);
    }
  } finally {
    await view.unmount();
    if (stored === null) localStorage.removeItem("tabs:font-preferences");
    else localStorage.setItem("tabs:font-preferences", stored);
    restoreThemeSnapshot(theme);
  }
});
