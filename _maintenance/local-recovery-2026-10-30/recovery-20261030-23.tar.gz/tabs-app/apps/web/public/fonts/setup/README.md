# Setup-only font assets

The active setup pairing is KS Bistra Regular (400) for headings, Pavot Bold
Italic (700) for "One window.", Aicon Semibold (600) for the
"Tabs Setup" label, and Manrope Regular/Medium for supporting text and controls.
These are the original font weights with no CSS stroke or synthetic bold.
The brand label is compact at 14px.

KS Bistra by Korak Studio:

- https://korakstudio.com/work/ks-bistra-font
- https://fontesk.com/ks-bistra-font/
- Download: https://fontesk.com/download/157262/
- The supplied `KS-Bistra-License.txt` permits personal and commercial use.

Aicon by Eko Bimantara:

- https://fontesk.com/aicon-typeface/
- Download: https://fontesk.com/download/144054/
- The supplied `AICON-License.txt` permits personal and commercial use and
  prohibits selling, modifying, or deriving new font software. The bundled
  `AICON-SemiBold.otf` is unchanged.

Pavot Bold Italic by DBWA is used only for the "One window." accent:

- https://fontesk.com/pavot-font/
- `Pavot-License.txt` states free use for all purposes. The original
  `Pavot-BoldItalic.otf` is unchanged.

ZT Otez Regular is restored from the previously downloaded package:

- https://fontesk.com/zt-otez-serif-font/
- `ZTOtez-License.txt` confirms free commercial use for the supplied Regular
  and Italic styles. Only the original Regular file is used for the label.

The shared `downloadedFonts.css` also registers Pavot Bold and ZT Otez Italic
for the new Themes/Animations heading collection. Both files come from the
previously downloaded, licensed packages. The application loads these faces
from local assets, independently of whether onboarding has been opened.

New heading-only presets are Bistra Signal, Exotica Motion, Moche Urbanist,
Aicon Grid, Mirano Flow, Culont Curve, Hebdomadal Shift, and Hashira Modular.
Studio Signal pairs Coconat page headings with Sun Seed Light section
headings, Syne interface/supporting text, and Menlo code.
Abstract Forms is preserved. Retired preset
definitions remain internal for existing saved settings but do not appear in
the picker.

Northern:

- https://fontesk.com/northern-font/
- Download: https://fontesk.com/download/137716/
- `Northern-Readme.txt` included.

Nafile by Ertekin Erdin:

- https://fontesk.com/nafile-typeface/
- Download: https://fontesk.com/download/146640/
- `Nafile-OFL.txt` grants SIL Open Font License 1.1 permissions.

Mirano by Unio Creative Solutions:

- https://fontesk.com/mirano-font/
- Download: https://fontesk.com/download/166122/
- `Mirano-License.pdf` grants free commercial use.

Culont by Sreenihal Pouka:

- https://fontesk.com/culont-font/
- Download: https://fontesk.com/download/48461/
- `Culont-OFL.txt` grants SIL Open Font License 1.1 permissions.

Hebdomadal by Bao Nguyen (RandomMaerks):

- https://fontesk.com/hebdomadal-font/
- Download: https://fontesk.com/download/148782/
- `Hebdomadal-OFL.txt` grants SIL Open Font License 1.1 permissions.

Ductile Display by Titus Homei:

- https://fontesk.com/ductile-display-font/
- Download: https://fontesk.com/download/152788/
- `DuctileDisplay-Readme.txt` permits free use.

Halo Grotesk:

- https://fontesk.com/halo-grotesk-font/
- Download: https://fontesk.com/download/143817/
- `HaloGrotesk-Readme.txt` permits free use.

Nauryz RedKeds by Red Keds:

- https://fontesk.com/nauryz-redkeds/
- Download: https://fontesk.com/download/134373/
- `NauryzRedKeds-Readme.txt` permits free use.

Exotica by Ivan Vetrov:

- https://fontesk.com/exotica-font/
- Download: https://fontesk.com/download/132871/
- `Exotica-Readme.txt` permits free use.

Mantranaga 36DOT:

- https://fontesk.com/mantranaga-36dot-font/
- Download: https://fontesk.com/download/116569/
- `Mantranaga36DOT-Readme.txt` permits free use.

Angst by Misha Ivanov:

- https://fontesk.com/angst-typeface/
- Download: https://fontesk.com/download/110640/
- `Angst-Readme.txt` permits free personal and commercial use.

Equilla by Asep Rendi:

- https://fontesk.com/equilla-font/
- Download: https://fontesk.com/download/103053/
- `Equilla-Readme.txt` permits free use.

Deserta by Fathul Irfaan:

- https://fontesk.com/deserta-font/
- Download: https://fontesk.com/download/78035/
- `Deserta-Readme.txt` permits free personal and commercial use.

Darker Grotesque by Gabriel Sans:

- https://fontesk.com/darker-grotesque-typeface/
- Download: https://fontesk.com/download/19880/
- `DarkerGrotesque-OFL.txt` grants SIL Open Font License 1.1 permissions.

Arck by Hugo Giffard:

- https://fontesk.com/arck-font/
- Download: https://fontesk.com/download/86486/
- `Arck-Readme.txt` permits free personal and commercial use.

Moche by Rodrigo Fuenzalida:

- https://fontesk.com/moche-typeface/
- Download: https://fontesk.com/download/30826/
- `Moche-OFL.txt` grants SIL Open Font License 1.1 permissions.

Urbanist by Corey Hu:

- https://fontesk.com/urbanist-typeface/
- Download: https://fontesk.com/download/31381/
- `Urbanist-OFL.txt` grants SIL Open Font License 1.1 permissions.

Sato Sans:

- https://fontesk.com/sato-sans-font/
- Download: https://fontesk.com/download/30713/
- `SatoSans-OFL.txt` grants SIL Open Font License 1.1 permissions.

Rebel Type Dog:

- https://fontesk.com/rebel-type-dog-font/
- Download: https://fontesk.com/download/35193/
- `RebelTypeDog-License.txt` permits free use.

Hashira Mt by Saiful Bahri (MotionTail Studio / Pinakiaa):

- https://fontesk.com/hashira-mt-font/
- Download: https://dl.dafont.com/dl/?f=hashira_mt
- `HashiraMt-License.txt` permits personal use.

Neutral Face by Vadym Aksieiev:

- https://fontesk.com/neutral-face-typeface/
- Download: https://fontesk.com/download/45445/
- `NeutralFace-License.txt` grants SIL Open Font License 1.1 permissions.

Stigma by Muksalmina (Mercurial Studio):

- https://fontesk.com/stigma-font/
- Download: https://befonts.com/stigma-font.html
- `Stigma-License.txt` included.

Sun Seed by Burak Mescioğlu:

- https://fontesk.com/sun-seed-typeface/
- Download: https://fontesk.com/download/65774/
- `SunSeed-License.txt` confirms free use for both personal and commercial projects.

Balbes by Authentype:

- https://fontesk.com/balbes-font/
- Download: https://fontesk.com/download/83352/
- `Balbes-Readme.txt` confirms desktop promotional and commercial use.

OTR Type by Bastien Tessanne:

- https://fontesk.com/otr-type-font/
- Download: https://fontesk.com/download/63287/
- `OTRtype-License.txt` confirms free commercial use.

Sirius by Laurent Müller:

- https://fontesk.com/sirius-font/
- Download: https://fontesk.com/download/67782/
- `Sirius-OFL.txt` grants SIL Open Font License 1.1 permissions.

Gerbil by Yukita Creative:

- https://fontesk.com/gerbil-font/
- `Gerbil-License.txt` confirms free commercial use on Fontesk and DafontFree.

Gella Display by Slava Antipov:

- https://fontesk.com/gella-display-font/
- Download: https://fontesk.com/download/104613/
- `GellaDisplay-License.pdf` confirms free commercial use for Light and Expanded Medium.

World Tour by Death of Typography:

- https://fontesk.com/world-tour-font/
- Download: https://fontesk.com/download/79613/
- `WorldTour-OFL.txt` grants SIL Open Font License 1.1 permissions.

Kunika by Leo Kuroshita:

- https://fontesk.com/kunika-font/
- Download: https://fontesk.com/download/90446/
- `Kunika-OFL.txt` grants SIL Open Font License 1.1 permissions.

Taruno Wide by Locomotype:

- https://fontesk.com/taruno-wide-font/
- Download: https://fontesk.com/download/98902/
- `TarunoWide-Readme.txt` grants free commercial use for Medium and Medium Italic.

Novoposelensky by Sasha Pavljenko:

- https://fontesk.com/novoposelensky-font/
- Download: https://fontesk.com/download/82477/
- `Novoposelensky-OFL.txt` grants SIL Open Font License 1.1 permissions.

Preparation validates all bundled font headers without a download or substitution.
Manrope comes from the existing `@fontsource/manrope` dependency under SIL OFL
1.1; see `Manrope-OFL.txt`. Application startup uses local assets offline.

## Seenonim interface typography

Seenonim Regular by Rita Kolmykowa is used for Hebdomadal Shift and Exotica Motion
interface/supporting text. Source: https://fontesk.com/seenonim-font/ and
https://www.behance.net/margaritt1. The supplied Seenonim-Readme.txt specifies
Creative Commons Attribution (CC BY); the original font files are unchanged.
CSS applies optical size correction (92%) and regular 400 weight, without synthetic
bold. The Regular face is the bundled style; this is not a variable weight font.
Moche Urbanist and Culont Curve retain their original fonts with 125% and 145%
optical size correction for ZT Floogn and Horovod respectively.

## ZT Glora Pro — Culont Curve interface

ZT Glora Pro Regular (400), by Zelow Type / Khairun Nas, replaces Horovod for
Culont Curve's interface and supporting text. Culont page headings, Equilla section
headings and Geist Mono editor text remain unchanged. Interface tracking is
0.015em with no synthetic bold or optical size override.

The unchanged Regular OTF/WOFF2 files come from the author's free distribution:
https://www.dafont.com/zt-glora-pro.font and https://zelowtype.com/zt-glora-pro/.
The bundled ZTGloraPro-License.pdf permits personal and commercial projects and
prohibits modifying the font files without the designer's written permission.
Only the original free Regular face is bundled; paid-family weights are not used.

Moche Urbanist uses Konstant Grotesk for interface and supporting text.
Its Moche page headings, Urbanist section headings, and Fragment Mono editor font are unchanged.
Existing Taruno Wide, ZT Floogn, and interim Mirano selections for this preset migrate to Konstant Grotesk;
individually chosen interface or supporting fonts are preserved.

Konstant Grotesk by Stephen French:

- Source: https://fontesk.com/konstant-grotesk-font/
- Download: https://fontesk.com/download/4287/
- `KonstantGrotesk-License.txt` includes the original free personal/commercial use notice.
- Original OTF bundled without modification.

GarciaMarquez by Shalom Guevara:

- Source: https://fontesk.com/garciamarquez-font/
- Download: https://fontesk.com/download/69791/
- `GarciaMarquez-License.txt` permits commercial use and software embedding.
- Original OTF bundled without modification; used only for the setup header brand text.

Bezmiar by Adam Falkowski / OHWOW Design Co.:

- Source: https://fontesk.com/bezmiar-font/
- Download: https://fontesk.com/download/156652/
- Original Regular OTF and `Bezmiar-OFL.txt` bundled without modification.
- Used only for the setup header brand label.
- Replaces GarciaMarquez for the setup header brand label.
- Moche Urbanist retains Konstant Grotesk with 90% optical size, 0.005em tracking,
  and no synthetic bold; its heading/editor fonts and saved sizes remain unchanged.

Delimeter by pmarta.dsgn / Martha Park:

- Source: https://fontesk.com/delimeter-font/
- Download: https://fontesk.com/download/114188/
- Original `Delimiter.otf` and `Delimeter-ReadMe.pdf` bundled unchanged.
- The included readme permits any kind of use; the font file uses the spelling Delimiter.
- Used only for the first-run "Tabs Setup" brand label, replacing Bezmiar.
- App interface presets, heading fonts, and editor fonts are unchanged.

Ransom by Courtney Howells / Courtneyisdope:

- Source: https://fontesk.com/ransom-font/
- Download: https://fontesk.com/download/103675/
- Original OTF and `Ransom-Readme.txt` bundled unchanged; free for commercial use.
- Trial face only for the first-run "TABS SETUP" brand label at 22px.
- Hebdomadal and Delimeter remain bundled for switching back; app presets are unchanged.
