A TrueType and Opentype font created with actual cut-out magazine letters. 
For personal and commercial use.

https://www.behance.net/courtneyhowells
http://www.courtneyisdope.com/