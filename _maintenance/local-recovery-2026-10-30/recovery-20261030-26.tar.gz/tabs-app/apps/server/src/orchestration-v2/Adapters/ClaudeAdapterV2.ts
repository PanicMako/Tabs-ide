import * as NodeCrypto from "node:crypto";

import { makeProviderTextDeltaCoalescer } from "./ProviderTextDeltaCoalescer.ts";
import {
  dynamicToolTitle,
  formatReadToolLabel,
  formatSearchToolLabel,
} from "@tabs/shared/toolActivity";
import { isWorkspaceImagePreviewPath } from "@tabs/shared/filePreview";
import { normalizeClaudeTurnTokenUsage } from "../../provider/ClaudeTurnTokenUsage.ts";
import {
  type CanUseTool,
  forkSession as forkClaudeSession,
  type ForkSessionOptions,
  type ForkSessionResult,
  getSubagentMessages,
  query,
  type Options as ClaudeQueryOptions,
  type PermissionMode,
  type PermissionResult,
  type PermissionUpdate,
  type Query as ClaudeQuery,
  type Settings as ClaudeSdkSettings,
  type SDKAssistantMessage,
  type SDKAPIRetryMessage,
  type SDKMessage,
  type SDKRateLimitInfo,
  type SDKResultMessage,
  type SDKUserMessage,
} from "@anthropic-ai/claude-agent-sdk";
import type {
  AskUserQuestionInput,
  WebSearchOutput,
} from "@anthropic-ai/claude-agent-sdk/sdk-tools";
import { parseCliArgs } from "@tabs/shared/cliArgs";
import { HostProcessEnvironment } from "@tabs/shared/hostProcess";
import { applyClaudePromptEffortPrefix } from "@tabs/shared/model";
import {
  CLAUDE_RESUME_COMPACTION_NEVER_ANSWER,
  formatClaudeResumeCompactionQuestion,
} from "@tabs/shared/claudeCompaction";
import {
  type ChatAttachment,
  ClaudeSettings,
  defaultInstanceIdForDriver,
  type ModelSelection,
  type OrchestrationV2ConversationMessage,
  type OrchestrationV2ExecutionNode,
  type OrchestrationV2ProviderCapabilities,
  type OrchestrationV2ProviderFailure,
  OrchestrationV2ProviderGoal,
  type OrchestrationV2PlanArtifact,
  type OrchestrationV2PlanStep,
  type OrchestrationV2PendingBackgroundTask,
  type OrchestrationV2ProviderRetry,
  type OrchestrationV2ProviderSession,
  type OrchestrationV2ProviderThread,
  type OrchestrationV2ProviderTurn,
  type OrchestrationV2RuntimeRequest,
  type OrchestrationV2UserInputQuestion,
  type OrchestrationV2Subagent,
  type OrchestrationV2TurnItem,
  type OrchestrationV2WebSearchResult,
  type ProviderApprovalDecision,
  ProviderDriverKind,
  type ProviderInstanceId,
  type ProviderRequestKind,
  type ProviderUserInputAnswers,
  type ProviderThreadId,
  type ThreadId,
} from "@tabs/contracts";

import * as Cause from "effect/Cause";
import * as Context from "effect/Context";
import * as Crypto from "effect/Crypto";
import * as DateTime from "effect/DateTime";
import * as Deferred from "effect/Deferred";
import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import * as FileSystem from "effect/FileSystem";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Path from "effect/Path";
import * as Queue from "effect/Queue";
import * as Ref from "effect/Ref";
import * as Schema from "effect/Schema";
import * as Stream from "effect/Stream";

import { resolveAttachmentPath } from "../../attachmentStore.ts";
import { resolveClaudeSdkExecutablePath } from "../../provider/Drivers/ClaudeExecutable.ts";
import { planClaudeSkillDispatch } from "../../provider/Drivers/ClaudeSkillDispatch.ts";
import { discoverClaudeSkills } from "../../provider/Drivers/ClaudeSkills.ts";
import { compileClaudeModelSelection } from "../../claudeModelOptions.ts";
import * as ServerConfig from "../../config.ts";
import { expandHomePath } from "../../pathExpansion.ts";
import {
  claudeSignedOutMessage,
  makeClaudeEnvironment,
} from "../../provider/Drivers/ClaudeHome.ts";
import {
  BUNDLED_CLAUDE_MODEL_CATALOG,
  resolveClaudeCatalogContextWindow,
  resolveClaudeCatalogContextWindowTokens,
} from "../../provider/ClaudeModelCatalog.ts";
import {
  boundProviderEventForLogging,
  type EventNdjsonLogger,
  shouldPersistProviderEvent,
} from "../../provider/EventNdjsonLogger.ts";
import * as ProviderEventLoggers from "../../provider/ProviderEventLoggers.ts";
import {
  claudeRateLimitEventToUpdate,
  type ClaudeScopedLimitNames,
} from "../../provider/claudeUsageLimits.ts";
import type { ServerProviderShape } from "../../provider/ServerProvider.ts";
import { mergeProviderInstanceEnvironment } from "../../provider/ProviderInstanceEnvironment.ts";
import { T3_CODE_ORCHESTRATION_INSTRUCTIONS } from "../../provider/T3OrchestrationInstructions.ts";
import { buildRuntimeInstructions } from "../../provider/RuntimeInstructions.ts";
import { mcpToolPresentation, normalizeMcpText } from "../../provider/McpToolPresentation.ts";
import * as McpProviderSession from "../../mcp/McpProviderSession.ts";
import * as IdAllocator from "../IdAllocator.ts";
import { makeProviderFailure, makeProviderRetryTurnItem } from "../ProviderFailure.ts";
import { turnScopedSelectionTransition } from "../ProviderSelectionTransition.ts";
import { providerMessageTextWithAttachmentPaths } from "../AttachmentPrompt.ts";
import * as ProviderAdapter from "../ProviderAdapter.ts";
import {
  ProviderAdapterDriverCreateError,
  type ProviderAdapterDriver,
  type ProviderAdapterDriverCreateInput,
} from "../ProviderAdapterDriver.ts";
import { type BackgroundWorkReport, backgroundWorkNotification } from "../Notification.ts";
import * as ProviderContinuationRequests from "../ProviderContinuationRequests.ts";
import {
  makeSubagentChildThread,
  makeSubagentConversationArtifacts,
  subagentThreadTitle,
} from "../SubagentProjection.ts";

export const CLAUDE_PROVIDER = ProviderDriverKind.make("claudeAgent");
export const CLAUDE_AGENT_SDK_QUERY_PROTOCOL = "claude-agent-sdk.query" as const;

function claudeContextWindow(modelSelection: ModelSelection): number | null {
  if (modelSelection.model === "claude-opus-4-6" || modelSelection.model === "claude-opus-4-7") {
    return 1_000_000;
  }
  return resolveClaudeCatalogContextWindow(BUNDLED_CLAUDE_MODEL_CATALOG, modelSelection) === "1m"
    ? 1_000_000
    : 200_000;
}

export function claudeProviderTurnTokenUsage(
  usage: {
    readonly input_tokens: number;
    readonly cache_creation_input_tokens?: number | null;
    readonly cache_read_input_tokens?: number | null;
    readonly output_tokens: number;
  },
  modelSelection: ModelSelection,
  updatedAt: string,
) {
  const inputTokens =
    usage.input_tokens +
    (usage.cache_creation_input_tokens ?? 0) +
    (usage.cache_read_input_tokens ?? 0);
  const outputTokens = usage.output_tokens;
  return {
    usedTokens: inputTokens + outputTokens,
    maxTokens: claudeContextWindow(modelSelection),
    inputTokens,
    cachedInputTokens: usage.cache_read_input_tokens ?? 0,
    outputTokens,
    reasoningOutputTokens: 0,
    updatedAt,
  };
}
export const CLAUDE_DEFAULT_INSTANCE_ID = defaultInstanceIdForDriver(CLAUDE_PROVIDER);
const DEFAULT_CLAUDE_SETTINGS = Schema.decodeSync(ClaudeSettings)({});

export const ClaudeProviderCapabilitiesV2 = {
  sessions: {
    supportsMultipleProviderThreadsPerSession: false,
    supportsModelSwitchInSession: true,
    supportsProviderSwitchingViaHandoff: true,
    supportsRuntimeModeSwitchInSession: false,
    pendingRequestsSurviveRestart: false,
  },
  threads: {
    canCreateEmptyThread: true,
    canReadThreadSnapshot: false,
    canRollbackThread: true,
    canForkThread: true,
    canForkFromTurn: true,
    canForkFromSubagentThread: false,
    exposesNativeThreadId: true,
  },
  turns: {
    exposesNativeTurnId: false,
    emitsTurnStarted: true,
    emitsTurnCompleted: true,
    supportsInterrupt: true,
    supportsActiveSteering: true,
    activeSteeringInterruptsTools: true,
    supportsSteeringByInterruptRestart: false,
    supportsQueuedMessages: true,
    terminalStatusQuality: "strong",
  },
  streaming: {
    streamsAssistantText: true,
    streamsReasoning: true,
    streamsToolOutput: false,
    streamsPlanText: false,
    emitsMessageCompleted: true,
  },
  tools: {
    exposesToolItemIds: true,
    emitsToolStarted: true,
    emitsToolCompleted: true,
    emitsToolOutput: true,
    supportsMcpTools: true,
    supportsDynamicToolCallbacks: true,
  },
  approvals: {
    supportsCommandApproval: true,
    supportsFileReadApproval: true,
    supportsFileChangeApproval: true,
    supportsApplyPatchApproval: false,
    approvalsHaveNativeRequestIds: true,
    approvalCallbacksAreLiveOnly: true,
    approvalsCanOriginateFromSubagents: false,
  },
  planning: {
    emitsPlanUpdated: true,
    emitsTodoList: true,
    emitsProposedPlan: true,
    supportsStructuredQuestions: true,
    planDeltasHaveItemIds: false,
  },
  subagents: {
    supportsSubagents: true,
    exposesSubagentThreadIds: false,
    emitsSubagentLifecycle: true,
    canWaitForSubagents: false,
    canCloseSubagents: false,
    canForkSubagentThread: false,
  },
  context: {
    acceptsSystemContext: true,
    acceptsDeveloperContext: true,
    acceptsSyntheticUserContext: true,
    canGenerateSummaries: true,
    canConsumeHandoffSummaries: true,
    supportsDeltaHandoff: true,
    supportsFullThreadHandoff: true,
    maxRecommendedHandoffChars: null,
  },
  checkpointing: {
    appCanCheckpointFilesystem: true,
    supportsNestedCheckpointScopes: true,
    providerCanRollbackConversation: true,
    providerRollbackReturnsSnapshot: true,
    providerCanReadConversationSnapshot: false,
  },
  identity: {
    nativeThreadIds: "strong",
    nativeTurnIds: "weak",
    nativeItemIds: "strong",
    nativeRequestIds: "strong",
  },
  runtimePolicy: {
    enforcement: "native",
  },
} satisfies OrchestrationV2ProviderCapabilities;

const CLAUDE_CODE_PRESET_TOOLS = {
  type: "preset",
  preset: "claude_code",
} satisfies NonNullable<ClaudeQueryOptions["tools"]>;

export type ClaudeAgentSdkQueryToolList = ReadonlyArray<string>;
export interface ClaudeAgentSdkQueryPresetTools {
  readonly type: "preset";
  readonly preset: "claude_code";
}
export type ClaudeAgentSdkQueryTools = ClaudeAgentSdkQueryToolList | ClaudeAgentSdkQueryPresetTools;

export const CLAUDE_READ_ONLY_ALLOWED_TOOLS = ["Read", "Glob", "Grep"] as const;

function claudeAgentSdkQueryToolsForSdk(
  tools: ClaudeAgentSdkQueryTools,
): NonNullable<ClaudeQueryOptions["tools"]> {
  if (isClaudeAgentSdkQueryToolList(tools)) {
    return [...tools];
  }
  return { type: tools.type, preset: tools.preset };
}

function isClaudeAgentSdkQueryToolList(
  tools: ClaudeAgentSdkQueryTools,
): tools is ClaudeAgentSdkQueryToolList {
  return Array.isArray(tools);
}

type ClaudeAgentSdkThreadIdentity =
  | {
      readonly sessionId: string;
      readonly resume?: never;
    }
  | {
      readonly sessionId?: never;
      readonly resume: string;
    };

export type ClaudeAgentSdkQueryOptions = Omit<
  ClaudeQueryOptions,
  "maxTurns" | "model" | "permissionMode" | "resume" | "sessionId" | "tools"
> & {
  readonly model: string;
  readonly tools: NonNullable<ClaudeQueryOptions["tools"]>;
  readonly permissionMode: NonNullable<ClaudeQueryOptions["permissionMode"]>;
} & ClaudeAgentSdkThreadIdentity;

export interface ClaudeAgentSdkQueryOpenInput {
  readonly options: ClaudeAgentSdkQueryOptions;
  readonly threadId: ThreadId;
  readonly providerSessionId: OrchestrationV2ProviderSession["id"];
}

export interface ClaudeAgentSdkQuerySession {
  readonly messages: Stream.Stream<SDKMessage, ClaudeAgentSdkQueryRunnerError>;
  readonly offer: (message: SDKUserMessage) => Effect.Effect<void, ClaudeAgentSdkQueryRunnerError>;
  readonly setModel: (model: string) => Effect.Effect<void, ClaudeAgentSdkQueryRunnerError>;
  readonly setPermissionMode: (
    mode: PermissionMode,
  ) => Effect.Effect<void, ClaudeAgentSdkQueryRunnerError>;
  readonly interrupt: Effect.Effect<void, ClaudeAgentSdkQueryRunnerError>;
  readonly close: Effect.Effect<void, ClaudeAgentSdkQueryRunnerError>;
}

type ClaudeQueryStreamExit = Exit.Exit<void, ClaudeAgentSdkQueryRunnerError>;

export class ClaudeAgentSdkQueryRunnerError extends Schema.TaggedError<ClaudeAgentSdkQueryRunnerError>()(
  "ClaudeAgentSdkQueryRunnerError",
  {
    method: Schema.String,
    cause: Schema.Defect(),
  },
) {
  override get message(): string {
    return "Claude Agent SDK query failed.";
  }
}

export class ClaudeBackgroundWorkBlocksQueryReplacementError extends Schema.TaggedError<ClaudeBackgroundWorkBlocksQueryReplacementError>()(
  "ClaudeBackgroundWorkBlocksQueryReplacementError",
  {},
) {
  override get message(): string {
    return "Claude is still running background agents or commands, and this model or setting change would end them. Wait for them to finish, or press Stop, then send the message again.";
  }
}

export interface ClaudeAgentSdkQueryRunnerShape {
  readonly allocateSessionId: Effect.Effect<string, ClaudeAgentSdkQueryRunnerError>;
  readonly open: (
    input: ClaudeAgentSdkQueryOpenInput,
  ) => Effect.Effect<ClaudeAgentSdkQuerySession, ClaudeAgentSdkQueryRunnerError>;
  readonly forkSession: (
    input: ClaudeAgentSdkSessionForkInput,
  ) => Effect.Effect<ForkSessionResult, ClaudeAgentSdkQueryRunnerError>;
  /** The tool call that launched a subagent, read from the CLI's session storage. */
  readonly subagentLaunchToolUseId: (
    input: ClaudeAgentSdkSubagentLookupInput,
  ) => Effect.Effect<string | null, ClaudeAgentSdkQueryRunnerError>;
  readonly assertComplete: Effect.Effect<void, ClaudeAgentSdkQueryRunnerError>;
}

export class ClaudeAgentSdkQueryRunner extends Context.Service<
  ClaudeAgentSdkQueryRunner,
  ClaudeAgentSdkQueryRunnerShape
>()("t3/orchestration-v2/Adapters/ClaudeAdapterV2/ClaudeAgentSdkQueryRunner") {}

export interface ClaudeAgentSdkSessionForkInput {
  readonly sessionId: string;
  readonly options: ForkSessionOptions;
  readonly threadId: ThreadId;
  readonly providerSessionId: OrchestrationV2ProviderSession["id"];
}

export interface ClaudeAgentSdkSubagentLookupInput {
  readonly sessionId: string;
  readonly agentId: string;
  readonly dir: string | null;
  readonly threadId: ThreadId;
  readonly providerSessionId: OrchestrationV2ProviderSession["id"];
}

const isClaudeAgentSdkQueryRunnerError = Schema.is(ClaudeAgentSdkQueryRunnerError);
const isProviderAdapterRuntimeRequestResponseError = Schema.is(
  ProviderAdapter.ProviderAdapterRuntimeRequestResponseError,
);
const isProviderAdapterRollbackThreadError = Schema.is(
  ProviderAdapter.ProviderAdapterRollbackThreadError,
);

function queryRunnerError(cause: unknown, method: string): ClaudeAgentSdkQueryRunnerError {
  return isClaudeAgentSdkQueryRunnerError(cause)
    ? cause
    : new ClaudeAgentSdkQueryRunnerError({ cause, method });
}

function closeClaudeQuery(queryRuntime: ClaudeQuery) {
  return Effect.try({
    try: () => queryRuntime.close(),
    catch: (cause) => queryRunnerError(cause, "close"),
  });
}

// Iterate the Query itself, not query[Symbol.asyncIterator]() (the raw
// sdkMessages generator). The raw generator's return() queues behind the
// in-flight read of the next CLI message and never settles while the CLI is
// idle, deadlocking stream interruption (and with it, session scope close).
// Query.return() runs cleanup() first, which closes the transport and
// unblocks that read.
export function claudeQueryMessages(queryRuntime: ClaudeQuery): AsyncIterable<SDKMessage, void> {
  return { [Symbol.asyncIterator]: () => queryRuntime };
}

export interface ClaudeAgentSdkLoggedQueryOptions {
  readonly model: ClaudeAgentSdkQueryOptions["model"];
  readonly tools: ClaudeAgentSdkQueryOptions["tools"];
  readonly permissionMode: ClaudeAgentSdkQueryOptions["permissionMode"];
  readonly sessionId?: string;
  readonly resume?: string;
  readonly resumeSessionAt?: ClaudeAgentSdkQueryOptions["resumeSessionAt"];
  readonly cwd?: ClaudeAgentSdkQueryOptions["cwd"];
  readonly allowedTools?: ClaudeAgentSdkQueryOptions["allowedTools"];
  readonly disallowedTools?: ClaudeAgentSdkQueryOptions["disallowedTools"];
  readonly settings?: ClaudeAgentSdkQueryOptions["settings"];
  readonly effort?: ClaudeAgentSdkQueryOptions["effort"];
  readonly includePartialMessages?: true;
  readonly pathToClaudeCodeExecutable?: ClaudeAgentSdkQueryOptions["pathToClaudeCodeExecutable"];
  readonly hasExtraArgs?: true;
  readonly allowDangerouslySkipPermissions?: true;
  readonly hasCanUseTool?: true;
  readonly hasEnvironment?: true;
  readonly hasMcpServers?: true;
}

export type ClaudeAgentSdkProtocolLogEvent =
  | {
      readonly direction: "outgoing";
      readonly stage: "decoded";
      readonly payload: {
        readonly type: "query.open";
        readonly options: ClaudeAgentSdkLoggedQueryOptions;
      };
    }
  | {
      readonly direction: "outgoing";
      readonly stage: "decoded";
      readonly payload: {
        readonly type: "prompt.offer";
        readonly message: SDKUserMessage;
      };
    }
  | {
      readonly direction: "outgoing";
      readonly stage: "decoded";
      readonly payload: {
        readonly type: "query.set_model";
        readonly model: string;
      };
    }
  | {
      readonly direction: "outgoing";
      readonly stage: "decoded";
      readonly payload: {
        readonly type: "query.set_permission_mode";
        readonly mode: PermissionMode;
      };
    }
  | {
      readonly direction: "outgoing";
      readonly stage: "decoded";
      readonly payload: {
        readonly type: "query.interrupt";
      };
    }
  | {
      readonly direction: "outgoing";
      readonly stage: "decoded";
      readonly payload: {
        readonly type: "query.close";
      };
    }
  | {
      readonly direction: "outgoing";
      readonly stage: "decoded";
      readonly payload: {
        readonly type: "session.fork";
        readonly sessionId: string;
        readonly options: ForkSessionOptions;
      };
    }
  | {
      readonly direction: "incoming";
      readonly stage: "decoded";
      readonly payload: {
        readonly type: "session.forked";
        readonly sessionId: string;
      };
    }
  | {
      readonly direction: "outgoing";
      readonly stage: "decoded";
      readonly payload: {
        readonly type: "subagent.lookup";
        readonly sessionId: string;
        readonly agentId: string;
      };
    }
  | {
      readonly direction: "incoming";
      readonly stage: "decoded";
      readonly payload: {
        readonly type: "subagent.found";
        readonly toolUseId: string | null;
      };
    }
  | {
      readonly direction: "incoming";
      readonly stage: "decoded";
      readonly payload: SDKMessage;
    };

export type ClaudeAgentSdkProtocolLogger = (
  event: ClaudeAgentSdkProtocolLogEvent,
) => Effect.Effect<void>;

export function loggedClaudeQueryOptions(
  options: ClaudeAgentSdkQueryOptions,
): ClaudeAgentSdkLoggedQueryOptions {
  return {
    model: options.model,
    tools: options.tools,
    permissionMode: options.permissionMode,
    ...(options.sessionId === undefined ? {} : { sessionId: options.sessionId }),
    ...(options.resume === undefined ? {} : { resume: options.resume }),
    ...(options.resumeSessionAt === undefined ? {} : { resumeSessionAt: options.resumeSessionAt }),
    ...(options.cwd === undefined ? {} : { cwd: options.cwd }),
    ...(options.allowedTools === undefined ? {} : { allowedTools: options.allowedTools }),
    ...(options.disallowedTools === undefined ? {} : { disallowedTools: options.disallowedTools }),
    ...(options.settings === undefined ? {} : { settings: options.settings }),
    ...(options.effort === undefined ? {} : { effort: options.effort }),
    ...(options.includePartialMessages === true ? { includePartialMessages: true } : {}),
    ...(options.pathToClaudeCodeExecutable === undefined
      ? {}
      : { pathToClaudeCodeExecutable: options.pathToClaudeCodeExecutable }),
    ...(options.extraArgs === undefined ? {} : { hasExtraArgs: true }),
    ...(options.allowDangerouslySkipPermissions === true
      ? { allowDangerouslySkipPermissions: true }
      : {}),
    ...(options.canUseTool === undefined ? {} : { hasCanUseTool: true }),
    ...(options.env === undefined ? {} : { hasEnvironment: true }),
    ...(options.mcpServers === undefined ? {} : { hasMcpServers: true }),
  };
}

export function makeClaudeAgentSdkProtocolLogger(input: {
  readonly nativeEventLogger: EventNdjsonLogger | undefined;
  readonly threadId: ThreadId;
  readonly providerSessionId: OrchestrationV2ProviderSession["id"];
}): ClaudeAgentSdkProtocolLogger | undefined {
  const { nativeEventLogger } = input;
  if (nativeEventLogger === undefined) {
    return undefined;
  }

  return (event) => {
    if (!shouldPersistProviderEvent("native", event)) return Effect.void;
    return nativeEventLogger
      .write(
        {
          provider: CLAUDE_PROVIDER,
          protocol: CLAUDE_AGENT_SDK_QUERY_PROTOCOL,
          kind: "protocol",
          providerSessionId: input.providerSessionId,
          event: boundProviderEventForLogging(event),
        },
        input.threadId,
      )
      .pipe(Effect.ignore);
  };
}

export const layerQueryRunner: Layer.Layer<
  ClaudeAgentSdkQueryRunner,
  never,
  Crypto.Crypto | ProviderEventLoggers.ProviderEventLoggers
> = Layer.effect(
  ClaudeAgentSdkQueryRunner,
  Effect.gen(function* () {
    const crypto = yield* Crypto.Crypto;
    const { native: nativeEventLogger } = yield* ProviderEventLoggers.ProviderEventLoggers;

    return ClaudeAgentSdkQueryRunner.of({
      allocateSessionId: crypto.randomUUIDv4.pipe(
        Effect.mapError((cause) => queryRunnerError(cause, "allocateSessionId")),
      ),
      open: Effect.fn("ClaudeAgentSdkQueryRunner.open")(function* (
        input: ClaudeAgentSdkQueryOpenInput,
      ) {
        const protocolLogger = makeClaudeAgentSdkProtocolLogger({
          nativeEventLogger,
          threadId: input.threadId,
          providerSessionId: input.providerSessionId,
        });
        const logProtocolEvent = (event: ClaudeAgentSdkProtocolLogEvent) =>
          protocolLogger === undefined ? Effect.void : protocolLogger(event);
        const promptQueue = yield* Queue.unbounded<SDKUserMessage>();
        const prompt = Stream.fromQueue(promptQueue).pipe(
          Stream.catchCause((cause) =>
            Cause.hasInterruptsOnly(cause) ? Stream.empty : Stream.failCause(cause),
          ),
          Stream.toAsyncIterable,
        );
        const queryRuntime = yield* Effect.try({
          try: () =>
            query({
              prompt,
              options: input.options,
            }),
          catch: (cause) => queryRunnerError(cause, "query"),
        });
        yield* logProtocolEvent({
          direction: "outgoing",
          stage: "decoded",
          payload: {
            type: "query.open",
            options: loggedClaudeQueryOptions(input.options),
          },
        });

        return {
          messages: Stream.fromAsyncIterable(claudeQueryMessages(queryRuntime), (cause) =>
            queryRunnerError(cause, "fromAsyncIterable"),
          ).pipe(
            Stream.tap((message) =>
              logProtocolEvent({
                direction: "incoming",
                stage: "decoded",
                payload: message,
              }),
            ),
          ),
          offer: (message) =>
            Queue.offer(promptQueue, message).pipe(
              Effect.asVoid,
              Effect.tap(() =>
                logProtocolEvent({
                  direction: "outgoing",
                  stage: "decoded",
                  payload: {
                    type: "prompt.offer",
                    message,
                  },
                }),
              ),
            ),
          setModel: (model) =>
            Effect.tryPromise({
              try: () => queryRuntime.setModel(model),
              catch: (cause) => queryRunnerError(cause, "setModel"),
            }).pipe(
              Effect.tap(() =>
                logProtocolEvent({
                  direction: "outgoing",
                  stage: "decoded",
                  payload: {
                    type: "query.set_model",
                    model,
                  },
                }),
              ),
            ),
          setPermissionMode: (mode) =>
            Effect.tryPromise({
              try: () => queryRuntime.setPermissionMode(mode),
              catch: (cause) => queryRunnerError(cause, "setPermissionMode"),
            }).pipe(
              Effect.tap(() =>
                logProtocolEvent({
                  direction: "outgoing",
                  stage: "decoded",
                  payload: {
                    type: "query.set_permission_mode",
                    mode,
                  },
                }),
              ),
            ),
          interrupt: Effect.tryPromise({
            try: () => queryRuntime.interrupt(),
            catch: (cause) => queryRunnerError(cause, "interrupt"),
          }).pipe(
            Effect.tap(() =>
              logProtocolEvent({
                direction: "outgoing",
                stage: "decoded",
                payload: {
                  type: "query.interrupt",
                },
              }),
            ),
          ),
          close: Queue.shutdown(promptQueue).pipe(
            Effect.andThen(closeClaudeQuery(queryRuntime)),
            Effect.tap(() =>
              logProtocolEvent({
                direction: "outgoing",
                stage: "decoded",
                payload: {
                  type: "query.close",
                },
              }),
            ),
          ),
        } satisfies ClaudeAgentSdkQuerySession;
      }),
      forkSession: Effect.fn("ClaudeAgentSdkQueryRunner.forkSession")(function* (
        input: ClaudeAgentSdkSessionForkInput,
      ) {
        const protocolLogger = makeClaudeAgentSdkProtocolLogger({
          nativeEventLogger,
          threadId: input.threadId,
          providerSessionId: input.providerSessionId,
        });
        const logProtocolEvent = (event: ClaudeAgentSdkProtocolLogEvent) =>
          protocolLogger === undefined ? Effect.void : protocolLogger(event);
        yield* logProtocolEvent({
          direction: "outgoing",
          stage: "decoded",
          payload: {
            type: "session.fork",
            sessionId: input.sessionId,
            options: input.options,
          },
        });
        const result = yield* Effect.tryPromise({
          try: () => forkClaudeSession(input.sessionId, input.options),
          catch: (cause) => queryRunnerError(cause, "forkSession"),
        });
        yield* logProtocolEvent({
          direction: "incoming",
          stage: "decoded",
          payload: {
            type: "session.forked",
            sessionId: result.sessionId,
          },
        });
        return result;
      }),
      subagentLaunchToolUseId: Effect.fn("ClaudeAgentSdkQueryRunner.subagentLaunchToolUseId")(
        function* (input: ClaudeAgentSdkSubagentLookupInput) {
          const protocolLogger = makeClaudeAgentSdkProtocolLogger({
            nativeEventLogger,
            threadId: input.threadId,
            providerSessionId: input.providerSessionId,
          });
          const logProtocolEvent = (event: ClaudeAgentSdkProtocolLogEvent) =>
            protocolLogger === undefined ? Effect.void : protocolLogger(event);
          yield* logProtocolEvent({
            direction: "outgoing",
            stage: "decoded",
            payload: {
              type: "subagent.lookup",
              sessionId: input.sessionId,
              agentId: input.agentId,
            },
          });
          // The CLI stamps every message of a subagent's transcript with the
          // tool call that launched it; one message is enough.
          const messages = yield* Effect.tryPromise({
            try: () =>
              getSubagentMessages(input.sessionId, input.agentId, {
                ...(input.dir === null ? {} : { dir: input.dir }),
                limit: 1,
              }),
            catch: (cause) => queryRunnerError(cause, "getSubagentMessages"),
          });
          const toolUseId = messages[0]?.parent_tool_use_id ?? null;
          yield* logProtocolEvent({
            direction: "incoming",
            stage: "decoded",
            payload: { type: "subagent.found", toolUseId },
          });
          return toolUseId;
        },
      ),
      assertComplete: Effect.void,
    });
  }),
);

export function makeClaudeQueryOptions(input: {
  readonly modelSelection: ModelSelection;
  readonly nativeThreadId: string;
  readonly resume: boolean;
  readonly resumeSessionAt?: string;
  readonly cwd: string | null;
  /**
   * The attachments dir grant lets the agent Read/copy pasted images at the
   * paths appended to the turn text, without an approval prompt. It is a leaf
   * directory holding only attachment files; siblings like secrets/ and
   * state.sqlite stay ungranted.
   */
  readonly attachmentsDir?: string;
  readonly settings?: ClaudeSettings;
  readonly sdkSettings?: string | ClaudeSdkSettings;
  readonly environment?: NodeJS.ProcessEnv;
  readonly mcpServers?: ClaudeQueryOptions["mcpServers"];
  readonly tools?: ClaudeAgentSdkQueryTools;
  readonly allowedTools?: ReadonlyArray<string>;
  readonly disallowedTools?: ReadonlyArray<string>;
  readonly permissionMode?: PermissionMode;
  readonly canUseTool?: CanUseTool;
  readonly onUserDialog?: ClaudeQueryOptions["onUserDialog"];
  readonly supportedDialogKinds?: ClaudeQueryOptions["supportedDialogKinds"];
  readonly allowDangerouslySkipPermissions?: boolean;
}): ClaudeAgentSdkQueryOptions {
  const compiledSelection = compileClaudeModelSelection(input.modelSelection);
  const {
    "permission-mode": launchArgPermissionMode,
    "dangerously-skip-permissions": launchArgSkipPermissions,
    ...extraArgs
  } = input.settings === undefined ? {} : parseCliArgs(input.settings.launchArgs).flags;
  const requestThinkingSummaries =
    compiledSelection.settings.alwaysThinkingEnabled !== false &&
    extraArgs["thinking-display"] !== "omitted";
  if (requestThinkingSummaries && extraArgs["thinking-display"] === undefined) {
    extraArgs["thinking-display"] = "summarized";
  }
  const threadIdentity: ClaudeAgentSdkThreadIdentity = input.resume
    ? { resume: input.nativeThreadId }
    : { sessionId: input.nativeThreadId };
  const selectedTools = input.tools ?? CLAUDE_CODE_PRESET_TOOLS;
  const selectionSettings =
    Object.keys(compiledSelection.settings).length === 0
      ? undefined
      : (compiledSelection.settings as ClaudeSdkSettings);
  const querySettings =
    selectionSettings === undefined
      ? input.sdkSettings
      : typeof input.sdkSettings === "object" && input.sdkSettings !== null
        ? ({ ...input.sdkSettings, ...selectionSettings } as ClaudeSdkSettings)
        : selectionSettings;
  const effectiveQuerySettings =
    input.settings?.autoCompactWindow === undefined || input.settings.autoCompactWindow.length === 0
      ? querySettings
      : ({
          ...(typeof querySettings === "object" && querySettings !== null ? querySettings : {}),
          autoCompactWindow: Number(input.settings.autoCompactWindow),
        } as ClaudeSdkSettings);
  const options: ClaudeAgentSdkQueryOptions = {
    model: compiledSelection.apiModelId,
    tools: claudeAgentSdkQueryToolsForSdk(selectedTools),
    permissionMode:
      (launchArgPermissionMode as PermissionMode | null | undefined) ??
      (launchArgSkipPermissions === null || launchArgSkipPermissions === "true"
        ? "bypassPermissions"
        : (input.permissionMode ?? "default")),
    includePartialMessages: true,
    ...(compiledSelection.effort === undefined
      ? {}
      : {
          effort: compiledSelection.effort as NonNullable<ClaudeQueryOptions["effort"]>,
        }),
    ...threadIdentity,
    ...(input.resumeSessionAt === undefined ? {} : { resumeSessionAt: input.resumeSessionAt }),
    ...(input.allowedTools === undefined ? {} : { allowedTools: [...input.allowedTools] }),
    ...(input.disallowedTools === undefined ? {} : { disallowedTools: [...input.disallowedTools] }),
    ...(input.canUseTool === undefined ? {} : { canUseTool: input.canUseTool }),
    ...(input.allowDangerouslySkipPermissions === true
      ? { allowDangerouslySkipPermissions: true }
      : {}),
    ...(requestThinkingSummaries
      ? {
          thinking: { type: "adaptive" as const, display: "summarized" as const },
          settings:
            typeof effectiveQuerySettings === "string"
              ? effectiveQuerySettings
              : {
                  ...effectiveQuerySettings,
                  showThinkingSummaries: true,
                },
        }
      : effectiveQuerySettings === undefined
        ? {}
        : { settings: effectiveQuerySettings }),
    ...(input.onUserDialog === undefined ? {} : { onUserDialog: input.onUserDialog }),
    ...(input.supportedDialogKinds === undefined
      ? {}
      : { supportedDialogKinds: input.supportedDialogKinds }),
    ...(input.settings?.binaryPath
      ? { pathToClaudeCodeExecutable: input.settings.binaryPath }
      : {}),
    ...(input.environment === undefined ? {} : { env: input.environment }),
    ...(input.mcpServers === undefined ? {} : { mcpServers: input.mcpServers }),
    systemPrompt: {
      type: "preset" as const,
      preset: "claude_code" as const,
      append:
        buildRuntimeInstructions({ harness: "Claude Code" }) +
        (input.mcpServers === undefined ? "" : T3_CODE_ORCHESTRATION_INSTRUCTIONS),
    },
    ...(Object.keys(extraArgs).length === 0 ? {} : { extraArgs }),
  };
  const additionalDirectories = [
    ...(input.cwd === null ? [] : [input.cwd]),
    ...(input.attachmentsDir === undefined ? [] : [input.attachmentsDir]),
  ];
  const withDirectories =
    additionalDirectories.length === 0 ? options : { ...options, additionalDirectories };
  return input.cwd === null ? withDirectories : { ...withDirectories, cwd: input.cwd };
}

export const CLAUDE_T3_MCP_TOOL_WILDCARD = "mcp__t3-code__*";

// Must stay in sync with the Tool.Readonly annotations on OrchestratorToolkit;
// ClaudeAdapterV2.test.ts cross-checks this list against the toolkit.
export const CLAUDE_READ_ONLY_T3_MCP_ALLOWED_TOOLS: ReadonlyArray<string> = [
  "mcp__t3-code__orchestrator_capabilities",
  "mcp__t3-code__list_scheduled_tasks",
  "mcp__t3-code__t3_thread_list",
  "mcp__t3-code__t3_thread_wait",
  "mcp__t3-code__t3_pending_request_list",
  "mcp__t3-code__t3_pending_request_read",
  "mcp__t3-code__t3_thread_configuration",
  "mcp__t3-code__t3_thread_transfers",
  "mcp__t3-code__t3_worktree_status",
  "mcp__t3-code__t3_worktree_list",
  "mcp__t3-code__t3_project_list",
  "mcp__t3-code__t3_project_read",
  "mcp__t3-code__t3_thread_search",
  "mcp__t3-code__t3_preview_list",
  "mcp__t3-code__t3_environment_read",
  "mcp__t3-code__t3_queue_list",
  "mcp__t3-code__t3_queue_read",
  "mcp__t3-code__html_preview",
  "mcp__t3-code__html_render",
];

// Claude Code aborts an HTTP MCP call after 60 s ("The operation timed out.")
// unless the server config sets `timeout`. T3's wait tools (t3_thread_wait,
// delegate_task mode=wait) legitimately block for up to an hour
// (MAX_WAIT_TIMEOUT_MS in OrchestratorMcpService), so the budget sits just
// above that and the server's own wait timeout is what ends a long call.
export const CLAUDE_T3_MCP_TOOL_TIMEOUT_MS = 65 * 60 * 1_000;

// The SDK's `allowedTools` only pre-approves tool calls; availability is the
// separate `tools` option. Attaching the t3-code MCP server therefore always
// pre-approves its tools (headless modes like `dontAsk` deny anything that is
// not pre-approved), but read-only sandboxes pre-approve only the annotated
// read-only orchestrator tools so a read-only session cannot silently spawn
// threads or scheduled tasks.
export function claudeMcpQueryOverrides(input: {
  readonly threadId: ThreadId;
  readonly readOnlySandbox: boolean;
  readonly allowedTools?: ReadonlyArray<string>;
}): {
  readonly allowedTools?: ReadonlyArray<string>;
  readonly mcpServers?: ClaudeQueryOptions["mcpServers"];
} {
  const session = McpProviderSession.readMcpProviderSession(input.threadId);
  if (session === undefined) {
    return input.allowedTools === undefined ? {} : { allowedTools: input.allowedTools };
  }
  const mcpAllowedTools = input.readOnlySandbox
    ? CLAUDE_READ_ONLY_T3_MCP_ALLOWED_TOOLS
    : [CLAUDE_T3_MCP_TOOL_WILDCARD];
  return {
    allowedTools: Array.from(new Set([...(input.allowedTools ?? []), ...mcpAllowedTools])),
    mcpServers: {
      "t3-code": {
        type: "http",
        url: session.endpoint,
        headers: {
          Authorization: session.authorizationHeader,
        },
        timeout: CLAUDE_T3_MCP_TOOL_TIMEOUT_MS,
      },
    },
  };
}

function providerSession(input: {
  readonly providerSessionId: OrchestrationV2ProviderSession["id"];
  readonly providerInstanceId: ProviderInstanceId;
  readonly cwd: string | null;
  readonly model: string;
  readonly now: DateTime.Utc;
}): OrchestrationV2ProviderSession {
  return {
    id: input.providerSessionId,
    driver: CLAUDE_PROVIDER,
    providerInstanceId: input.providerInstanceId,
    status: "ready",
    cwd: input.cwd ?? process.cwd(),
    model: input.model,
    capabilities: ClaudeProviderCapabilitiesV2,
    createdAt: input.now,
    updatedAt: input.now,
    lastError: null,
  };
}

function textFromClaudeContent(content: SDKAssistantMessage["message"]["content"]): string {
  return content.flatMap((part) => (part.type === "text" ? [part.text] : [])).join("");
}

// In SDK mode Claude reports `/goal` only through the transcript (its
// `active_goal` event is remote-only): synthetic command output names the
// goal, and each unmet evaluator check returns as Stop hook feedback.
const CLAUDE_GOAL_SET_PREFIX = "Goal set: ";
const CLAUDE_GOAL_ACTIVE = /^Goal active: ([\s\S]+?) \((?:not yet evaluated|(\d+) turns?)\)/u;

/**
 * The goal after one root SDK frame, or undefined when the frame says nothing
 * about it. Completion has no frame of its own; see finalizeActiveTurn.
 */
function nextClaudeGoal(
  current: OrchestrationV2ProviderGoal | null,
  message: SDKMessage,
): OrchestrationV2ProviderGoal | null | undefined {
  if (message.type === "assistant") {
    if (message.parent_tool_use_id !== null || message.message.model !== "<synthetic>") {
      return undefined;
    }
    const text = textFromClaudeContent(message.message.content).trim();
    if (text.startsWith(CLAUDE_GOAL_SET_PREFIX)) {
      const objective = text.slice(CLAUDE_GOAL_SET_PREFIX.length).trim();
      return objective.length === 0 ? undefined : { objective, status: "active", checks: 0 };
    }
    if (text.startsWith("Goal cleared: ") || text.startsWith("No goal set")) return null;
    const active = CLAUDE_GOAL_ACTIVE.exec(text);
    if (active?.[1] === undefined) return undefined;
    return {
      ...(current?.objective === active[1] ? current : {}),
      objective: active[1],
      status: "active",
      checks: Number(active[2] ?? 0),
    };
  }
  if (
    message.type !== "user" ||
    message.parent_tool_use_id !== null ||
    message.isSynthetic !== true ||
    current === null
  ) {
    return undefined;
  }
  const prefix = `Stop hook feedback:\n[${current.objective}]: `;
  const content = message.message.content;
  const text =
    typeof content === "string"
      ? content
      : content.flatMap((part) => (part.type === "text" ? [part.text] : [])).join("");
  if (!text.startsWith(prefix)) return undefined;
  return {
    ...current,
    status: "active",
    checks: (current.checks ?? 0) + 1,
    lastCheck: text.slice(prefix.length).trim(),
  };
}

const providerGoalsEqual = Schema.toEquivalence(Schema.NullOr(OrchestrationV2ProviderGoal));

/** Compares a subagent result with its routed text regardless of block joins. */
function normalizeClaudeResultText(text: string): string {
  return text.replace(/\s+/g, " ").trim();
}

function assistantTextFromSdkMessage(
  message: SDKMessage,
): { readonly nativeItemId: string; readonly text: string } | null {
  if (message.type !== "assistant") {
    return null;
  }
  return {
    nativeItemId: message.uuid,
    text: textFromClaudeContent(message.message.content),
  };
}

function resultTextFromSdkMessage(
  message: SDKMessage,
): { readonly nativeItemId: string; readonly text: string } | null {
  if (message.type !== "result" || message.subtype !== "success") {
    return null;
  }
  return {
    nativeItemId: message.uuid,
    text: message.result,
  };
}

function makeProviderThread(input: {
  readonly idAllocator: IdAllocator.IdAllocatorV2Shape;
  readonly providerInstanceId: ProviderInstanceId;
  readonly appThreadId: OrchestrationV2ProviderThread["appThreadId"];
  readonly ownerNodeId?: OrchestrationV2ProviderThread["ownerNodeId"];
  readonly providerSessionId: OrchestrationV2ProviderThread["providerSessionId"];
  readonly nativeThreadId: string;
  readonly forkedFrom?: NonNullable<OrchestrationV2ProviderThread["forkedFrom"]>;
  readonly now: DateTime.Utc;
}): OrchestrationV2ProviderThread {
  return {
    id: input.idAllocator.derive.providerThread({
      driver: CLAUDE_PROVIDER,
      nativeThreadId: input.nativeThreadId,
    }),
    driver: CLAUDE_PROVIDER,
    providerInstanceId: input.providerInstanceId,
    providerSessionId: input.providerSessionId,
    appThreadId: input.appThreadId,
    ownerNodeId: input.ownerNodeId ?? null,
    nativeThreadRef: {
      driver: CLAUDE_PROVIDER,
      nativeId: input.nativeThreadId,
      strength: "strong",
    },
    nativeConversationHeadRef: null,
    status: "idle",
    firstRunOrdinal: null,
    lastRunOrdinal: null,
    handoffIds: [],
    forkedFrom: input.forkedFrom ?? null,
    createdAt: input.now,
    updatedAt: input.now,
  };
}

const getNativeThreadId = Effect.fnUntraced(function* (
  providerThread: OrchestrationV2ProviderThread,
) {
  const nativeThreadId = providerThread.nativeThreadRef?.nativeId;
  if (nativeThreadId === undefined || nativeThreadId === null) {
    return yield* new ProviderAdapter.ProviderAdapterProtocolError({
      driver: CLAUDE_PROVIDER,
      detail: `Provider thread ${providerThread.id} is missing a native Claude session id.`,
    });
  }
  return nativeThreadId;
});

const isSyntheticClaudeTurnId = (nativeTurnId: string): boolean => nativeTurnId.startsWith("turn:");

const isTerminalProviderTurn = (turn: OrchestrationV2ProviderTurn): boolean =>
  turn.status === "completed" ||
  turn.status === "interrupted" ||
  turn.status === "failed" ||
  turn.status === "cancelled";

const getNativeConversationHeadId = Effect.fnUntraced(function* (
  providerThread: OrchestrationV2ProviderThread,
) {
  const nativeHeadRef = providerThread.nativeConversationHeadRef;
  if (nativeHeadRef === null) {
    return undefined;
  }
  if (nativeHeadRef.driver !== CLAUDE_PROVIDER) {
    return yield* new ProviderAdapter.ProviderAdapterProtocolError({
      driver: CLAUDE_PROVIDER,
      detail: `Provider thread ${providerThread.id} has a non-Claude native conversation head reference.`,
    });
  }
  if (nativeHeadRef.nativeId === null) {
    return yield* new ProviderAdapter.ProviderAdapterProtocolError({
      driver: CLAUDE_PROVIDER,
      detail: `Provider thread ${providerThread.id} has a Claude native conversation head reference without a native id.`,
    });
  }
  return nativeHeadRef.nativeId;
});

const resolveClaudeForkUpToMessageId = Effect.fn("ClaudeAdapterV2.resolveForkUpToMessageId")(
  function* (input: ProviderAdapter.ProviderAdapterV2ForkThreadInput) {
    if (input.providerTurnId === undefined || input.sourceProviderTurns === undefined) {
      return undefined;
    }

    const sourceTurns = input.sourceProviderTurns
      .filter((turn) => turn.providerThreadId === input.sourceProviderThread.id)
      .toSorted((left, right) => left.ordinal - right.ordinal);
    const boundaryIndex = sourceTurns.findIndex((turn) => turn.id === input.providerTurnId);
    if (boundaryIndex < 0) {
      return yield* new ProviderAdapter.ProviderAdapterForkThreadError({
        driver: CLAUDE_PROVIDER,
        providerThreadId: input.sourceProviderThread.id,
        cause: `Cannot fork Claude thread from provider turn ${input.providerTurnId}: source turn was not found in provider thread ${input.sourceProviderThread.id}.`,
      });
    }

    const boundaryNativeId = sourceTurns[boundaryIndex]?.nativeTurnRef?.nativeId;
    if (
      boundaryNativeId !== undefined &&
      boundaryNativeId !== null &&
      !isSyntheticClaudeTurnId(boundaryNativeId)
    ) {
      return boundaryNativeId;
    }

    const terminalTurnsAfterBoundary = sourceTurns
      .slice(boundaryIndex + 1)
      .filter(isTerminalProviderTurn);
    if (terminalTurnsAfterBoundary.length === 0) {
      return undefined;
    }

    return yield* new ProviderAdapter.ProviderAdapterForkThreadError({
      driver: CLAUDE_PROVIDER,
      providerThreadId: input.sourceProviderThread.id,
      cause: `Cannot fork Claude thread from prior provider turn ${input.providerTurnId}: no SDK assistant message cursor was recorded for that turn.`,
    });
  },
);

const resolveClaudeRollbackResumeSessionAt = Effect.fn(
  "ClaudeAdapterV2.resolveRollbackResumeSessionAt",
)(function* (input: ProviderAdapter.ProviderAdapterV2RollbackThreadInput) {
  switch (input.target.type) {
    case "thread_start":
      return null;
    case "provider_turn": {
      const target = input.target;
      if (target.providerTurn.providerThreadId !== input.providerThread.id) {
        return yield* new ProviderAdapter.ProviderAdapterRollbackThreadError({
          driver: CLAUDE_PROVIDER,
          providerThreadId: input.providerThread.id,
          cause: `Cannot roll back Claude thread ${input.providerThread.id} to provider turn ${target.providerTurn.id}: target turn belongs to provider thread ${target.providerTurn.providerThreadId}.`,
        });
      }

      const nativeTurnRef = target.providerTurn.nativeTurnRef;
      if (
        nativeTurnRef !== null &&
        nativeTurnRef.driver === CLAUDE_PROVIDER &&
        nativeTurnRef.nativeId !== null &&
        !isSyntheticClaudeTurnId(nativeTurnRef.nativeId)
      ) {
        return nativeTurnRef.nativeId;
      }

      const providerTurnsAfterTarget = input.providerThreadTurns.filter(
        (turn) => turn.ordinal > target.providerTurn.ordinal && isTerminalProviderTurn(turn),
      );
      if (providerTurnsAfterTarget.length === 0) {
        return null;
      }

      return yield* new ProviderAdapter.ProviderAdapterRollbackThreadError({
        driver: CLAUDE_PROVIDER,
        providerThreadId: input.providerThread.id,
        cause: `Cannot roll back Claude thread ${input.providerThread.id} to provider turn ${target.providerTurn.id}: no SDK assistant message cursor was recorded for that turn.`,
      });
    }
  }
});

type ClaudeUserContent = SDKUserMessage["message"]["content"];
type ClaudeUserContentBlock = Exclude<ClaudeUserContent, string>[number];

const SUPPORTED_CLAUDE_IMAGE_MIME_TYPES = [
  "image/gif",
  "image/jpeg",
  "image/png",
  "image/webp",
] as const;
type SupportedClaudeImageMimeType = (typeof SUPPORTED_CLAUDE_IMAGE_MIME_TYPES)[number];
const supportedClaudeImageMimeTypes = new Set<string>(SUPPORTED_CLAUDE_IMAGE_MIME_TYPES);

function isSupportedClaudeImageMimeType(
  mimeType: string,
): mimeType is SupportedClaudeImageMimeType {
  return supportedClaudeImageMimeTypes.has(mimeType);
}

export function makeClaudeUserMessage(input: {
  readonly text: string;
  readonly priority?: SDKUserMessage["priority"];
  readonly skillNames?: ReadonlySet<string>;
  // Claude echoes it as user_message_uuid on the turn that answers it.
  readonly uuid?: SDKUserMessage["uuid"];
}): SDKUserMessage {
  // Claude Code expands a skill only from the LAST text block, and only when
  // `/name` is its first character. A `$skill` chip anywhere in the prompt is
  // therefore split into [leading text, "/name trailing text"] so the CLI
  // runs it natively and the prose around it survives. See ClaudeSkillDispatch.
  const dispatch =
    input.skillNames === undefined
      ? undefined
      : planClaudeSkillDispatch(input.text, input.skillNames);
  return {
    type: "user",
    message: {
      role: "user",
      content: dispatch
        ? [
            ...(dispatch.leadingText === undefined
              ? []
              : [{ type: "text" as const, text: dispatch.leadingText }]),
            { type: "text" as const, text: dispatch.commandText },
          ]
        : input.text,
    },
    parent_tool_use_id: null,
    ...(input.priority === undefined ? {} : { priority: input.priority }),
    ...(input.uuid === undefined ? {} : { uuid: input.uuid }),
  };
}

const makeClaudeUserMessageWithAttachments = Effect.fnUntraced(function* (input: {
  readonly text: string;
  readonly attachments: ReadonlyArray<ChatAttachment>;
  readonly priority?: SDKUserMessage["priority"];
  readonly uuid?: SDKUserMessage["uuid"];
  readonly attachmentsDir: string;
  readonly fileSystem: FileSystem.FileSystem;
  readonly skillNames?: ReadonlySet<string>;
}) {
  if (input.attachments.length === 0) {
    return makeClaudeUserMessage({
      text: input.text,
      ...(input.skillNames === undefined ? {} : { skillNames: input.skillNames }),
      ...(input.priority === undefined ? {} : { priority: input.priority }),
      ...(input.uuid === undefined ? {} : { uuid: input.uuid }),
    });
  }

  // The model's tools cannot dereference inlined pixels. Appending the
  // on-disk path is what lets a turn like "include this screenshot in the
  // PR" copy the actual file (the query grants attachmentsDir for reads).
  const textWithAttachmentPaths = providerMessageTextWithAttachmentPaths({
    text: input.text,
    attachments: input.attachments,
    attachmentsDir: input.attachmentsDir,
  });

  const dispatch =
    input.skillNames === undefined
      ? undefined
      : planClaudeSkillDispatch(textWithAttachmentPaths, input.skillNames);
  const content: Array<ClaudeUserContentBlock> = [];
  if (dispatch?.leadingText !== undefined) {
    content.push({ type: "text", text: dispatch.leadingText });
  }

  for (const attachment of input.attachments) {
    if (attachment.type === "file") {
      continue;
    }
    if (!isSupportedClaudeImageMimeType(attachment.mimeType)) {
      return yield* new ProviderAdapter.ProviderAdapterProtocolError({
        driver: CLAUDE_PROVIDER,
        detail: `Unsupported Claude image attachment type '${attachment.mimeType}'`,
      });
    }

    const attachmentPath = resolveAttachmentPath({
      attachmentsDir: input.attachmentsDir,
      attachment,
    });
    if (attachmentPath === null) {
      return yield* new ProviderAdapter.ProviderAdapterProtocolError({
        driver: CLAUDE_PROVIDER,
        detail: `Invalid attachment id '${attachment.id}'`,
      });
    }

    const bytes = yield* input.fileSystem.readFile(attachmentPath).pipe(
      Effect.mapError(
        (cause) =>
          new ProviderAdapter.ProviderAdapterProtocolError({
            driver: CLAUDE_PROVIDER,
            detail: `Failed to read attachment '${attachment.id}'`,
            payload: cause,
          }),
      ),
    );
    content.push({
      type: "image",
      source: {
        type: "base64",
        media_type: attachment.mimeType,
        data: Buffer.from(bytes).toString("base64"),
      },
    });
  }

  // Images go before the command block: a text block after them still
  // expands, a command block followed by an image does not.
  if (dispatch) {
    content.push({ type: "text", text: dispatch.commandText });
  } else if (textWithAttachmentPaths.length > 0) {
    content.push({ type: "text", text: textWithAttachmentPaths });
  }

  return {
    type: "user",
    message: {
      role: "user",
      content,
    },
    parent_tool_use_id: null,
    ...(input.priority === undefined ? {} : { priority: input.priority }),
    ...(input.uuid === undefined ? {} : { uuid: input.uuid }),
  } satisfies SDKUserMessage;
});

// Stable per run attempt, so a replayed prompt offer matches its recording.
// Claude echoes it back as user_message_uuid on the turn that answers it.
export function claudePromptUuid(attemptId: string): NonNullable<SDKUserMessage["uuid"]> {
  const hex = NodeCrypto.createHash("sha256").update(`t3-claude-prompt:${attemptId}`).digest("hex");
  const variant = ((Number.parseInt(hex[16]!, 16) & 0x3) | 0x8).toString(16);
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-4${hex.slice(13, 16)}-${variant}${hex.slice(17, 20)}-${hex.slice(20, 32)}`;
}

type ClaudeAssistantContentBlock = SDKAssistantMessage["message"]["content"][number];
type ClaudeToolUseContentBlock = Extract<
  ClaudeAssistantContentBlock,
  {
    readonly id: string;
    readonly name: string;
    readonly input: unknown;
  }
>;
type ClaudeAssistantToolResultContentBlock = Extract<
  ClaudeAssistantContentBlock,
  {
    readonly tool_use_id: string;
  }
>;
type ClaudeUserToolResultContentBlock = Extract<
  ClaudeUserContentBlock,
  {
    readonly tool_use_id: string;
  }
>;
type ClaudeToolResultContentBlock =
  | ClaudeAssistantToolResultContentBlock
  | ClaudeUserToolResultContentBlock;
type ClaudeTypedToolResultContentBlock = Exclude<
  ClaudeToolResultContentBlock,
  { readonly type: "mcp_tool_result" | "tool_result" }
>;
type ClaudeTypedToolResultContent = ClaudeTypedToolResultContentBlock["content"];
type ClaudeToolResultOutput =
  | Extract<ClaudeToolResultContentBlock, { readonly type: "tool_result" }>["content"]
  | Extract<ClaudeToolResultContentBlock, { readonly type: "mcp_tool_result" }>["content"]
  | ClaudeTypedToolResultContent;

function assertNever(value: never): never {
  throw new Error(`Unhandled Claude SDK variant: ${jsonStringifyForTool(value)}`);
}

const ClaudeRuntimeSandboxPolicyKind = Schema.Struct({
  type: Schema.Literals(["dangerFullAccess", "externalSandbox", "readOnly", "workspaceWrite"]),
});
type ClaudeRuntimeSandboxPolicy = typeof ClaudeRuntimeSandboxPolicyKind.Type;
type ClaudeRuntimeSandboxPolicyKindName = ClaudeRuntimeSandboxPolicy["type"];
const isClaudeRuntimeSandboxPolicyKind = Schema.is(ClaudeRuntimeSandboxPolicyKind);

const ClaudeRuntimeReadOnlyFullAccessSandboxPolicy = Schema.Struct({
  type: Schema.Literal("readOnly"),
  access: Schema.Struct({
    type: Schema.Literal("fullAccess"),
  }),
});
const isClaudeRuntimeReadOnlyFullAccessSandboxPolicy = Schema.is(
  ClaudeRuntimeReadOnlyFullAccessSandboxPolicy,
);

function sandboxPolicyKindForClaudeRuntimePolicy(
  runtimePolicy: ProviderAdapter.ProviderAdapterV2RuntimePolicy,
): ClaudeRuntimeSandboxPolicyKindName | undefined {
  return runtimePolicy.sandboxPolicy !== undefined &&
    isClaudeRuntimeSandboxPolicyKind(runtimePolicy.sandboxPolicy)
    ? runtimePolicy.sandboxPolicy.type
    : undefined;
}

function readOnlyPolicyAllowsGlobalReads(
  runtimePolicy: ProviderAdapter.ProviderAdapterV2RuntimePolicy,
): boolean {
  return (
    runtimePolicy.sandboxPolicy !== undefined &&
    isClaudeRuntimeReadOnlyFullAccessSandboxPolicy(runtimePolicy.sandboxPolicy)
  );
}

function permissionModeForClaudeRuntimePolicy(
  runtimePolicy: ProviderAdapter.ProviderAdapterV2RuntimePolicy,
): PermissionMode {
  if (runtimePolicy.interactionMode === "plan") {
    return "plan";
  }
  if (runtimePolicy.approvalPolicy === "never") {
    switch (sandboxPolicyKindForClaudeRuntimePolicy(runtimePolicy)) {
      case "readOnly":
        return "dontAsk";
      case "dangerFullAccess":
      case "externalSandbox":
        return "bypassPermissions";
      case "workspaceWrite":
      case undefined:
        return runtimePolicy.runtimeMode === "approval-required"
          ? "dontAsk"
          : runtimePolicy.runtimeMode === "auto-accept-edits"
            ? "acceptEdits"
            : "bypassPermissions";
    }
  }
  if (runtimePolicy.approvalPolicy !== undefined && runtimePolicy.approvalPolicy !== "never") {
    return "default";
  }

  switch (sandboxPolicyKindForClaudeRuntimePolicy(runtimePolicy)) {
    case "readOnly":
      return "dontAsk";
    case "dangerFullAccess":
      return runtimePolicy.runtimeMode === "approval-required" ? "default" : "bypassPermissions";
    case "externalSandbox":
    case "workspaceWrite":
    case undefined:
      break;
  }

  switch (runtimePolicy.runtimeMode) {
    case "approval-required":
      return "default";
    case "auto-accept-edits":
      return "acceptEdits";
    case "auto":
      return "auto";
    case "full-access":
      return "bypassPermissions";
  }
}

export interface ClaudeRuntimeQueryPolicy {
  readonly permissionMode: PermissionMode;
  readonly tools?: ClaudeAgentSdkQueryTools;
  readonly allowedTools?: ReadonlyArray<string>;
  readonly allowDangerouslySkipPermissions?: true;
  readonly installPermissionCallback: boolean;
}

export function claudeRuntimeQueryPolicyForRuntimePolicy(
  runtimePolicy: ProviderAdapter.ProviderAdapterV2RuntimePolicy,
): ClaudeRuntimeQueryPolicy {
  const permissionMode = permissionModeForClaudeRuntimePolicy(runtimePolicy);
  const readOnlyTools =
    sandboxPolicyKindForClaudeRuntimePolicy(runtimePolicy) === "readOnly"
      ? CLAUDE_READ_ONLY_ALLOWED_TOOLS
      : undefined;
  const allowedTools =
    readOnlyTools !== undefined && readOnlyPolicyAllowsGlobalReads(runtimePolicy)
      ? readOnlyTools
      : undefined;
  // acceptEdits approves edits before the callback runs; everything else it
  // leaves to the callback, which must ask rather than allow.
  const installPermissionCallback =
    runtimePolicy.approvalPolicy === undefined
      ? runtimePolicy.runtimeMode === "approval-required" ||
        runtimePolicy.runtimeMode === "auto-accept-edits"
      : runtimePolicy.approvalPolicy !== "never";

  if (permissionMode === "plan") {
    return {
      permissionMode,
      ...(readOnlyTools === undefined ? {} : { tools: readOnlyTools }),
      ...(allowedTools === undefined ? {} : { allowedTools }),
      installPermissionCallback,
    };
  }

  return {
    permissionMode,
    ...(readOnlyTools === undefined ? {} : { tools: readOnlyTools }),
    ...(allowedTools === undefined ? {} : { allowedTools }),
    ...(permissionMode === "bypassPermissions" ? { allowDangerouslySkipPermissions: true } : {}),
    installPermissionCallback,
  };
}

function shouldInstallClaudePermissionCallback(policy: ClaudeRuntimeQueryPolicy): boolean {
  return policy.installPermissionCallback;
}

// Whether a tool's permission callback must ask the user before answering.
function requiresClaudeApproval(context: ActiveClaudeTurnContext): boolean {
  return shouldInstallClaudePermissionCallback(
    claudeRuntimeQueryPolicyForRuntimePolicy(context.input.runtimePolicy),
  );
}

function claudeRuntimeQueryPolicyKey(policy: ClaudeRuntimeQueryPolicy): string {
  return JSON.stringify({
    permissionMode: policy.permissionMode,
    tools: policy.tools,
    allowedTools: policy.allowedTools,
    allowDangerouslySkipPermissions: policy.allowDangerouslySkipPermissions,
    installPermissionCallback: policy.installPermissionCallback,
  });
}

// Live-query reuse must key on the effective allowlist (including the
// MCP-derived pre-approvals), not just the runtime policy: policies that
// share a policy key can still differ in MCP pre-approvals.
export function claudeEffectiveQueryPolicyKey(
  queryPolicy: ClaudeRuntimeQueryPolicy,
  mcpOverrides: {
    readonly allowedTools?: ReadonlyArray<string>;
    readonly mcpServers?: ClaudeQueryOptions["mcpServers"];
  },
): string {
  return JSON.stringify({
    runtimePolicy: claudeRuntimeQueryPolicyKey({
      ...queryPolicy,
      ...(mcpOverrides.allowedTools === undefined
        ? {}
        : { allowedTools: mcpOverrides.allowedTools }),
    }),
    mcpServers: mcpOverrides.mcpServers,
  });
}

type ClaudeToolItemType = Extract<
  OrchestrationV2TurnItem["type"],
  "command_execution" | "file_change" | "dynamic_tool" | "web_search"
>;

interface ClaudeToolClassification {
  readonly known: boolean;
  readonly normalizedName: string;
  readonly itemType: ClaudeToolItemType;
  readonly requestKind: ProviderRequestKind;
}

function normalizedClaudeToolName(toolName: string): string {
  return toolName.toLowerCase().replaceAll(/[\s_-]/g, "");
}

const CLAUDE_KNOWN_TOOL_CLASSIFICATIONS: Record<
  string,
  {
    readonly itemType: ClaudeToolItemType;
    readonly requestKind: ProviderRequestKind;
  }
> = {
  agent: { itemType: "dynamic_tool", requestKind: "command" },
  bash: { itemType: "command_execution", requestKind: "command" },
  edit: { itemType: "file_change", requestKind: "file-change" },
  glob: { itemType: "dynamic_tool", requestKind: "file-read" },
  grep: { itemType: "dynamic_tool", requestKind: "file-read" },
  ls: { itemType: "dynamic_tool", requestKind: "file-read" },
  monitor: { itemType: "dynamic_tool", requestKind: "command" },
  multiedit: { itemType: "file_change", requestKind: "file-change" },
  notebookedit: { itemType: "file_change", requestKind: "file-change" },
  read: { itemType: "dynamic_tool", requestKind: "file-read" },
  sendmessage: { itemType: "dynamic_tool", requestKind: "command" },
  task: { itemType: "dynamic_tool", requestKind: "command" },
  taskstop: { itemType: "dynamic_tool", requestKind: "command" },
  todowrite: { itemType: "dynamic_tool", requestKind: "command" },
  toolsearch: { itemType: "dynamic_tool", requestKind: "command" },
  webfetch: { itemType: "web_search", requestKind: "command" },
  websearch: { itemType: "web_search", requestKind: "command" },
  write: { itemType: "file_change", requestKind: "file-change" },
};

export function classifyClaudeNativeTool(toolName: string): ClaudeToolClassification {
  const normalizedName = normalizedClaudeToolName(toolName);
  const known = CLAUDE_KNOWN_TOOL_CLASSIFICATIONS[normalizedName];
  return known === undefined
    ? {
        known: false,
        normalizedName,
        itemType: "dynamic_tool",
        requestKind: "command",
      }
    : {
        known: true,
        normalizedName,
        ...known,
      };
}

function providerRequestKindFromClaudeTool(toolName: string): ProviderRequestKind {
  return classifyClaudeNativeTool(toolName).requestKind;
}

function isClaudeWebSearchOutput(output: unknown): output is WebSearchOutput {
  return (
    typeof output === "object" &&
    output !== null &&
    typeof Reflect.get(output, "query") === "string" &&
    Array.isArray(Reflect.get(output, "results")) &&
    typeof Reflect.get(output, "durationSeconds") === "number"
  );
}

const ClaudeNativeToolInputRecord = Schema.Record(Schema.String, Schema.Unknown);
type ClaudeNativeToolInputRecord = typeof ClaudeNativeToolInputRecord.Type;
const isClaudeNativeToolInputRecord = Schema.is(ClaudeNativeToolInputRecord);

type ClaudeNativeToolInput =
  | {
      readonly type: "record";
      readonly value: ClaudeNativeToolInputRecord;
    }
  | {
      readonly type: "non_record";
      readonly value: unknown;
    };

const EMPTY_CLAUDE_NATIVE_TOOL_INPUT = {
  type: "record",
  value: {},
} satisfies ClaudeNativeToolInput;

function claudeNativeToolInputFromUnknown(input: unknown): ClaudeNativeToolInput {
  return isClaudeNativeToolInputRecord(input)
    ? { type: "record", value: input }
    : { type: "non_record", value: input };
}

function claudeNativeToolInputFromRecord(input: Record<string, unknown>): ClaudeNativeToolInput {
  return { type: "record", value: input };
}

function claudeNativeToolInputValue(input: ClaudeNativeToolInput): unknown {
  return input.value;
}

function inputRecordValue(input: ClaudeNativeToolInput, key: string): unknown {
  return input.type === "record" ? input.value[key] : undefined;
}

function firstStringInputField(
  input: ClaudeNativeToolInput,
  keys: ReadonlyArray<string>,
): string | undefined {
  for (const key of keys) {
    const value = inputRecordValue(input, key);
    if (typeof value === "string" && value.trim().length > 0) {
      return value.trim();
    }
  }
  return undefined;
}

function jsonStringifyForTool(value: unknown): string {
  if (typeof value === "string") {
    return value;
  }
  return JSON.stringify(value) ?? String(value);
}

function commandInputFromClaudeTool(toolName: string, input: ClaudeNativeToolInput): string {
  return (
    firstStringInputField(input, ["command", "cmd", "script"]) ??
    `${toolName}: ${jsonStringifyForTool(claudeNativeToolInputValue(input))}`
  );
}

// Opaque non-subagent background work admitted onto the Waiting roster, by
// Claude SDK `task_type`, and the kind the roster names it by. Subagents
// project through the normal subagent lifecycle and must not be
// double-counted when background_tasks_changed includes them.
const CLAUDE_OPAQUE_BACKGROUND_TASK_KINDS: ReadonlyMap<
  string,
  Exclude<OrchestrationV2PendingBackgroundTask["kind"], "subagent">
> = new Map([["local_bash", "command"]]);

function isClaudeOpaqueBackgroundTaskType(taskType: string | null | undefined): boolean {
  return typeof taskType === "string" && CLAUDE_OPAQUE_BACKGROUND_TASK_KINDS.has(taskType);
}

function claudePendingBackgroundTask(input: {
  readonly taskId: string;
  readonly taskType: string | null;
  // Claude runs a Monitor as a local_bash task, so only the Monitor tool call
  // that started it tells it apart from a background Bash command.
  readonly startedByMonitor: boolean;
  readonly description: string | undefined;
}): OrchestrationV2PendingBackgroundTask {
  return {
    taskId: input.taskId,
    kind: input.startedByMonitor
      ? "monitor"
      : ((input.taskType === null
          ? undefined
          : CLAUDE_OPAQUE_BACKGROUND_TASK_KINDS.get(input.taskType)) ?? "background_task"),
    ...(input.description !== undefined && input.description.trim().length > 0
      ? { description: input.description }
      : {}),
  };
}

function claudeTaskTypeFromSdkMessage(message: SDKMessage): string | null {
  if (typeof message !== "object" || message === null) {
    return null;
  }
  const taskType = Reflect.get(message, "task_type");
  return typeof taskType === "string" ? taskType : null;
}

function isClaudeNonSubagentTask(message: SDKMessage): boolean {
  return isClaudeOpaqueBackgroundTaskType(claudeTaskTypeFromSdkMessage(message));
}

function isClaudeBackgroundTasksChangedMessage(message: SDKMessage): boolean {
  return (
    message.type === "system" &&
    // Undeclared SDK subtype: full roster snapshot of live background tasks.
    (message.subtype as string) === "background_tasks_changed"
  );
}

// Claude opens every turn it runs with a root `init` frame. Outside a T3 turn
// that turn is a wake, and `init` comes 20-110 ms after the notification that
// caused it but seconds before its first output (model thinking time).
function isClaudeTurnStartMessage(message: SDKMessage): boolean {
  return message.type === "system" && message.subtype === "init";
}

function claudePendingBackgroundTasksFromRoster(
  roster: ReadonlyMap<string, OrchestrationV2PendingBackgroundTask>,
): ReadonlyArray<OrchestrationV2PendingBackgroundTask> {
  return Array.from(roster.values());
}

function parseClaudeBackgroundTaskEntry(
  entry: unknown,
  monitorTasks: ReadonlyMap<string, unknown>,
): OrchestrationV2PendingBackgroundTask | null {
  if (entry === null || typeof entry !== "object") {
    return null;
  }
  const taskId = Reflect.get(entry, "task_id");
  if (typeof taskId !== "string" || taskId.length === 0) {
    return null;
  }
  const rawTaskType = Reflect.get(entry, "task_type");
  const taskType = typeof rawTaskType === "string" ? rawTaskType : null;
  // Mirror the incremental path: only opaque non-subagent types currently
  // supported for Waiting. Subagent/agent entries stay on the subagent path.
  if (!isClaudeOpaqueBackgroundTaskType(taskType)) {
    return null;
  }
  const description = Reflect.get(entry, "description");
  return claudePendingBackgroundTask({
    taskId,
    taskType,
    startedByMonitor: monitorTasks.has(taskId),
    description: typeof description === "string" ? description : undefined,
  });
}

function fileNameFromClaudeTool(toolName: string, input: ClaudeNativeToolInput): string {
  return (
    firstStringInputField(input, ["file_path", "path", "filename", "fileName"]) ??
    `${toolName} result`
  );
}

type ClaudeNativeToolOutput =
  | {
      readonly type: "none";
    }
  | {
      readonly type: "content_block";
      readonly value: ClaudeToolResultOutput;
    }
  | {
      readonly type: "structured_tool_use_result";
      readonly value: unknown;
      readonly fallbackValue?: ClaudeToolResultOutput;
    };

const NO_CLAUDE_NATIVE_TOOL_OUTPUT = { type: "none" } satisfies ClaudeNativeToolOutput;

function claudeNativeToolOutputFromToolResult(
  toolResult: ClaudeToolResultContentBlock,
): ClaudeNativeToolOutput {
  const value = outputFromClaudeToolResult(toolResult);
  return value === undefined ? NO_CLAUDE_NATIVE_TOOL_OUTPUT : { type: "content_block", value };
}

function claudeNativeToolOutputFromStructuredResult(input: {
  readonly structuredOutput: unknown;
  readonly fallbackValue?: ClaudeToolResultOutput;
}): ClaudeNativeToolOutput {
  return {
    type: "structured_tool_use_result",
    value: input.structuredOutput,
    ...(input.fallbackValue === undefined ? {} : { fallbackValue: input.fallbackValue }),
  };
}

function claudeNativeToolOutputValue(output: ClaudeNativeToolOutput): unknown | undefined {
  switch (output.type) {
    case "none":
      return undefined;
    case "content_block":
    case "structured_tool_use_result":
      return output.value;
    default:
      return assertNever(output);
  }
}

function claudeNativeToolOutputText(output: ClaudeNativeToolOutput): string {
  const value = claudeNativeToolOutputValue(output);
  return typeof value === "string" ? value : value === undefined ? "" : jsonStringifyForTool(value);
}

/**
 * Bash results arrive as `{ stdout, stderr, interrupted, ... }`; keep only the
 * text. A background run has empty streams, so keep its acknowledgement instead.
 */
function claudeCommandOutputText(output: ClaudeNativeToolOutput): string {
  const value = claudeNativeToolOutputValue(output);
  if (typeof value === "object" && value !== null) {
    const stdout = Reflect.get(value, "stdout");
    const stderr = Reflect.get(value, "stderr");
    if (typeof stdout === "string" || typeof stderr === "string") {
      const text = [stdout, stderr]
        .filter((part): part is string => typeof part === "string" && part.trim().length > 0)
        .join("\n");
      if (text.length > 0) return text;
      return output.type === "structured_tool_use_result" && output.fallbackValue !== undefined
        ? claudeSubagentResultText({ type: "content_block", value: output.fallbackValue })
        : "";
    }
  }
  return claudeNativeToolOutputText(output);
}

function claudeSubagentResultText(output: ClaudeNativeToolOutput): string {
  const value = claudeNativeToolOutputValue(output);
  const content = Array.isArray(value)
    ? value
    : typeof value === "object" && value !== null && "content" in value
      ? value.content
      : undefined;
  if (Array.isArray(content)) {
    const text = content
      .flatMap((part) =>
        typeof part === "object" &&
        part !== null &&
        "type" in part &&
        part.type === "text" &&
        "text" in part &&
        typeof part.text === "string"
          ? [part.text]
          : [],
      )
      .join("\n");
    if (text.length > 0) {
      return text;
    }
  }
  return claudeNativeToolOutputText(output);
}

function isClaudeSubagentAsyncLaunchAck(output: ClaudeNativeToolOutput): boolean {
  const value = claudeNativeToolOutputValue(output);
  if (typeof value === "object" && value !== null) {
    if ("isAsync" in value && value.isAsync === true) {
      return true;
    }
    if ("status" in value && value.status === "async_launched") {
      return true;
    }
  }
  return claudeSubagentResultText(output).startsWith("Async agent launched successfully.");
}

const WEB_FETCH_SNIPPET_MAX_CHARS = 8_000;

function webSearchPatternsFromClaudeTool(input: {
  readonly toolInput: ClaudeNativeToolInput;
  readonly output: ClaudeNativeToolOutput;
}): ReadonlyArray<string> {
  const output = claudeNativeToolOutputValue(input.output);
  const pattern =
    firstStringInputField(input.toolInput, ["query", "url", "pattern"]) ??
    (isClaudeWebSearchOutput(output) ? output.query : undefined);
  return pattern === undefined || pattern.trim().length === 0 ? [] : [pattern];
}

function webSearchResultsFromClaudeOutput(
  output: ClaudeNativeToolOutput,
): ReadonlyArray<OrchestrationV2WebSearchResult> {
  const value = claudeNativeToolOutputValue(output);
  if (!isClaudeWebSearchOutput(value)) {
    return [];
  }

  return value.results.flatMap((result) => {
    if (typeof result === "string") {
      return [];
    }
    return result.content.map((content) => ({
      title: content.title,
      url: content.url,
    }));
  });
}

function summarizeClaudeToolRequest(toolName: string, input: ClaudeNativeToolInput): string {
  const command = firstStringInputField(input, ["command", "cmd", "script"]);
  if (command !== undefined) {
    return `${toolName}: ${command.slice(0, 400)}`;
  }
  const path = firstStringInputField(input, ["file_path", "path", "filename", "fileName"]);
  if (path !== undefined) {
    return `${toolName}: ${path.slice(0, 400)}`;
  }
  const serialized = jsonStringifyForTool(claudeNativeToolInputValue(input));
  return serialized.length <= 400
    ? `${toolName}: ${serialized}`
    : `${toolName}: ${serialized.slice(0, 397)}...`;
}

function outputFromClaudeToolResult(
  toolResult: ClaudeToolResultContentBlock,
): ClaudeToolResultOutput | undefined {
  switch (toolResult.type) {
    case "tool_result":
      return toolResult.content;
    case "mcp_tool_result":
      return toolResult.content;
    case "bash_code_execution_tool_result":
    case "code_execution_tool_result":
    case "advisor_tool_result":
    case "text_editor_code_execution_tool_result":
    case "tool_search_tool_result":
    case "web_fetch_tool_result":
    case "web_search_tool_result":
      return toolResult.content;
    default:
      return assertNever(toolResult);
  }
}

function isClaudeTypedToolResultErrorContent(content: ClaudeTypedToolResultContent): boolean {
  if (Array.isArray(content)) {
    return false;
  }

  switch (content.type) {
    case "bash_code_execution_tool_result_error":
    case "code_execution_tool_result_error":
    case "text_editor_code_execution_tool_result_error":
    case "tool_search_tool_result_error":
    case "web_fetch_tool_result_error":
    case "web_search_tool_result_error":
      return true;
    default:
      return false;
  }
}

function isClaudeToolResultError(toolResult: ClaudeToolResultContentBlock): boolean {
  switch (toolResult.type) {
    case "tool_result":
      return toolResult.is_error === true;
    case "mcp_tool_result":
      return toolResult.is_error;
    case "bash_code_execution_tool_result":
    case "code_execution_tool_result":
    case "advisor_tool_result":
    case "text_editor_code_execution_tool_result":
    case "tool_search_tool_result":
    case "web_fetch_tool_result":
    case "web_search_tool_result":
      return isClaudeTypedToolResultErrorContent(toolResult.content);
    default:
      return assertNever(toolResult);
  }
}

function toolNameFromClaudeToolResult(toolResult: ClaudeToolResultContentBlock): string {
  switch (toolResult.type) {
    case "bash_code_execution_tool_result":
      return "bash_code_execution";
    case "code_execution_tool_result":
      return "code_execution";
    case "advisor_tool_result":
      return "advisor";
    case "mcp_tool_result":
      return "mcp_tool";
    case "text_editor_code_execution_tool_result":
      return "text_editor_code_execution";
    case "tool_result":
      return "tool";
    case "tool_search_tool_result":
      return "tool_search";
    case "web_fetch_tool_result":
      return "web_fetch";
    case "web_search_tool_result":
      return "web_search";
    default:
      return assertNever(toolResult);
  }
}

function isClaudeAssistantToolResultContentBlock(
  part: ClaudeAssistantContentBlock,
): part is ClaudeAssistantToolResultContentBlock {
  return "tool_use_id" in part && typeof part.tool_use_id === "string";
}

function isClaudeUserToolResultContentBlock(
  part: ClaudeUserContentBlock,
): part is ClaudeUserToolResultContentBlock {
  return "tool_use_id" in part && typeof part.tool_use_id === "string";
}

function isClaudeToolUseContentBlock(
  part: ClaudeAssistantContentBlock,
): part is ClaudeToolUseContentBlock {
  return (
    "id" in part &&
    typeof part.id === "string" &&
    "name" in part &&
    typeof part.name === "string" &&
    "input" in part
  );
}

function claudeToolUseBlocksFromAssistantMessage(
  message: SDKMessage,
): ReadonlyArray<ClaudeToolUseContentBlock> {
  if (message.type !== "assistant") {
    return [];
  }
  return message.message.content.filter(isClaudeToolUseContentBlock);
}

type ClaudeToolPresentation = ReturnType<typeof mcpToolPresentation>;

function claudeToolPresentationsFromAssistantMessage(
  message: SDKMessage,
): ReadonlyMap<string, ClaudeToolPresentation> {
  const presentations = new Map<string, ClaudeToolPresentation>();
  const meta = message.type === "assistant" ? Reflect.get(message, "tool_use_meta") : undefined;
  if (!Array.isArray(meta)) return presentations;
  const toolNames = new Map(
    claudeToolUseBlocksFromAssistantMessage(message).map((tool) => [
      tool.id,
      tool.name.replace(/^mcp__claude_ai_/u, "mcp__"),
    ]),
  );
  for (const entry of meta) {
    if (typeof entry !== "object" || entry === null) continue;
    const id = normalizeMcpText(Reflect.get(entry, "id"), 512);
    if (id === undefined) continue;
    presentations.set(
      id,
      mcpToolPresentation({
        toolName: toolNames.get(id),
        title: Reflect.get(entry, "display_name"),
        serverDisplayName: Reflect.get(entry, "server_display_name"),
        iconUrl: Reflect.get(entry, "icon_url"),
      }),
    );
  }
  return presentations;
}

function claudeToolResultBlocksFromAssistantMessage(
  message: SDKMessage,
): ReadonlyArray<ClaudeToolResultContentBlock> {
  if (message.type !== "assistant") {
    return [];
  }
  return message.message.content.filter(isClaudeAssistantToolResultContentBlock);
}

function claudeToolResultBlocksFromUserMessage(
  message: SDKMessage,
): ReadonlyArray<ClaudeToolResultContentBlock> {
  if (message.type !== "user" || typeof message.message.content === "string") {
    return [];
  }
  return message.message.content.filter(isClaudeUserToolResultContentBlock);
}

function claudeToolResultEntriesFromMessage(message: SDKMessage): ReadonlyArray<{
  readonly toolResult: ClaudeToolResultContentBlock;
  readonly output: ClaudeNativeToolOutput;
}> {
  const assistantResults = claudeToolResultBlocksFromAssistantMessage(message).map(
    (toolResult) => ({ toolResult, output: claudeNativeToolOutputFromToolResult(toolResult) }),
  );
  const userResults = claudeToolResultBlocksFromUserMessage(message);
  const structuredOutput =
    message.type === "user" && userResults.length === 1 ? message.tool_use_result : undefined;
  return [
    ...assistantResults,
    ...userResults.map((toolResult) => ({
      toolResult,
      output:
        structuredOutput === undefined
          ? claudeNativeToolOutputFromToolResult(toolResult)
          : claudeNativeToolOutputFromStructuredResult({
              structuredOutput,
              fallbackValue: outputFromClaudeToolResult(toolResult),
            }),
    })),
  ];
}

// These wire fields are not yet declared by the SDK's SDKUserMessage type.
const ClaudeToolResultMetadata = Schema.Struct({
  tool_result_meta: Schema.Array(
    Schema.Struct({
      id: Schema.String,
      non_execution_kind: Schema.optional(Schema.NullOr(Schema.String)),
    }),
  ),
});
const isClaudeToolResultMetadata = Schema.is(ClaudeToolResultMetadata);

function claudeToolNonExecutionKind(message: SDKMessage, toolUseId: string) {
  return isClaudeToolResultMetadata(message)
    ? (message.tool_result_meta.find((meta) => meta.id === toolUseId)?.non_execution_kind ??
        undefined)
    : undefined;
}

function parentToolUseIdFromSdkMessage(message: SDKMessage): string | null {
  return message.type === "assistant" || message.type === "user"
    ? message.parent_tool_use_id
    : null;
}

export function permissionResultFromDecision(input: {
  readonly toolName: string;
  readonly decision: ProviderApprovalDecision;
  readonly toolInput: Record<string, unknown>;
  readonly toolUseID: string;
  readonly suggestions?: Parameters<CanUseTool>[2]["suggestions"];
}): PermissionResult {
  if (input.decision === "accept" || input.decision === "acceptForSession") {
    return {
      behavior: "allow",
      updatedInput: input.toolInput,
      toolUseID: input.toolUseID,
      decisionClassification:
        input.decision === "acceptForSession" ? "user_permanent" : "user_temporary",
      ...(input.decision === "acceptForSession"
        ? {
            updatedPermissions: toSessionPermissionUpdates(input.toolName, input.suggestions),
          }
        : {}),
    };
  }

  return {
    behavior: "deny",
    message:
      input.decision === "cancel"
        ? "User cancelled tool execution."
        : "User declined tool execution.",
    toolUseID: input.toolUseID,
    decisionClassification: "user_reject",
    ...(input.decision === "cancel" ? { interrupt: true } : {}),
  };
}

function toSessionPermissionUpdates(
  toolName: string,
  suggestions: ReadonlyArray<PermissionUpdate> | undefined,
): Array<PermissionUpdate> {
  const updates = (suggestions ?? []).map(
    (suggestion): PermissionUpdate => ({
      ...suggestion,
      destination: "session",
    }),
  );
  if (updates.length > 0) {
    return updates;
  }
  return [
    {
      type: "addRules",
      rules: [{ toolName }],
      behavior: "allow",
      destination: "session",
    },
  ];
}

export const awaitClaudeApprovalDecision = Effect.fn("awaitClaudeApprovalDecision")(function* (
  decision: Deferred.Deferred<ProviderApprovalDecision>,
  signal: AbortSignal,
) {
  const cancellation = Effect.callback<ProviderApprovalDecision>((resume) => {
    const abort = () => resume(Effect.succeed("cancel"));
    signal.addEventListener("abort", abort, { once: true });
    if (signal.aborted) {
      abort();
    }
    return Effect.sync(() => signal.removeEventListener("abort", abort));
  });
  return yield* Effect.raceFirst(Deferred.await(decision), cancellation);
});

const awaitClaudeUserInputAnswers = Effect.fn("awaitClaudeUserInputAnswers")(function* (
  answers: Deferred.Deferred<ProviderUserInputAnswers>,
  signal: AbortSignal,
) {
  const cancellation = Effect.callback<ProviderUserInputAnswers>((resume) => {
    const abort = () => resume(Effect.succeed({}));
    signal.addEventListener("abort", abort, { once: true });
    if (signal.aborted) abort();
    return Effect.sync(() => signal.removeEventListener("abort", abort));
  });
  return yield* Effect.raceFirst(Deferred.await(answers), cancellation);
});

/**
 * First user-facing error from a non-success result. "[ede_diagnostic] ..."
 * entries are CLI-internal telemetry (the CLI hides them from its own UI too),
 * so they must never become the error banner (#5557).
 */
function resultUserFacingError(result: SDKResultMessage): string | undefined {
  const errors = "errors" in result && Array.isArray(result.errors) ? result.errors : [];
  if (result.subtype === "success" && !result.is_error) {
    return undefined;
  }
  return errors.find(
    (error): error is string => typeof error === "string" && !error.startsWith("[ede_diagnostic]"),
  );
}

function terminalResultError(
  reason: SDKResultMessage["terminal_reason"],
  failureHint?: string,
): string | undefined {
  switch (reason) {
    case "api_error":
      return failureHint ?? "Claude gave up after repeated API errors.";
    case "malformed_tool_use_exhausted":
      return "Claude gave up after repeated malformed tool calls.";
    case "budget_exhausted":
      return "Claude stopped: the turn's token budget was exhausted.";
    case "structured_output_retry_exhausted":
      return "Claude could not produce the requested structured output.";
    case "tool_deferred_unavailable":
      return "Claude could not resume a deferred tool call: the tool is no longer available.";
    case "turn_setup_failed":
      return "Claude could not start the turn.";
    case "blocking_limit":
      return "Claude stopped: a usage limit blocked the request.";
    case "rapid_refill_breaker":
      return "Claude stopped: the context refilled too quickly after compaction.";
    case "prompt_too_long":
      return "Claude stopped: the prompt exceeds the model's context window.";
    case "image_error":
      return "Claude stopped: an image in the conversation could not be processed.";
    case "model_error":
      return "Claude stopped: the model returned an error.";
    default:
      return undefined;
  }
}

function isOverloadedResult(result: SDKResultMessage): boolean {
  return result.subtype === "success" && result.api_error_status === 529;
}

function terminalStatusFromResult(
  message: SDKResultMessage,
  failureHint?: string,
): Extract<
  OrchestrationV2ProviderTurn["status"],
  "completed" | "interrupted" | "failed" | "cancelled"
> {
  // The CLI can label an abort as success with is_error=false. Its explicit
  // terminal reason takes precedence over that envelope.
  if (
    message.terminal_reason === "aborted_tools" ||
    message.terminal_reason === "aborted_streaming"
  ) {
    return "interrupted";
  }
  if (message.subtype === "success") {
    // The SDK reports API-level failures (401 auth, 529 overloaded, …) as
    // subtype "success" with is_error set; the turn produced no real work.
    return isOverloadedResult(message) ||
      message.api_error_status === 429 ||
      terminalResultError(message.terminal_reason, failureHint) !== undefined ||
      (message.is_error && failureHint !== undefined)
      ? "failed"
      : "completed";
  }
  const errorText = message.errors.join("\n").toLowerCase();
  if (errorText.includes("interrupt")) {
    return "interrupted";
  }
  if (errorText.includes("cancel")) {
    return "cancelled";
  }
  return "failed";
}

function isClaudeActiveSteeringAbortResult(message: SDKResultMessage): boolean {
  return (
    message.terminal_reason === "aborted_streaming" || message.terminal_reason === "aborted_tools"
  );
}

function isClaudeProviderContinuationTurn(
  input: ProviderAdapter.ProviderAdapterV2TurnInput,
): boolean {
  return input.message.createdBy === "agent" && input.message.creationSource === "provider";
}

// Root turn output whose owner (the offered prompt or a queued wake turn)
// the prompt echo decides. Subagent frames, lifecycle frames, and anything
// else not produced by the root model turn pass straight through.
function isClaudePromptEchoGatedFrame(message: SDKMessage): boolean {
  switch (message.type) {
    case "assistant":
    case "stream_event":
    case "user":
      return message.parent_tool_use_id === null;
    case "result":
      return true;
    default:
      return false;
  }
}

// The tool_use a non-root frame belongs to: a subagent frame's parent, or a
// task lifecycle frame's tool_use_id.
function claudeFrameToolUseIds(message: SDKMessage): ReadonlyArray<string> {
  const ids: Array<string> = [];
  const parent = Reflect.get(message, "parent_tool_use_id");
  if (typeof parent === "string") {
    ids.push(parent);
  }
  if (message.type === "system") {
    const toolUseId = Reflect.get(message, "tool_use_id");
    if (typeof toolUseId === "string") {
      ids.push(toolUseId);
    }
  }
  return ids;
}

function claudeEchoedPromptUuids(message: SDKMessage): ReadonlyArray<string> {
  const uuids = Reflect.get(message, "user_message_uuids");
  if (Array.isArray(uuids)) {
    return uuids.filter((uuid): uuid is string => typeof uuid === "string");
  }
  const uuid = Reflect.get(message, "user_message_uuid");
  return typeof uuid === "string" ? [uuid] : [];
}

// The prompt uuid a command_lifecycle frame (queued, started, completed)
// acknowledges. A CLI that sends them also echoes that uuid on the result of
// the turn answering the prompt; one that does not keeps the old path.
function claudeAcknowledgedPromptUuid(message: SDKMessage): string | null {
  const type: unknown = Reflect.get(message, "type");
  if (type !== "command_lifecycle") return null;
  const uuid: unknown = Reflect.get(message, "command_uuid");
  return typeof uuid === "string" ? uuid : null;
}

// A result that answers a turn other than the pending prompt's. An echo
// names the prompts its turn consumed. Without one, only a process known to
// echo proves the turn foreign by its non-human origin; on a CLI that never
// echoes, that result can be the prompt turn's only result.
function isClaudeResultForOtherTurn(input: {
  readonly message: SDKResultMessage;
  readonly promptUuid: string;
  readonly promptEchoMode: ClaudeLiveQueryContext["promptEchoMode"];
}): boolean {
  const echoed = claudeEchoedPromptUuids(input.message);
  if (echoed.length > 0) return !echoed.includes(input.promptUuid);
  return (
    input.promptEchoMode !== "unknown" &&
    input.message.origin !== undefined &&
    input.message.origin.kind !== "human"
  );
}

function isClaudeTaskNotificationOriginResult(message: SDKMessage): message is SDKResultMessage & {
  readonly origin: Extract<
    NonNullable<SDKResultMessage["origin"]>,
    { readonly kind: "task-notification" }
  >;
} {
  return message.type === "result" && message.origin?.kind === "task-notification";
}

function providerFailureFromResult(
  message: SDKResultMessage,
  failureHint?: string,
  usageLimited = false,
): OrchestrationV2ProviderFailure | null {
  const failureClass =
    message.terminal_reason === "blocking_limit" ||
    (message.subtype === "success" && message.api_error_status === 429) ||
    usageLimited
      ? "usage_limit"
      : "provider_error";
  const listedError = resultUserFacingError(message);
  const structuredError = isOverloadedResult(message)
    ? "Claude API is overloaded (529). Try again shortly."
    : message.subtype === "success" && message.api_error_status === 429
      ? "Claude API rate limit reached. Try again later."
      : terminalResultError(message.terminal_reason, failureHint);
  if (message.subtype !== "success") {
    return makeProviderFailure({
      message: listedError ?? structuredError ?? message.errors.join("\n"),
      code: message.subtype,
      class: failureClass,
    });
  }
  if (!message.is_error && structuredError === undefined) {
    return null;
  }
  const apiErrorStatus = message.api_error_status ?? null;
  return makeProviderFailure({
    message: listedError ?? structuredError ?? failureHint ?? message.result,
    code:
      apiErrorStatus === null
        ? (message.terminal_reason ?? "sdk_result_error")
        : `api_error_${apiErrorStatus}`,
    class: failureClass,
    retryable: apiErrorStatus === 429 || apiErrorStatus === 529 ? true : null,
  });
}

function providerFailureFromApiRetry(message: SDKAPIRetryMessage): OrchestrationV2ProviderFailure {
  const errorName = message.error.replaceAll("_", " ");
  return makeProviderFailure({
    message: `Claude API ${errorName}.`,
    code:
      message.error_status === null
        ? message.error
        : `api_error_${Math.trunc(message.error_status)}`,
    class:
      message.error_status === 429
        ? "usage_limit"
        : message.error_status === null
          ? "transport_error"
          : "provider_error",
    retryable: true,
  });
}

function buildAssistantArtifacts(input: {
  readonly idAllocator: IdAllocator.IdAllocatorV2Shape;
  readonly turnInput: ProviderAdapter.ProviderAdapterV2TurnInput;
  readonly providerTurnId: OrchestrationV2ProviderTurn["id"];
  readonly nativeItemId: string;
  readonly text: string;
  readonly ordinal: number;
  readonly startedAt: DateTime.Utc;
  readonly completedAt: DateTime.Utc;
}): {
  readonly node: OrchestrationV2ExecutionNode;
  readonly message: OrchestrationV2ConversationMessage;
  readonly turnItem: OrchestrationV2TurnItem;
} {
  const nodeId = input.idAllocator.derive.nodeFromProviderItem({
    driver: CLAUDE_PROVIDER,
    nativeItemId: input.nativeItemId,
  });
  const messageId = input.idAllocator.derive.messageFromProviderItem({
    driver: CLAUDE_PROVIDER,
    nativeItemId: input.nativeItemId,
  });
  const turnItemId = input.idAllocator.derive.turnItemFromProviderItem({
    driver: CLAUDE_PROVIDER,
    nativeItemId: input.nativeItemId,
  });
  const nativeItemRef = {
    driver: CLAUDE_PROVIDER,
    nativeId: input.nativeItemId,
    strength: "strong" as const,
  };

  return {
    node: {
      id: nodeId,
      threadId: input.turnInput.threadId,
      runId: input.turnInput.runId,
      parentNodeId: input.turnInput.rootNodeId,
      rootNodeId: input.turnInput.rootNodeId,
      kind: "assistant_message",
      status: "completed",
      countsForRun: false,
      providerThreadId: input.turnInput.providerThread.id,
      providerTurnId: input.providerTurnId,
      nativeItemRef,
      runtimeRequestId: null,
      checkpointScopeId: null,
      startedAt: input.startedAt,
      completedAt: input.completedAt,
    },
    message: {
      createdBy: "agent",
      creationSource: "provider",
      id: messageId,
      threadId: input.turnInput.threadId,
      runId: input.turnInput.runId,
      nodeId,
      role: "assistant",
      text: input.text,
      attachments: [],
      streaming: false,
      createdAt: input.completedAt,
      updatedAt: input.completedAt,
    },
    turnItem: {
      id: turnItemId,
      threadId: input.turnInput.threadId,
      runId: input.turnInput.runId,
      nodeId,
      providerThreadId: input.turnInput.providerThread.id,
      providerTurnId: input.providerTurnId,
      nativeItemRef,
      parentItemId: null,
      ordinal: input.ordinal,
      status: "completed",
      title: null,
      startedAt: input.startedAt,
      completedAt: input.completedAt,
      updatedAt: input.completedAt,
      type: "assistant_message",
      messageId,
      text: input.text,
      streaming: false,
    },
  };
}

const CLAUDE_USAGE_LIMIT_WINDOWS = {
  five_hour: "5-hour",
  seven_day: "7-day",
  seven_day_opus: "7-day Opus",
  seven_day_sonnet: "7-day Sonnet",
  seven_day_overage_included: "7-day model",
  overage: "overage",
} satisfies Record<NonNullable<SDKRateLimitInfo["rateLimitType"]>, string>;

/** Beyond this the reset time is not credible, so the row ships without a wait. */
const CLAUDE_USAGE_LIMIT_MAX_WAIT_MS = 30 * 24 * 60 * 60 * 1000;

/**
 * `resetsAt` is epoch seconds. The row states the remaining wait rather than a
 * wall-clock time: this renders on the server, while the row is read on clients
 * that may sit in another timezone and locale, and that carry their own
 * timestamp preference. A wait reads the same everywhere.
 */
function describeClaudeUsageLimit(
  info: SDKRateLimitInfo,
  nowMs: number,
  names: ClaudeScopedLimitNames,
): string {
  const label =
    info.rateLimitType === "seven_day_overage_included" && names.overageIncluded
      ? `7-day ${names.overageIncluded}`
      : info.rateLimitType
        ? CLAUDE_USAGE_LIMIT_WINDOWS[info.rateLimitType]
        : undefined;
  const resetsAtMs = info.resetsAt === undefined ? undefined : info.resetsAt * 1000;
  const waitMs =
    resetsAtMs === undefined || !Number.isFinite(nowMs) ? undefined : resetsAtMs - nowMs;
  const wait =
    waitMs !== undefined && waitMs > 0 && waitMs <= CLAUDE_USAGE_LIMIT_MAX_WAIT_MS
      ? formatClaudeUsageLimitWait(waitMs)
      : undefined;
  return `Claude usage limit reached. This turn is paused until the ${
    label ? `${label} ` : ""
  }limit resets${wait ? ` in ${wait}` : ""}.`;
}

function formatClaudeUsageLimitWait(waitMs: number): string {
  const totalMinutes = Math.ceil(waitMs / 60_000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours === 0) return `${totalMinutes}m`;
  return minutes === 0 ? `${hours}h` : `${hours}h ${minutes}m`;
}

interface ActiveClaudeTurnContext {
  readonly input: ProviderAdapter.ProviderAdapterV2TurnInput;
  readonly nativeTurnId: string;
  nativeMessageCursor: string | null;
  readonly providerTurnId: OrchestrationV2ProviderTurn["id"];
  readonly providerTurnOrdinal: number;
  readonly startedAt: DateTime.Utc;
  // Item ordinals allocated in this turn. Later turns never look items up
  // here: a subagent resumed from another turn keeps its ordinal on the
  // session subagent registry.
  readonly itemOrdinals: Map<string, number>;
  readonly assistant: {
    fallbackText: string;
    fallbackNativeItemId: string;
    emittedNativeItemIds: Set<string>;
  };
  readonly reasoning: {
    messageId: string | null;
    readonly streamBlocks: Map<number, string>;
    readonly nextBlockIndex: Map<string, number>;
    readonly snapshotBlockIndex: Map<string, number>;
    readonly snapshots: Set<string>;
    readonly blocks: Map<
      string,
      { readonly startedAt: DateTime.Utc; readonly ordinal: number; text: string }
    >;
  };
  readonly toolCalls: Map<string, ActiveClaudeToolCall>;
  readonly ignoredTaskIds: Set<string>;
  readonly announcedUsageLimits: Set<string>;
  authenticationFailureMessage: string | undefined;
  readonly rejectedRateLimitTypes: Set<string>;
  readonly rateLimitResetTimes: Map<string, string | null>;
  latestAssistantRateLimited: boolean;
  readonly subagentsByTaskId: Map<string, ActiveClaudeSubagent>;
  readonly subagentsByToolUseId: Map<string, ActiveClaudeSubagent>;
  readonly subagentNodesByTaskId: Map<string, OrchestrationV2ExecutionNode["id"]>;
  readonly pendingSubagentLaunchesByToolUseId: Map<string, PendingClaudeSubagentLaunch>;
  // Set on turns that offered a prompt. Claude runs a wake turn it queued
  // for background work before the next prompt's turn, and only the
  // prompt's turn echoes this uuid (see handleSdkMessage).
  readonly promptUuid: string | null;
  promptEcho: "pending" | "confirmed";
  // Root frames seen before the echo; held only when the CLI echoes early.
  gatedFramesBeforeEcho: number;
  readonly heldRootFrames: Array<SDKMessage>;
}

interface ActiveClaudeProviderRetry {
  readonly retry: OrchestrationV2ProviderRetry;
  readonly failure: OrchestrationV2ProviderFailure;
  readonly startedAt: DateTime.Utc;
  readonly itemOrdinal: number;
}

interface ActiveClaudeSubagent {
  task: OrchestrationV2Subagent;
  // The launch run's root node. task.parentNodeId is that same node, or the
  // owning subagent's node for a subagent another subagent started.
  readonly rootNodeId: OrchestrationV2ExecutionNode["id"];
  readonly childThreadId: ThreadId;
  readonly childRootNodeId: OrchestrationV2ExecutionNode["id"];
  readonly turnItemId: OrchestrationV2TurnItem["id"];
  readonly turnItemOrdinal: number;
  // The tool call that started the current run: the Agent launch, then each
  // SendMessage that resumes the subagent. A new one means a new prompt.
  readonly runToolUseId: string | null;
  nextChildItemOrdinal: number;
  resultItemOrdinal: number | null;
  // The subagent's latest assistant message routed into its child thread,
  // accumulated across the per-content-block snapshots that share one native
  // message id. A completion result equal to it is already on screen.
  lastAssistantText: string | null;
  lastAssistantMessageId: string | null;
}

interface ClaudeLiveQueryContext {
  readonly nativeThreadId: string;
  readonly query: ClaudeAgentSdkQuerySession;
  readonly queryPolicyKey: string;
  readonly selectionKey: string;
  readonly closed: Deferred.Deferred<void, never>;
  // Whether this CLI process echoes a prompt's uuid on the first frame of
  // the turn answering it ("early") or only on its result. Learned from the
  // first prompt turn. "acknowledged": the CLI confirmed it took a prompt's
  // uuid before any echo, so it echoes, but a resume's own turns can still
  // run ahead of that prompt.
  promptEchoMode: "unknown" | "acknowledged" | "early" | "result_only";
  // The mode this process was opened in, and the mode the CLI last reported
  // (init and status frames). Claude changes the latter itself through
  // EnterPlanMode.
  readonly openedPermissionMode: PermissionMode;
  permissionMode: PermissionMode;
  // Stop, rollback or fork is closing this process; its work is ending.
  stopping: boolean;
  // Registry entries still running when this process opened. Their process
  // is gone and never reports their end; any later task_started replaces the
  // entry, so an entry still in this set runs nowhere.
  readonly subagentsFromEarlierProcesses: ReadonlySet<ActiveClaudeSubagent>;
}

interface ActiveClaudeToolCall {
  readonly nativeItemId: string;
  readonly toolName: string;
  readonly classification: ClaudeToolClassification;
  readonly input: ClaudeNativeToolInput;
  readonly threadId: ThreadId;
  readonly runId: ProviderAdapter.ProviderAdapterV2TurnInput["runId"] | null;
  readonly rootNodeId: OrchestrationV2ExecutionNode["id"];
  readonly parentNodeId: OrchestrationV2ExecutionNode["id"];
  readonly ordinal: number;
  readonly startedAt: DateTime.Utc;
  readonly presentation?: ClaudeToolPresentation;
}

// What is known about a subagent before its task_started registers it,
// keyed by the tool_use_id that launches it.
interface PendingClaudeSubagentLaunch {
  readonly model?: string;
  // parent_tool_use_id of the subagent whose own Agent call launches this one.
  readonly ownerToolUseId?: string;
}

const PENDING_CLAUDE_SUBAGENT_CAP = 64;
// Per-subagent bound on frames held while waiting for task_started.
const PENDING_CLAUDE_SUBAGENT_FRAME_CAP = 256;

function rememberPendingClaudeSubagentLaunch(
  pending: Map<string, PendingClaudeSubagentLaunch>,
  toolUseId: string,
  launch: PendingClaudeSubagentLaunch,
): void {
  pending.set(toolUseId, { ...pending.get(toolUseId), ...launch });
  if (pending.size <= PENDING_CLAUDE_SUBAGENT_CAP) {
    return;
  }
  const oldest = pending.keys().next();
  if (!oldest.done) {
    pending.delete(oldest.value);
  }
}

/**
 * Agent calls carry model overrides even when the SDK omits child assistant
 * snapshots. A subagent's own Agent call arrives only in its snapshot, so the
 * owner recorded here is all that links the subagent it starts back to it.
 */
function rememberClaudeSubagentLaunch(
  context: ActiveClaudeTurnContext,
  toolUseId: string,
  input: ClaudeNativeToolInput,
  ownerToolUseId: string | null,
): void {
  if (context.subagentsByToolUseId.has(toolUseId)) return;
  const pending = context.pendingSubagentLaunchesByToolUseId;
  const requested = firstStringInputField(input, ["model"]);
  // "inherit" is the caller's model: the session's here, an owner's once
  // task_started resolves it.
  const model =
    requested !== "inherit"
      ? requested
      : ownerToolUseId === null
        ? context.input.modelSelection.model
        : undefined;
  // A model already known (a snapshot's, or an earlier sighting of this
  // call) wins over the requested one.
  const launch: PendingClaudeSubagentLaunch = {
    ...(model === undefined || pending.get(toolUseId)?.model !== undefined ? {} : { model }),
    ...(ownerToolUseId === null ? {} : { ownerToolUseId }),
  };
  if (launch.model !== undefined || launch.ownerToolUseId !== undefined) {
    rememberPendingClaudeSubagentLaunch(pending, toolUseId, launch);
  }
}

type PendingClaudeRuntimeRequest =
  | {
      readonly type: "approval";
      readonly requestId: OrchestrationV2RuntimeRequest["id"];
      readonly requestKind: ProviderRequestKind;
      readonly decision: Deferred.Deferred<ProviderApprovalDecision, never>;
    }
  | {
      readonly type: "user_input";
      readonly requestId: OrchestrationV2RuntimeRequest["id"];
      readonly answers: Deferred.Deferred<ProviderUserInputAnswers, never>;
    };

export function claudeUserInputQuestions(
  input: unknown,
): ReadonlyArray<OrchestrationV2UserInputQuestion> {
  const value =
    typeof input === "object" && input !== null && Reflect.get(input, "type") === "record"
      ? Reflect.get(input, "value")
      : input;
  const questions =
    typeof value === "object" && value !== null ? Reflect.get(value, "questions") : undefined;
  if (!Array.isArray(questions)) return [];
  return questions.flatMap((value: unknown, index: number) => {
    if (typeof value !== "object" || value === null) return [];
    const record = value as Record<string, unknown>;
    const question = typeof record.question === "string" ? record.question.trim() : "";
    if (question.length === 0) return [];
    const header =
      typeof record.header === "string" && record.header.trim().length > 0
        ? record.header.trim()
        : `Question ${index + 1}`;
    const options = Array.isArray(record.options)
      ? record.options.flatMap((option) => {
          if (typeof option !== "object" || option === null) return [];
          const optionRecord = option as Record<string, unknown>;
          const label = typeof optionRecord.label === "string" ? optionRecord.label.trim() : "";
          if (label.length === 0) return [];
          return [
            {
              label,
              description:
                typeof optionRecord.description === "string" ? optionRecord.description.trim() : "",
            },
          ];
        })
      : [];
    return [
      {
        id: question,
        header,
        question,
        options,
        multiSelect: record.multiSelect === true,
      },
    ];
  });
}

export function claudeSdkUserInputAnswers(
  answers: ProviderUserInputAnswers,
): NonNullable<AskUserQuestionInput["answers"]> {
  return Object.fromEntries(
    Object.entries(answers).map(([question, answer]) => [
      question,
      Array.isArray(answer)
        ? answer.filter((value): value is string => typeof value === "string").join(", ")
        : typeof answer === "string"
          ? answer
          : String(answer ?? ""),
    ]),
  );
}

export function claudeTodoSteps(input: unknown): ReadonlyArray<OrchestrationV2PlanStep> {
  const value =
    typeof input === "object" && input !== null && Reflect.get(input, "type") === "record"
      ? Reflect.get(input, "value")
      : input;
  const todos =
    typeof value === "object" && value !== null ? Reflect.get(value, "todos") : undefined;
  if (!Array.isArray(todos)) return [];
  return todos.flatMap((todo, index) => {
    if (typeof todo !== "object" || todo === null) return [];
    const text =
      typeof Reflect.get(todo, "content") === "string"
        ? String(Reflect.get(todo, "content")).trim()
        : "";
    if (text.length === 0) return [];
    const nativeStatus = Reflect.get(todo, "status");
    return [
      {
        id: `todo-${index}`,
        text,
        status:
          nativeStatus === "completed"
            ? "completed"
            : nativeStatus === "in_progress"
              ? "running"
              : "pending",
      },
    ];
  });
}

export function claudeProposedPlan(input: unknown): string | null {
  const value =
    typeof input === "object" && input !== null && Reflect.get(input, "type") === "record"
      ? Reflect.get(input, "value")
      : input;
  const plan = typeof value === "object" && value !== null ? Reflect.get(value, "plan") : undefined;
  return typeof plan === "string" && plan.trim().length > 0 ? plan.trim() : null;
}

export interface ClaudeAdapterV2Options {
  readonly instanceId: ProviderInstanceId;
  readonly settings: ClaudeSettings;
  readonly environment: NodeJS.ProcessEnv;
  readonly attachmentsDir: string;
  readonly fileSystem: FileSystem.FileSystem;
  readonly path: Path.Path;
  readonly idAllocator: IdAllocator.IdAllocatorV2Shape;
  readonly queryRunner: ClaudeAgentSdkQueryRunnerShape;
  readonly scopedLimitNames?: Ref.Ref<ClaudeScopedLimitNames>;
  readonly onUsageLimits?: ServerProviderShape["applyUsageLimits"];
  /** Sink for wake-turn continuation requests; defaults to dropping them. */
  readonly continuationRequests?: {
    readonly offer: (
      request: ProviderContinuationRequests.ProviderContinuationRequest,
    ) => Effect.Effect<void>;
  };
}

export function makeClaudeAdapterV2(
  adapterOptions: ClaudeAdapterV2Options,
): ProviderAdapter.ProviderAdapterV2Shape {
  const { attachmentsDir, fileSystem, path, idAllocator, queryRunner } = adapterOptions;
  const continuationRequests = adapterOptions.continuationRequests ?? {
    offer: () => Effect.void,
  };

  // Re-scan on every send: skills are added and switched off mid-session, and
  // the scan is a few directory reads. A skill switched off via skillOverrides,
  // or reserved for the agent with `user-invocable: false`, is left as prose:
  // the CLI would answer `/name` with a notice instead of running it.
  const userInvocableSkillNames = (cwd: string | null) =>
    discoverClaudeSkills(
      adapterOptions.settings,
      cwd ?? undefined,
      adapterOptions.environment,
    ).pipe(
      Effect.map(
        (skills) =>
          new Set(
            skills
              .filter((skill) => skill.enabled && skill.userInvocable !== false)
              .map((skill) => skill.name),
          ),
      ),
      Effect.provideService(FileSystem.FileSystem, fileSystem),
      Effect.provideService(Path.Path, path),
    );

  return ProviderAdapter.ProviderAdapterV2.of({
    instanceId: adapterOptions.instanceId,
    driver: CLAUDE_PROVIDER,
    getCapabilities: () => Effect.succeed(ClaudeProviderCapabilitiesV2),
    planSelectionTransition: () => Effect.succeed(turnScopedSelectionTransition()),
    openSession: Effect.fn("ClaudeAdapterV2.openSession")(
      function* (input: ProviderAdapter.ProviderAdapterV2OpenSessionInput) {
        const sessionScope = yield* Effect.scope;
        const now = yield* DateTime.now;
        const session = providerSession({
          providerSessionId: input.providerSessionId,
          providerInstanceId: adapterOptions.instanceId,
          cwd: input.runtimePolicy.cwd,
          model: input.modelSelection.model,
          now,
        });
        const events = yield* Queue.unbounded<ProviderAdapter.ProviderAdapterV2Event>();
        const activeTurn = yield* Ref.make<ActiveClaudeTurnContext | null>(null);
        const interruptedTurns = yield* Ref.make(new Set<OrchestrationV2ProviderTurn["id"]>());
        const steeredTurns = yield* Ref.make(new Set<OrchestrationV2ProviderTurn["id"]>());
        const queryContext = yield* Ref.make<ClaudeLiveQueryContext | null>(null);
        const openedNativeThreads = yield* Ref.make(new Set<string>());
        const latestPlanByKind = yield* Ref.make(new Map<string, OrchestrationV2PlanArtifact>());
        const planIdsByNativeItem = yield* Ref.make(
          new Map<string, OrchestrationV2PlanArtifact["id"]>(),
        );
        const providerRetries = yield* Ref.make(
          new Map<OrchestrationV2ProviderTurn["id"], ActiveClaudeProviderRetry>(),
        );
        const pendingRuntimeRequests = yield* Ref.make(
          new Map<string, PendingClaudeRuntimeRequest>(),
        );
        // Background-task wake support. Claude can settle a turn while a
        // local_bash background task keeps running; the CLI later re-invokes
        // the model (a "wake turn") on the same query stream with no active
        // provider turn. These refs track pending background tasks, buffer
        // wake messages until a continuation run attaches, and remember where
        // to dispatch that run.
        const lastTurnRouteByNativeThread = yield* Ref.make(
          new Map<
            string,
            { readonly threadId: ThreadId; readonly providerThreadId: ProviderThreadId }
          >(),
        );
        // Authoritative + incremental background-task roster for post-settle
        // Waiting UI. Outer key is native Claude session id so concurrent
        // provider threads on one runtime cannot share or clear each other.
        const pendingBackgroundTasksByNativeThread = yield* Ref.make(
          new Map<string, Map<string, OrchestrationV2PendingBackgroundTask>>(),
        );
        // Wake eligibility is separate from the Waiting roster. It survives
        // empty background_tasks_changed levels (SDK: empty level can precede
        // task_notification) and is consumed when the first idle notification
        // is buffered/offered so duplicates cannot re-buffer. A short-lived
        // replay tombstone then covers continuation drain classification so
        // local_bash is never projected as a subagent; the tombstone is
        // cleared after that drained notification is processed. Both sets
        // clear on CLI process open/replacement and failed/interrupted turns.
        const wakeEligibleBackgroundTasksByNativeThread = yield* Ref.make(
          new Map<string, Set<string>>(),
        );
        const opaqueBackgroundTaskReplayTombstonesByNativeThread = yield* Ref.make(
          new Map<string, Set<string>>(),
        );
        // Last known provider-thread payload per native session, used to emit
        // roster-only provider_thread.updated events between turns without
        // resurrecting an active status after root settlement.
        const lastProviderThreadByNativeThread = yield* Ref.make(
          new Map<string, OrchestrationV2ProviderThread>(),
        );
        // Native `/goal` per session, seeded from the persisted provider thread.
        const goalsByNativeThread = new Map<string, OrchestrationV2ProviderGoal | null>();
        // Turns whose model output met an active goal's Stop hook check at its end.
        const goalCheckedTurns = new Set<string>();
        // Subagent registry that survives turn settle: a background subagent
        // (Agent with run_in_background) can complete after the root turn
        // ended, and its task_notification must both count as wake evidence
        // and hydrate the original subagent node instead of being dropped.
        const sessionSubagentsByTaskId = yield* Ref.make(new Map<string, ActiveClaudeSubagent>());
        // Subagent frames carry only parent_tool_use_id. Frames that outlive
        // the turn that launched the subagent (wake drain, later turns) resolve
        // their subagent through this index into sessionSubagentsByTaskId.
        const sessionSubagentTaskIdsByToolUseId = yield* Ref.make(new Map<string, string>());
        // Subagent frames can precede the task_started that registers their
        // subagent (the same race rememberPendingClaudeSubagentLaunch covers).
        // They wait here and replay once task_started registers the owner.
        const pendingSubagentFramesByToolUseId = yield* Ref.make(
          new Map<string, ReadonlyArray<SDKMessage>>(),
        );
        const wakeBuffers = yield* Ref.make(
          new Map<
            string,
            { readonly messages: ReadonlyArray<SDKMessage>; readonly detail: string | null }
          >(),
        );
        // Background work that ended and has not been named by a wake offer yet,
        // by native thread and task id, with the user turn it ended in. Claude's
        // wake result carries no task id, and its wake can run after a prompt the
        // user queued meanwhile, so reports survive one user turn and then expire:
        // a notification Claude folded into its own turn cannot name a later wake.
        // One Ref holds both, so a report cannot be stamped with a turn that
        // has already been superseded.
        const wakeReportsByNativeThread = yield* Ref.make<{
          readonly userTurns: ReadonlyMap<string, number>;
          readonly reports: ReadonlyMap<
            string,
            ReadonlyMap<string, { readonly report: BackgroundWorkReport; readonly turn: number }>
          >;
        }>({ userTurns: new Map(), reports: new Map() });
        // Subagents Claude started in the background. Only their ends wake the root.
        const backgroundedSubagentTaskIds = yield* Ref.make<ReadonlySet<string>>(new Set());
        // Subagents another subagent started (spawn_depth above 1). Claude
        // reports their end to the owning subagent, so it never wakes the root.
        const nestedSubagentTaskIds = yield* Ref.make<ReadonlySet<string>>(new Set());
        const isNestedSubagentTask = (taskId: string) =>
          Ref.get(nestedSubagentTaskIds).pipe(Effect.map((ids) => ids.has(taskId)));
        const recordWakeReport = (
          nativeThreadId: string,
          taskId: string,
          report: BackgroundWorkReport,
        ) =>
          Ref.update(wakeReportsByNativeThread, ({ userTurns, reports }) => ({
            userTurns,
            reports: new Map(reports).set(
              nativeThreadId,
              new Map(reports.get(nativeThreadId)).set(taskId, {
                report,
                turn: userTurns.get(nativeThreadId) ?? 0,
              }),
            ),
          }));
        const startUserTurnForWakeReports = (nativeThreadId: string) =>
          Ref.update(wakeReportsByNativeThread, ({ userTurns, reports }) => {
            const turn = (userTurns.get(nativeThreadId) ?? 0) + 1;
            const updatedTurns = new Map(userTurns).set(nativeThreadId, turn);
            const threadReports = reports.get(nativeThreadId);
            if (threadReports === undefined) return { userTurns: updatedTurns, reports };
            const kept = new Map([...threadReports].filter(([, entry]) => entry.turn >= turn - 1));
            const updatedReports = new Map(reports);
            if (kept.size === 0) updatedReports.delete(nativeThreadId);
            else updatedReports.set(nativeThreadId, kept);
            return { userTurns: updatedTurns, reports: updatedReports };
          });
        /** Removes and returns a thread's reports. */
        const takeWakeReports = (nativeThreadId: string) =>
          Ref.modify(wakeReportsByNativeThread, (current) => {
            const taken = current.reports.get(nativeThreadId);
            if (taken === undefined) return [taken, current] as const;
            const reports = new Map(current.reports);
            reports.delete(nativeThreadId);
            return [taken, { userTurns: current.userTurns, reports }] as const;
          });
        const clearWakeReports = (nativeThreadId: string) =>
          takeWakeReports(nativeThreadId).pipe(Effect.asVoid);
        // Last roster entry per opaque task. An empty roster level can land before
        // the task's notification, and the wake still needs to name the task.
        const lastKnownOpaqueTasks = yield* Ref.make(
          new Map<string, OrchestrationV2PendingBackgroundTask>(),
        );
        // Live Claude monitors. A Monitor call waits in `calls` until its
        // task_started links it to a task, or its tool_result ends the call
        // without one. A task stays in `tasks` until it leaves its native
        // thread's roster or its task_notification arrives, so a monitor is
        // never forgotten while it runs.
        const claudeMonitors = yield* Ref.make<{
          readonly calls: ReadonlySet<string>;
          readonly tasks: ReadonlyMap<
            string,
            { readonly toolUseId: string; readonly nativeThreadId: string }
          >;
        }>({ calls: new Set(), tasks: new Map() });
        const trackClaudeMonitorCalls = (message: SDKMessage) => {
          const started = claudeToolUseBlocksFromAssistantMessage(message).flatMap((toolUse) =>
            toolUse.name === "Monitor" ? [toolUse.id] : [],
          );
          const returned = [
            ...claudeToolResultBlocksFromAssistantMessage(message),
            ...claudeToolResultBlocksFromUserMessage(message),
          ].map((toolResult) => toolResult.tool_use_id);
          if (started.length === 0 && returned.length === 0) return Effect.void;
          return Ref.update(claudeMonitors, (current) => {
            // A replayed tool_use frame must not reopen a call whose task already started.
            const linked = new Set([...current.tasks.values()].map((task) => task.toolUseId));
            const opened = started.filter((id) => !linked.has(id) && !current.calls.has(id));
            const closed = returned.filter((id) => current.calls.has(id));
            if (opened.length === 0 && closed.length === 0) return current;
            const calls = new Set([...current.calls, ...opened]);
            for (const id of closed) calls.delete(id);
            return { ...current, calls };
          });
        };
        /** True when a Monitor call started this task; links the task to that call. */
        const isClaudeMonitorTask = (input: {
          readonly nativeThreadId: string;
          readonly taskId: string;
          readonly toolUseId: string | undefined;
        }) =>
          Ref.modify(claudeMonitors, (current) => {
            if (current.tasks.has(input.taskId)) return [true, current] as const;
            if (input.toolUseId === undefined || !current.calls.has(input.toolUseId)) {
              return [false, current] as const;
            }
            const calls = new Set(current.calls);
            calls.delete(input.toolUseId);
            const tasks = new Map(current.tasks).set(input.taskId, {
              toolUseId: input.toolUseId,
              nativeThreadId: input.nativeThreadId,
            });
            return [true, { calls, tasks }] as const;
          });
        /** Drops monitor tasks that ended: gone from the thread's roster, or notified. */
        const endClaudeMonitorTasks = (
          ended: (taskId: string, task: { readonly nativeThreadId: string }) => boolean,
        ) =>
          Ref.modify(claudeMonitors, (current) => {
            const endedIds = [...current.tasks].filter(([taskId, task]) => ended(taskId, task));
            if (endedIds.length === 0) return [current.tasks, current] as const;
            const tasks = new Map(current.tasks);
            for (const [taskId] of endedIds) tasks.delete(taskId);
            return [tasks, { ...current, tasks }] as const;
          });
        const claudeTaskOutcome = (status: "completed" | "failed" | "stopped") =>
          status === "completed" ? "completed" : status === "stopped" ? "cancelled" : "failed";
        // Reads the roster, so call it before the notification clears the task from it.
        const opaqueTaskWakeReport = Effect.fnUntraced(function* (
          nativeThreadId: string,
          message: Extract<SDKMessage, { readonly subtype: "task_notification" }>,
        ): Effect.fn.Return<BackgroundWorkReport> {
          const task =
            rosterForNativeThread(
              yield* Ref.get(pendingBackgroundTasksByNativeThread),
              nativeThreadId,
            ).get(message.task_id) ?? (yield* Ref.get(lastKnownOpaqueTasks)).get(message.task_id);
          yield* Ref.update(lastKnownOpaqueTasks, (current) => {
            if (!current.has(message.task_id)) return current;
            const updated = new Map(current);
            updated.delete(message.task_id);
            return updated;
          });
          const outcome = claudeTaskOutcome(message.status);
          const label = task?.description;
          switch (task?.kind) {
            case "subagent":
              return { kind: "subagent", label, outcome, childThreadId: task.childThreadId };
            case "monitor":
            case "background_task":
              return { kind: task.kind, label, outcome };
            case "command":
            case undefined:
              // Only local_bash is opaque background work today.
              return { kind: "command", label, outcome };
          }
        });
        const requestedContinuations = yield* Ref.make(new Set<string>());
        // ExitPlanMode plans whose permission callback fired while the tool's
        // root frames were held for a prompt echo. Each projects when its
        // tool_use frame is handled, in whichever run that frame is routed
        // to (the prompt's turn, or the continuation that drains a wake).
        const heldProposedPlansByToolUseId = new Map<string, string>();
        const runtimeContext = yield* Effect.context<never>();
        const runPromise = Effect.runPromiseWith(runtimeContext);

        const emitProviderEvent = (event: ProviderAdapter.ProviderAdapterV2Event) =>
          Queue.offer(events, event).pipe(Effect.asVoid);

        // Claude emits retry progress but no recovered frame; the next
        // assistant message is the first reliable evidence of recovery.
        const completeProviderRetry = Effect.fn("ClaudeAdapterV2.completeProviderRetry")(function* (
          context: ActiveClaudeTurnContext,
          updatedAt: DateTime.Utc,
        ) {
          const providerRetry = yield* Ref.modify(providerRetries, (current) => {
            const retry = current.get(context.providerTurnId);
            if (retry === undefined) {
              return [undefined, current] as const;
            }
            const updated = new Map(current);
            updated.delete(context.providerTurnId);
            return [retry, updated] as const;
          });
          if (providerRetry === undefined) {
            return;
          }
          yield* emitProviderEvent({
            type: "turn_item.updated",
            driver: CLAUDE_PROVIDER,
            turnItem: makeProviderRetryTurnItem({
              idAllocator,
              driver: CLAUDE_PROVIDER,
              threadId: context.input.threadId,
              runId: context.input.runId,
              nodeId: context.input.rootNodeId,
              providerThreadId: context.input.providerThread.id,
              providerTurnId: context.providerTurnId,
              itemOrdinal: providerRetry.itemOrdinal,
              failure: providerRetry.failure,
              retry: providerRetry.retry,
              status: "completed",
              startedAt: providerRetry.startedAt,
              updatedAt,
            }),
          });
        });

        const rememberProviderThread = (providerThread: OrchestrationV2ProviderThread) =>
          Effect.gen(function* () {
            const nativeThreadId = providerThread.nativeThreadRef?.nativeId;
            if (nativeThreadId === undefined || nativeThreadId === null) {
              return;
            }
            yield* Ref.update(lastProviderThreadByNativeThread, (current) =>
              new Map(current).set(nativeThreadId, providerThread),
            );
          });

        const rosterForNativeThread = (
          all: ReadonlyMap<string, Map<string, OrchestrationV2PendingBackgroundTask>>,
          nativeThreadId: string,
        ): Map<string, OrchestrationV2PendingBackgroundTask> =>
          all.get(nativeThreadId) ?? new Map<string, OrchestrationV2PendingBackgroundTask>();

        const hasPendingBackgroundTaskOnNativeThread = (nativeThreadId: string, taskId: string) =>
          Ref.get(pendingBackgroundTasksByNativeThread).pipe(
            Effect.map((all) => rosterForNativeThread(all, nativeThreadId).has(taskId)),
          );

        const taskIdSetForNativeThread = (
          all: ReadonlyMap<string, Set<string>>,
          nativeThreadId: string,
        ): Set<string> => all.get(nativeThreadId) ?? new Set<string>();

        const addTaskIdsToNativeThreadSet = (
          ref: Ref.Ref<Map<string, Set<string>>>,
          nativeThreadId: string,
          taskIds: ReadonlyArray<string>,
        ) =>
          Ref.update(ref, (current) => {
            if (taskIds.length === 0) {
              return current;
            }
            const next = new Set(taskIdSetForNativeThread(current, nativeThreadId));
            let changed = false;
            for (const taskId of taskIds) {
              if (!next.has(taskId)) {
                next.add(taskId);
                changed = true;
              }
            }
            return changed ? new Map(current).set(nativeThreadId, next) : current;
          });

        const clearTaskIdFromNativeThreadSet = (
          ref: Ref.Ref<Map<string, Set<string>>>,
          nativeThreadId: string,
          taskId: string,
        ) =>
          Ref.update(ref, (current) => {
            const existing = taskIdSetForNativeThread(current, nativeThreadId);
            if (!existing.has(taskId)) {
              return current;
            }
            const next = new Set(existing);
            next.delete(taskId);
            const updated = new Map(current);
            if (next.size === 0) {
              updated.delete(nativeThreadId);
            } else {
              updated.set(nativeThreadId, next);
            }
            return updated;
          });

        const clearNativeThreadTaskIdSet = (
          ref: Ref.Ref<Map<string, Set<string>>>,
          nativeThreadId: string,
        ) =>
          Ref.update(ref, (current) => {
            if (!current.has(nativeThreadId)) {
              return current;
            }
            const updated = new Map(current);
            updated.delete(nativeThreadId);
            return updated;
          });

        // First-notification wake offering only: not the Waiting roster and
        // not the post-buffer replay tombstone.
        const isWakeEligibleOpaqueBackgroundTaskOnNativeThread = (
          nativeThreadId: string,
          taskId: string,
        ) =>
          Ref.get(wakeEligibleBackgroundTasksByNativeThread).pipe(
            Effect.map((all) => taskIdSetForNativeThread(all, nativeThreadId).has(taskId)),
          );

        const hasOpaqueBackgroundTaskReplayTombstoneOnNativeThread = (
          nativeThreadId: string,
          taskId: string,
        ) =>
          Ref.get(opaqueBackgroundTaskReplayTombstonesByNativeThread).pipe(
            Effect.map((all) => taskIdSetForNativeThread(all, nativeThreadId).has(taskId)),
          );

        // Classify a task_notification as opaque local_bash (not a subagent):
        // live roster, still-eligible first notification, or short-lived
        // replay tombstone left after the idle notification was buffered.
        const isKnownOpaqueBackgroundTaskOnNativeThread = (
          nativeThreadId: string,
          taskId: string,
        ) =>
          Effect.gen(function* () {
            if (yield* hasPendingBackgroundTaskOnNativeThread(nativeThreadId, taskId)) {
              return true;
            }
            if (yield* isWakeEligibleOpaqueBackgroundTaskOnNativeThread(nativeThreadId, taskId)) {
              return true;
            }
            return yield* hasOpaqueBackgroundTaskReplayTombstoneOnNativeThread(
              nativeThreadId,
              taskId,
            );
          });

        // Admit onto wake eligibility only. Replay tombstones are created when
        // the first idle notification is buffered, not at task start.
        const markWakeEligibleOpaqueBackgroundTasks = (
          nativeThreadId: string,
          taskIds: ReadonlyArray<string>,
        ) =>
          addTaskIdsToNativeThreadSet(
            wakeEligibleBackgroundTasksByNativeThread,
            nativeThreadId,
            taskIds,
          );

        // After the first idle opaque notification is buffered/offered: stop
        // further wake buffering for this task id, but keep a replay tombstone
        // until the continuation drain classifies the buffered notification.
        const consumeWakeEligibilityForBufferedNotification = (
          nativeThreadId: string,
          taskId: string,
        ) =>
          Effect.gen(function* () {
            yield* clearTaskIdFromNativeThreadSet(
              wakeEligibleBackgroundTasksByNativeThread,
              nativeThreadId,
              taskId,
            );
            yield* addTaskIdsToNativeThreadSet(
              opaqueBackgroundTaskReplayTombstonesByNativeThread,
              nativeThreadId,
              [taskId],
            );
          });

        const clearOpaqueBackgroundTaskReplayTombstone = (nativeThreadId: string, taskId: string) =>
          clearTaskIdFromNativeThreadSet(
            opaqueBackgroundTaskReplayTombstonesByNativeThread,
            nativeThreadId,
            taskId,
          );

        const emitProviderThreadRoster = Effect.fnUntraced(function* (input: {
          readonly nativeThreadId: string;
          readonly providerThread: OrchestrationV2ProviderThread;
          readonly status?: OrchestrationV2ProviderThread["status"];
        }) {
          const roster = rosterForNativeThread(
            yield* Ref.get(pendingBackgroundTasksByNativeThread),
            input.nativeThreadId,
          );
          const now = yield* DateTime.now;
          const providerThread: OrchestrationV2ProviderThread = {
            ...input.providerThread,
            providerSessionId: session.id,
            ...(input.status === undefined ? {} : { status: input.status }),
            pendingBackgroundTasks: claudePendingBackgroundTasksFromRoster(roster),
            ...(goalsByNativeThread.has(input.nativeThreadId)
              ? { goal: goalsByNativeThread.get(input.nativeThreadId) ?? null }
              : {}),
            updatedAt: now,
          };
          yield* rememberProviderThread(providerThread);
          yield* emitProviderEvent({
            type: "provider_thread.updated",
            driver: CLAUDE_PROVIDER,
            providerThread,
          });
        });

        /** Applies one root frame's goal signal and writes any change onto the provider thread. */
        const trackClaudeGoal = Effect.fnUntraced(function* (input: {
          readonly nativeThreadId: string;
          readonly context: ActiveClaudeTurnContext;
          readonly message: SDKMessage;
        }) {
          const current = goalsByNativeThread.get(input.nativeThreadId) ?? null;
          if (
            current?.status === "active" &&
            input.message.type === "assistant" &&
            input.message.parent_tool_use_id === null &&
            input.message.message.model !== "<synthetic>"
          ) {
            goalCheckedTurns.add(input.context.providerTurnId);
          }
          const next = nextClaudeGoal(current, input.message);
          if (next === undefined || providerGoalsEqual(current, next)) return;
          goalsByNativeThread.set(input.nativeThreadId, next);
          const providerThread = (yield* Ref.get(lastProviderThreadByNativeThread)).get(
            input.nativeThreadId,
          );
          if (providerThread === undefined) return;
          const updated = { ...providerThread, goal: next, updatedAt: yield* DateTime.now };
          yield* rememberProviderThread(updated);
          yield* emitProviderEvent({
            type: "provider_thread.updated",
            driver: CLAUDE_PROVIDER,
            providerThread: updated,
          });
        });

        const rememberOpaqueTasks = (tasks: ReadonlyArray<OrchestrationV2PendingBackgroundTask>) =>
          tasks.length === 0
            ? Effect.void
            : Ref.update(lastKnownOpaqueTasks, (current) => {
                const updated = new Map(current);
                for (const task of tasks) updated.set(task.taskId, task);
                // Bounded: an entry only outlives its task when no notification came.
                for (const oldest of updated.keys()) {
                  if (updated.size <= 64) break;
                  updated.delete(oldest);
                }
                return updated;
              });

        const replacePendingBackgroundTasks = (
          nativeThreadId: string,
          tasks: ReadonlyArray<OrchestrationV2PendingBackgroundTask>,
        ) =>
          Effect.gen(function* () {
            yield* Ref.update(pendingBackgroundTasksByNativeThread, (current) => {
              const updated = new Map(current);
              if (tasks.length === 0) {
                updated.delete(nativeThreadId);
              } else {
                updated.set(
                  nativeThreadId,
                  new Map(tasks.map((task) => [task.taskId, task] as const)),
                );
              }
              return updated;
            });
            yield* rememberOpaqueTasks(tasks);
            // Empty level must not drop wake eligibility: notification may
            // still be in flight. Non-empty level admits new task ids to
            // wake eligibility only (replay tombstones are edge-created).
            if (tasks.length > 0) {
              yield* markWakeEligibleOpaqueBackgroundTasks(
                nativeThreadId,
                tasks.map((task) => task.taskId),
              );
            }
          });

        const upsertPendingBackgroundTask = (
          nativeThreadId: string,
          task: OrchestrationV2PendingBackgroundTask,
        ) =>
          Effect.gen(function* () {
            yield* Ref.update(pendingBackgroundTasksByNativeThread, (current) => {
              const roster = new Map(rosterForNativeThread(current, nativeThreadId));
              roster.set(task.taskId, task);
              return new Map(current).set(nativeThreadId, roster);
            });
            yield* rememberOpaqueTasks([task]);
            yield* markWakeEligibleOpaqueBackgroundTasks(nativeThreadId, [task.taskId]);
          });

        const clearPendingBackgroundTask = (nativeThreadId: string, taskId: string) =>
          Ref.modify(pendingBackgroundTasksByNativeThread, (current) => {
            const roster = rosterForNativeThread(current, nativeThreadId);
            if (!roster.has(taskId)) {
              return [false, current] as const;
            }
            const nextRoster = new Map(roster);
            nextRoster.delete(taskId);
            const updated = new Map(current);
            if (nextRoster.size === 0) {
              updated.delete(nativeThreadId);
            } else {
              updated.set(nativeThreadId, nextRoster);
            }
            return [true, updated] as const;
          });

        const clearPendingBackgroundTasksForNativeThread = (nativeThreadId: string) =>
          Effect.gen(function* () {
            yield* Ref.update(pendingBackgroundTasksByNativeThread, (current) => {
              if (!current.has(nativeThreadId)) {
                return current;
              }
              const updated = new Map(current);
              updated.delete(nativeThreadId);
              return updated;
            });
            // The thread's process died or its turn failed; those monitors never notify.
            yield* endClaudeMonitorTasks((_taskId, task) => task.nativeThreadId === nativeThreadId);
          });

        // Drop idle wake traffic for a dead native process so it cannot pin
        // session-wide pending work after sibling query replacement.
        const clearWakeStateForNativeThread = (nativeThreadId: string) =>
          Effect.gen(function* () {
            yield* clearWakeReports(nativeThreadId);
            yield* Ref.update(wakeBuffers, (current) => {
              if (!current.has(nativeThreadId)) {
                return current;
              }
              const updated = new Map(current);
              updated.delete(nativeThreadId);
              return updated;
            });
            yield* Ref.update(requestedContinuations, (current) => {
              if (!current.has(nativeThreadId)) {
                return current;
              }
              const updated = new Set(current);
              updated.delete(nativeThreadId);
              return updated;
            });
          });

        // Process-scoped level: SDK emits nothing at CLI start, so both the
        // Waiting roster and wake eligibility reset when a live query opens
        // or is replaced for this native thread. Opaque replay tombstones that
        // already covered buffered task_notification frames are restored so a
        // model/policy query replacement still classifies those local_bash
        // completions on continuation drain. Buffer membership alone must not
        // invent opaque classification: session-registered subagent
        // notifications share the same buffer.
        const resetBackgroundTaskStateForNativeThreadProcess = Effect.fnUntraced(function* (
          nativeThreadId: string,
          options?: {
            // openQuery during startTurn: activeTurn is not installed yet, but
            // ProviderTurnStartService already marked the provider thread active.
            readonly status?: OrchestrationV2ProviderThread["status"];
          },
        ) {
          const hadRoster =
            rosterForNativeThread(
              yield* Ref.get(pendingBackgroundTasksByNativeThread),
              nativeThreadId,
            ).size > 0;
          const remembered = (yield* Ref.get(lastProviderThreadByNativeThread)).get(nativeThreadId);
          const hadPersistedRoster = (remembered?.pendingBackgroundTasks?.length ?? 0) > 0;
          const priorOpaqueTombstones = taskIdSetForNativeThread(
            yield* Ref.get(opaqueBackgroundTaskReplayTombstonesByNativeThread),
            nativeThreadId,
          );
          const bufferedTaskNotificationIds = new Set<string>();
          const buffered = (yield* Ref.get(wakeBuffers)).get(nativeThreadId);
          if (buffered !== undefined) {
            for (const message of buffered.messages) {
              if (message.type === "system" && message.subtype === "task_notification") {
                bufferedTaskNotificationIds.add(message.task_id);
              }
            }
          }
          const preservedOpaqueTombstones = [...priorOpaqueTombstones].filter((taskId) =>
            bufferedTaskNotificationIds.has(taskId),
          );
          yield* clearPendingBackgroundTasksForNativeThread(nativeThreadId);
          yield* clearNativeThreadTaskIdSet(
            wakeEligibleBackgroundTasksByNativeThread,
            nativeThreadId,
          );
          yield* clearNativeThreadTaskIdSet(
            opaqueBackgroundTaskReplayTombstonesByNativeThread,
            nativeThreadId,
          );
          if (preservedOpaqueTombstones.length > 0) {
            yield* addTaskIdsToNativeThreadSet(
              opaqueBackgroundTaskReplayTombstonesByNativeThread,
              nativeThreadId,
              preservedOpaqueTombstones,
            );
          }
          if (!hadRoster && !hadPersistedRoster) {
            return;
          }
          if (remembered === undefined) {
            return;
          }
          // Prefer an explicit starting-turn status so a successful openQuery
          // replacement clear cannot emit idle over an already-active thread.
          // Otherwise: between turns never resurrect active from process reset;
          // with a live activeTurn context, upgrade idle → active.
          const activeContext = yield* Ref.get(activeTurn);
          const status =
            options?.status ??
            (activeContext === null
              ? ("idle" as const)
              : remembered.status === "idle"
                ? ("active" as const)
                : remembered.status);
          yield* emitProviderThreadRoster({
            nativeThreadId,
            providerThread: remembered,
            status,
          });
        });

        // A subagent's projection ids derive from its task id, so they are
        // the same whether this process created the subagent or not.
        const claudeSubagentIds = (context: ActiveClaudeTurnContext, taskId: string) => ({
          nodeId: idAllocator.derive.nodeFromProviderItem({
            driver: CLAUDE_PROVIDER,
            nativeItemId: `task:${taskId}`,
          }),
          childRootNodeId: idAllocator.derive.nodeFromProviderItem({
            driver: CLAUDE_PROVIDER,
            nativeItemId: `task:${taskId}:thread-root`,
          }),
          childThreadId: idAllocator.derive.threadFromProviderThread({
            driver: CLAUDE_PROVIDER,
            nativeThreadId: `${context.input.providerThread.id}:${taskId}`,
          }),
          turnItemId: idAllocator.derive.turnItemFromProviderItem({
            driver: CLAUDE_PROVIDER,
            nativeItemId: `task:${taskId}:subagent`,
          }),
        });

        const resolveItemOrdinal = (context: ActiveClaudeTurnContext, nativeItemId: string) =>
          Effect.sync(() => {
            const existing = context.itemOrdinals.get(nativeItemId);
            if (existing !== undefined) {
              return existing;
            }
            const ordinal = context.input.providerTurnOrdinal * 100 + context.itemOrdinals.size + 1;
            context.itemOrdinals.set(nativeItemId, ordinal);
            return ordinal;
          });

        const providerTurnPayload = (input: {
          readonly context: ActiveClaudeTurnContext;
          readonly status: OrchestrationV2ProviderTurn["status"];
          readonly completedAt: DateTime.Utc | null;
        }): OrchestrationV2ProviderTurn => ({
          id: input.context.providerTurnId,
          providerThreadId: input.context.input.providerThread.id,
          nodeId: input.context.input.rootNodeId,
          runAttemptId: input.context.input.attemptId,
          nativeTurnRef: {
            driver: CLAUDE_PROVIDER,
            nativeId: input.context.nativeMessageCursor ?? input.context.nativeTurnId,
            strength: "weak",
          },
          ordinal: input.context.providerTurnOrdinal,
          status: input.status,
          startedAt: input.context.startedAt,
          completedAt: input.completedAt,
        });

        const buildToolCallArtifacts = (input: {
          readonly context: ActiveClaudeTurnContext;
          readonly nativeItemId: string;
          readonly toolName: string;
          readonly classification: ClaudeToolClassification;
          readonly toolInput: ClaudeNativeToolInput;
          readonly threadId: ThreadId;
          readonly runId: ProviderAdapter.ProviderAdapterV2TurnInput["runId"] | null;
          readonly rootNodeId: OrchestrationV2ExecutionNode["id"];
          readonly parentNodeId: OrchestrationV2ExecutionNode["id"];
          readonly ordinal: number;
          readonly output: ClaudeNativeToolOutput;
          readonly status: Extract<
            OrchestrationV2TurnItem["status"],
            "running" | "completed" | "failed" | "interrupted" | "cancelled"
          >;
          readonly startedAt: DateTime.Utc;
          readonly updatedAt: DateTime.Utc;
          readonly presentation: ClaudeToolPresentation | undefined;
          readonly toolNonExecutionKind?: string;
        }) => {
          const completedAt = input.status === "running" ? null : input.updatedAt;
          const nodeId = idAllocator.derive.nodeFromProviderItem({
            driver: CLAUDE_PROVIDER,
            nativeItemId: input.nativeItemId,
          });
          const turnItemId = idAllocator.derive.turnItemFromProviderItem({
            driver: CLAUDE_PROVIDER,
            nativeItemId: input.nativeItemId,
          });
          const nativeItemRef = {
            driver: CLAUDE_PROVIDER,
            nativeId: input.nativeItemId,
            strength: "strong" as const,
          };
          const node: OrchestrationV2ExecutionNode = {
            id: nodeId,
            threadId: input.threadId,
            runId: input.runId,
            parentNodeId: input.parentNodeId,
            rootNodeId: input.rootNodeId,
            kind: "tool_call",
            status: input.status,
            countsForRun: false,
            providerThreadId: input.runId === null ? null : input.context.input.providerThread.id,
            providerTurnId: input.runId === null ? null : input.context.providerTurnId,
            nativeItemRef,
            runtimeRequestId: null,
            checkpointScopeId: null,
            startedAt: input.startedAt,
            completedAt,
          };
          const readPath = ["read", "read file"].includes(input.classification.normalizedName)
            ? firstStringInputField(input.toolInput, ["file_path", "path"])?.trim()
            : undefined;
          const nativeToolInput = claudeNativeToolInputValue(input.toolInput);
          const searchTitle = ["grep", "glob", "ls"].includes(input.classification.normalizedName)
            ? formatSearchToolLabel({
                input:
                  nativeToolInput !== null &&
                  typeof nativeToolInput === "object" &&
                  !Array.isArray(nativeToolInput)
                    ? (nativeToolInput as Record<string, unknown>)
                    : undefined,
              })
            : undefined;
          const itemBase = {
            ...(input.toolNonExecutionKind === undefined
              ? {}
              : { toolNonExecutionKind: input.toolNonExecutionKind }),
            id: turnItemId,
            threadId: input.threadId,
            runId: input.runId,
            nodeId,
            providerThreadId: input.runId === null ? null : input.context.input.providerThread.id,
            providerTurnId: input.runId === null ? null : input.context.providerTurnId,
            nativeItemRef,
            parentItemId: null,
            ordinal: input.ordinal,
            status: input.status,
            title:
              readPath !== undefined
                ? formatReadToolLabel(readPath)
                : (searchTitle ??
                  dynamicToolTitle(input.toolName, nativeToolInput) ??
                  input.presentation?.title ??
                  null),
            startedAt: input.startedAt,
            completedAt,
            updatedAt: input.updatedAt,
          } satisfies Pick<
            OrchestrationV2TurnItem,
            | "id"
            | "threadId"
            | "runId"
            | "nodeId"
            | "providerThreadId"
            | "providerTurnId"
            | "nativeItemRef"
            | "parentItemId"
            | "ordinal"
            | "status"
            | "title"
            | "startedAt"
            | "completedAt"
            | "updatedAt"
          >;
          const viewedImagePath =
            readPath &&
            readPath.length <= 4096 &&
            !/[\r\n]/.test(readPath) &&
            isWorkspaceImagePreviewPath(readPath)
              ? readPath
              : undefined;
          const itemType = input.classification.itemType;
          const webSearchPatterns = webSearchPatternsFromClaudeTool({
            toolInput: input.toolInput,
            output: input.output,
          });
          const webSearchResults = webSearchResultsFromClaudeOutput(input.output);
          const webFetchUrl = firstStringInputField(input.toolInput, ["url"])?.trim();
          const outputValue = claudeNativeToolOutputValue(input.output);
          const outputText =
            itemType === "command_execution"
              ? claudeCommandOutputText(input.output)
              : claudeNativeToolOutputText(input.output);
          const turnItem: OrchestrationV2TurnItem =
            itemType === "command_execution"
              ? {
                  ...itemBase,
                  type: "command_execution",
                  input: commandInputFromClaudeTool(input.toolName, input.toolInput),
                  ...(outputText.length === 0 ? {} : { output: outputText }),
                }
              : itemType === "file_change"
                ? {
                    ...itemBase,
                    type: "file_change",
                    fileName: fileNameFromClaudeTool(input.toolName, input.toolInput),
                    ...(outputText.length === 0 ? {} : { diffStr: outputText }),
                  }
                : itemType === "web_search"
                  ? {
                      ...itemBase,
                      type: "web_search",
                      ...(webSearchPatterns.length === 0
                        ? {}
                        : { patterns: [...webSearchPatterns] }),
                      ...(webSearchResults.length > 0
                        ? { results: [...webSearchResults] }
                        : input.classification.normalizedName === "webfetch" &&
                            outputText.trim().length > 0
                          ? {
                              // WebFetch returns page text, not search hits. Keep a
                              // bounded preview so the row has something to show.
                              results: [
                                {
                                  ...(webFetchUrl === undefined ? {} : { url: webFetchUrl }),
                                  snippet: outputText.slice(0, WEB_FETCH_SNIPPET_MAX_CHARS),
                                },
                              ],
                            }
                          : {}),
                    }
                  : {
                      ...itemBase,
                      type: "dynamic_tool",
                      ...(input.presentation?.toolIcon === undefined
                        ? {}
                        : { toolIcon: input.presentation.toolIcon }),
                      ...(input.presentation?.toolSource === undefined
                        ? {}
                        : { toolSource: input.presentation.toolSource }),
                      toolName: input.toolName,
                      ...(viewedImagePath === undefined ? {} : { viewedImagePath }),
                      input: claudeNativeToolInputValue(input.toolInput),
                      ...(outputValue === undefined ? {} : { output: outputValue }),
                    };
          return { node, turnItem };
        };

        const emitToolCallArtifacts = Effect.fnUntraced(function* (artifacts: {
          readonly node: OrchestrationV2ExecutionNode;
          readonly turnItem: OrchestrationV2TurnItem;
        }) {
          yield* emitProviderEvent({
            type: "node.updated",
            driver: CLAUDE_PROVIDER,
            node: artifacts.node,
          });
          yield* emitProviderEvent({
            type: "turn_item.updated",
            driver: CLAUDE_PROVIDER,
            turnItem: artifacts.turnItem,
          });
        });

        // A subagent launched before a server restart is missing from the
        // registry when SendMessage resumes it. The resume's task_started
        // names only the SendMessage call, while the resumed run's frames
        // carry the launch call as parent_tool_use_id, which only the CLI's
        // session storage still records. Registering the subagent as a
        // finished run lets the resume reopen it like an in-session resume:
        // same child thread, launch prompt kept, the new prompt appended.
        const recoverResumedClaudeSubagent = Effect.fnUntraced(function* (resume: {
          readonly context: ActiveClaudeTurnContext;
          readonly nativeThreadId: string;
          readonly taskId: string;
          readonly toolUseId: string | undefined;
          readonly title: string;
        }) {
          // An Agent launch never enters toolCalls, so a task_started under a
          // tracked tool call is a resume.
          if (
            resume.toolUseId === undefined ||
            !resume.context.toolCalls.has(resume.toolUseId) ||
            resume.context.subagentsByTaskId.has(resume.taskId) ||
            (yield* Ref.get(sessionSubagentsByTaskId)).has(resume.taskId)
          ) {
            return;
          }
          const launchToolUseId = yield* queryRunner
            .subagentLaunchToolUseId({
              sessionId: resume.nativeThreadId,
              agentId: resume.taskId,
              dir: resume.context.input.runtimePolicy.cwd,
              threadId: resume.context.input.threadId,
              providerSessionId: input.providerSessionId,
            })
            .pipe(
              Effect.catch(() =>
                Effect.logWarning("orchestration-v2.claude-subagent-launch-lookup-failed", {
                  taskId: resume.taskId,
                }).pipe(Effect.as(null)),
              ),
            );
          if (launchToolUseId === null || launchToolUseId === resume.toolUseId) {
            return;
          }
          const ids = claudeSubagentIds(resume.context, resume.taskId);
          const now = yield* DateTime.now;
          const subagent: ActiveClaudeSubagent = {
            task: {
              id: ids.nodeId,
              threadId: resume.context.input.threadId,
              runId: resume.context.input.runId,
              parentNodeId: resume.context.input.rootNodeId,
              origin: "provider_native",
              createdBy: "agent",
              driver: CLAUDE_PROVIDER,
              providerInstanceId: resume.context.input.modelSelection.instanceId,
              providerThreadId: null,
              childThreadId: ids.childThreadId,
              nativeTaskRef: {
                driver: CLAUDE_PROVIDER,
                nativeId: resume.taskId,
                strength: "strong",
              },
              prompt: "",
              title: resume.title,
              model: null,
              result: null,
              status: "completed",
              startedAt: now,
              completedAt: now,
              updatedAt: now,
            },
            rootNodeId: resume.context.input.rootNodeId,
            childThreadId: ids.childThreadId,
            childRootNodeId: ids.childRootNodeId,
            turnItemId: ids.turnItemId,
            turnItemOrdinal: yield* resolveItemOrdinal(
              resume.context,
              `task:${resume.taskId}:subagent`,
            ),
            runToolUseId: launchToolUseId,
            nextChildItemOrdinal: 100,
            resultItemOrdinal: null,
            lastAssistantText: null,
            lastAssistantMessageId: null,
          };
          yield* Ref.update(sessionSubagentsByTaskId, (current) =>
            new Map(current).set(resume.taskId, subagent),
          );
          yield* Ref.update(sessionSubagentTaskIdsByToolUseId, (current) =>
            new Map(current).set(launchToolUseId, resume.taskId),
          );
        });

        const updateClaudeSubagentNode = Effect.fnUntraced(function* (input: {
          readonly context: ActiveClaudeTurnContext;
          readonly taskId: string;
          readonly toolUseId?: string;
          readonly prompt?: string;
          readonly title?: string;
          readonly model?: string;
          // The subagent whose own Agent call started this one; read only
          // when this call registers the subagent.
          readonly owner?: ActiveClaudeSubagent;
          readonly progress?: string;
          readonly result?: string;
          readonly status: Extract<
            OrchestrationV2ExecutionNode["status"],
            "running" | "completed" | "failed" | "cancelled"
          >;
          readonly reopen?: boolean;
        }) {
          // The session registry lets a wake-replay turn (fresh context maps)
          // hydrate a subagent that was created by an earlier, settled turn.
          const existingSubagent =
            input.context.subagentsByTaskId.get(input.taskId) ??
            (input.toolUseId === undefined
              ? undefined
              : input.context.subagentsByToolUseId.get(input.toolUseId)) ??
            (yield* Ref.get(sessionSubagentsByTaskId)).get(input.taskId);
          if (existingSubagent === undefined && input.status !== "running") {
            return;
          }
          // Status is monotone with one exception: task_started for a known
          // task id is an authoritative CLI lifecycle event (SendMessage to a
          // completed subagent resumes it and re-emits task_started with the
          // same id), so it may re-open a terminal entry. A late or
          // out-of-order task_progress must not.
          const isReopen =
            input.reopen === true &&
            existingSubagent !== undefined &&
            existingSubagent.task.status !== "running" &&
            input.status === "running";
          if (
            existingSubagent !== undefined &&
            existingSubagent.task.status !== "running" &&
            input.status === "running" &&
            !isReopen
          ) {
            return;
          }
          // A task_started under a tool call other than the current run's is
          // a resume: SendMessage re-emits task_started for the same task id
          // under its own tool_use_id, with the sent message as the prompt.
          const resumeToolUseId =
            input.reopen === true &&
            existingSubagent !== undefined &&
            input.toolUseId !== undefined &&
            input.toolUseId !== existingSubagent.runToolUseId &&
            input.prompt !== undefined
              ? input.toolUseId
              : null;
          const lifecycleChanged =
            existingSubagent === undefined ||
            existingSubagent.task.status !== input.status ||
            // A drain-replayed resume task_started finds the registry entry
            // already pre-opened to running by bufferWakeMessage while the
            // projection node still holds the old terminal status; re-emit
            // the node lifecycle for authoritative task_started updates.
            (input.reopen === true && input.status === "running");

          const now = yield* DateTime.now;
          const nativeItemId = `task:${input.taskId}`;
          const derivedIds = claudeSubagentIds(input.context, input.taskId);
          const nodeId = existingSubagent?.task.id ?? derivedIds.nodeId;
          const childRootNodeId = existingSubagent?.childRootNodeId ?? derivedIds.childRootNodeId;
          const childThreadId = existingSubagent?.childThreadId ?? derivedIds.childThreadId;
          if (existingSubagent === undefined) {
            input.context.subagentNodesByTaskId.set(input.taskId, nodeId);
          }
          const turnItemOrdinal =
            existingSubagent?.turnItemOrdinal ??
            (yield* resolveItemOrdinal(input.context, `${nativeItemId}:subagent`));
          // A resumed subagent's previous final answer and progress no longer
          // represent its outcome; the next task_progress/task_notification
          // carry the new ones.
          const priorTask =
            existingSubagent === undefined
              ? undefined
              : isReopen
                ? (({ progress: _staleProgress, ...rest }) => ({ ...rest, result: null }))(
                    existingSubagent.task,
                  )
                : existingSubagent.task;
          const task = {
            ...(priorTask ?? {
              id: nodeId,
              threadId: input.context.input.threadId,
              runId: input.context.input.runId,
              parentNodeId: input.owner?.task.id ?? input.context.input.rootNodeId,
              origin: "provider_native" as const,
              createdBy: "agent" as const,
              driver: CLAUDE_PROVIDER,
              providerInstanceId: input.context.input.modelSelection.instanceId,
              providerThreadId: null,
              childThreadId,
              nativeTaskRef: {
                driver: CLAUDE_PROVIDER,
                nativeId: input.taskId,
                strength: "strong" as const,
              },
              prompt: input.prompt ?? "",
              title: input.title ?? null,
              model: input.model ?? null,
              result: null,
              startedAt: now,
            }),
            status: input.status,
            // A reopen replayed under a continuation run re-attributes the
            // subagent to that run. RunExecutionService routes parent-thread
            // events by runId, and only the resuming run's ingestion fiber is
            // guaranteed alive (the launch run's fiber stops once its child
            // subagents terminalize); attribution also enrolls the subagent
            // in the resuming run's active-child tracking so its fiber
            // outlives settle until the resumed task completes.
            ...(input.reopen === true &&
            input.status === "running" &&
            existingSubagent !== undefined
              ? { runId: input.context.input.runId }
              : {}),
            ...(input.prompt === undefined ? {} : { prompt: input.prompt }),
            ...(input.title === undefined ? {} : { title: input.title }),
            ...(input.model === undefined ? {} : { model: input.model }),
            ...(input.progress === undefined ? {} : { progress: input.progress }),
            ...(input.result === undefined ? {} : { result: input.result }),
            ...(isReopen ? { startedAt: now } : {}),
            completedAt: input.status === "running" ? null : (priorTask?.completedAt ?? now),
            updatedAt: now,
          } satisfies OrchestrationV2Subagent;
          const subagent = {
            task,
            rootNodeId: existingSubagent?.rootNodeId ?? input.context.input.rootNodeId,
            childThreadId,
            childRootNodeId,
            turnItemId: existingSubagent?.turnItemId ?? derivedIds.turnItemId,
            turnItemOrdinal,
            runToolUseId:
              existingSubagent === undefined
                ? (input.toolUseId ?? null)
                : (resumeToolUseId ?? existingSubagent.runToolUseId),
            nextChildItemOrdinal: existingSubagent?.nextChildItemOrdinal ?? 100,
            resultItemOrdinal: existingSubagent?.resultItemOrdinal ?? null,
            // Every task_started begins a new run of the subagent (including a
            // resume that bufferWakeMessage already pre-opened), so text from
            // an earlier run can no longer stand in for the next result.
            lastAssistantText:
              input.reopen === true ? null : (existingSubagent?.lastAssistantText ?? null),
            lastAssistantMessageId:
              input.reopen === true ? null : (existingSubagent?.lastAssistantMessageId ?? null),
          } satisfies ActiveClaudeSubagent;
          input.context.subagentsByTaskId.set(input.taskId, subagent);
          if (input.toolUseId !== undefined) {
            input.context.subagentsByToolUseId.set(input.toolUseId, subagent);
            const toolUseId = input.toolUseId;
            yield* Ref.update(sessionSubagentTaskIdsByToolUseId, (current) =>
              current.get(toolUseId) === input.taskId
                ? current
                : new Map(current).set(toolUseId, input.taskId),
            );
          }
          // The same terminal protection, applied atomically: a concurrent
          // fiber (live stream vs continuation drain) may have terminalized
          // the registry entry after this update's lookup read it. A resume
          // re-open (task_started) bypasses it only when the registered entry
          // is still the terminal generation the lookup resolved; if a
          // concurrent fiber installed a newer terminal entry meanwhile, the
          // re-open must not clobber its result.
          yield* Ref.update(sessionSubagentsByTaskId, (current) => {
            const registered = current.get(input.taskId);
            if (
              registered !== undefined &&
              registered.task.status !== "running" &&
              input.status === "running" &&
              !(isReopen && registered === existingSubagent)
            ) {
              return current;
            }
            return new Map(current).set(input.taskId, subagent);
          });

          if (existingSubagent === undefined) {
            const childThread = makeSubagentChildThread({
              parentThread: input.context.input.appThread,
              childThreadId,
              parentNodeId: nodeId,
              activeProviderThreadId: null,
              providerInstanceId: input.context.input.modelSelection.instanceId,
              modelSelection:
                task.model && task.model !== input.context.input.modelSelection.model
                  ? { instanceId: input.context.input.modelSelection.instanceId, model: task.model }
                  : input.context.input.modelSelection,
              title: subagentThreadTitle({
                parentTitle: input.context.input.appThread.title,
                prompt: task.prompt,
                title: task.title,
                ordinal: input.context.subagentsByTaskId.size,
              }),
              now,
              createdBy: "agent",
              creationSource: "provider",
            });
            yield* emitProviderEvent({
              type: "app_thread.created",
              driver: CLAUDE_PROVIDER,
              appThread: childThread,
            });
          }

          if (lifecycleChanged) {
            yield* emitProviderEvent({
              type: "node.updated",
              driver: CLAUDE_PROVIDER,
              node: {
                id: nodeId,
                // Parenting stays with the launch run's root node (or the
                // owning subagent) even on wake-replay; runId follows
                // task.runId, which a reopen re-attributes to the resuming run
                // (see task construction).
                threadId: task.threadId,
                runId: task.runId,
                parentNodeId: task.parentNodeId,
                rootNodeId: subagent.rootNodeId,
                kind: "subagent",
                status: input.status,
                countsForRun: false,
                providerThreadId: input.context.input.providerThread.id,
                providerTurnId: input.context.providerTurnId,
                nativeItemRef: {
                  driver: CLAUDE_PROVIDER,
                  nativeId: input.taskId,
                  strength: "strong",
                },
                runtimeRequestId: null,
                checkpointScopeId: null,
                startedAt: task.startedAt,
                completedAt: task.completedAt,
              },
            });
            yield* emitProviderEvent({
              type: "node.updated",
              driver: CLAUDE_PROVIDER,
              node: {
                id: childRootNodeId,
                threadId: childThreadId,
                runId: null,
                parentNodeId: null,
                rootNodeId: childRootNodeId,
                kind: "root_turn",
                status: input.status,
                countsForRun: false,
                providerThreadId: null,
                providerTurnId: null,
                nativeItemRef: task.nativeTaskRef,
                runtimeRequestId: null,
                checkpointScopeId: null,
                startedAt: task.startedAt,
                completedAt: task.completedAt,
              },
            });
          }
          // Each run opens with its own prompt in the child thread: the launch
          // task, then every message that resumes the subagent.
          const promptNativeItemId =
            existingSubagent === undefined
              ? `${nativeItemId}:prompt`
              : resumeToolUseId === null
                ? null
                : `${nativeItemId}:prompt:${resumeToolUseId}`;
          if (promptNativeItemId !== null) {
            const promptArtifacts = makeSubagentConversationArtifacts({
              senderThreadId: input.context.input.threadId,
              messageId: idAllocator.derive.messageFromProviderItem({
                driver: CLAUDE_PROVIDER,
                nativeItemId: promptNativeItemId,
              }),
              turnItemId: idAllocator.derive.turnItemFromProviderItem({
                driver: CLAUDE_PROVIDER,
                nativeItemId: promptNativeItemId,
              }),
              threadId: childThreadId,
              rootNodeId: childRootNodeId,
              providerThreadId: null,
              providerTurnId: null,
              nativeItemRef: {
                driver: CLAUDE_PROVIDER,
                nativeId: promptNativeItemId,
                strength: "strong",
              },
              role: "user",
              text: task.prompt,
              ordinal: existingSubagent === undefined ? 100 : ++subagent.nextChildItemOrdinal,
              now,
            });
            yield* emitProviderEvent({
              type: "message.updated",
              driver: CLAUDE_PROVIDER,
              message: promptArtifacts.message,
            });
            yield* emitProviderEvent({
              type: "turn_item.updated",
              driver: CLAUDE_PROVIDER,
              turnItem: promptArtifacts.turnItem,
            });
          }
          yield* emitProviderEvent({
            type: "subagent.updated",
            driver: CLAUDE_PROVIDER,
            subagent: task,
          });
          yield* emitProviderEvent({
            type: "turn_item.updated",
            driver: CLAUDE_PROVIDER,
            turnItem: {
              id: subagent.turnItemId,
              threadId: task.threadId,
              runId: task.runId,
              nodeId: task.id,
              providerThreadId: input.context.input.providerThread.id,
              providerTurnId: input.context.providerTurnId,
              nativeItemRef: task.nativeTaskRef,
              parentItemId: null,
              ordinal: subagent.turnItemOrdinal,
              status: task.status,
              title: task.title,
              startedAt: task.startedAt,
              completedAt: task.completedAt,
              updatedAt: task.updatedAt,
              type: "subagent",
              subagentId: task.id,
              origin: task.origin,
              driver: task.driver,
              providerInstanceId: task.providerInstanceId,
              childThreadId: task.childThreadId,
              prompt: task.prompt,
              ...(task.progress === undefined ? {} : { progress: task.progress }),
              result: task.result,
            },
          });

          // A completed subagent's result is normally its final assistant
          // message, which is already in the child thread when its text was
          // routed there. Failures and cancellations always get the message.
          const resultAlreadyShown =
            input.status === "completed" &&
            input.result !== undefined &&
            normalizeClaudeResultText(subagent.lastAssistantText ?? "") ===
              normalizeClaudeResultText(input.result);
          if (
            input.result !== undefined &&
            input.result.trim().length > 0 &&
            input.status !== "running" &&
            !resultAlreadyShown
          ) {
            const resultNativeItemId = `${nativeItemId}:result`;
            const resultItemOrdinal = subagent.resultItemOrdinal ?? ++subagent.nextChildItemOrdinal;
            subagent.resultItemOrdinal = resultItemOrdinal;
            const resultArtifacts = makeSubagentConversationArtifacts({
              messageId: idAllocator.derive.messageFromProviderItem({
                driver: CLAUDE_PROVIDER,
                nativeItemId: resultNativeItemId,
              }),
              turnItemId: idAllocator.derive.turnItemFromProviderItem({
                driver: CLAUDE_PROVIDER,
                nativeItemId: resultNativeItemId,
              }),
              threadId: childThreadId,
              rootNodeId: childRootNodeId,
              providerThreadId: null,
              providerTurnId: null,
              nativeItemRef: {
                driver: CLAUDE_PROVIDER,
                nativeId: resultNativeItemId,
                strength: "strong",
              },
              role: "assistant",
              text: input.result,
              ordinal: resultItemOrdinal,
              now,
            });
            yield* emitProviderEvent({
              type: "message.updated",
              driver: CLAUDE_PROVIDER,
              message: resultArtifacts.message,
            });
            yield* emitProviderEvent({
              type: "turn_item.updated",
              driver: CLAUDE_PROVIDER,
              turnItem: resultArtifacts.turnItem,
            });
          }
        });

        const emitClaudePlanProjection = Effect.fnUntraced(function* (input: {
          readonly context: ActiveClaudeTurnContext;
          readonly nativeItemId: string;
          readonly kind: "todo_list" | "proposed_plan";
          readonly steps?: ReadonlyArray<OrchestrationV2PlanStep>;
          readonly markdown?: string;
        }) {
          const updatedAt = yield* DateTime.now;
          const projectionNativeItemId = `${input.kind}:${input.nativeItemId}`;
          const planKey = `${input.context.input.threadId}:${projectionNativeItemId}`;
          const existingPlanId = (yield* Ref.get(planIdsByNativeItem)).get(planKey);
          const planId =
            existingPlanId ??
            (yield* idAllocator.allocate.plan({
              threadId: input.context.input.threadId,
              runId: input.context.input.runId,
              driver: CLAUDE_PROVIDER,
            }));
          if (existingPlanId === undefined) {
            yield* Ref.update(planIdsByNativeItem, (current) => {
              const updated = new Map(current);
              updated.set(planKey, planId);
              return updated;
            });
          }
          const nodeId = idAllocator.derive.nodeFromProviderItem({
            driver: CLAUDE_PROVIDER,
            nativeItemId: projectionNativeItemId,
          });
          const nativeItemRef = {
            driver: CLAUDE_PROVIDER,
            nativeId: input.nativeItemId,
            strength: "strong" as const,
          };
          const ordinal = yield* resolveItemOrdinal(input.context, projectionNativeItemId);
          const steps = [...(input.steps ?? [])];
          const todoStatus = steps.every((step) => step.status === "completed")
            ? "completed"
            : "active";
          const plan: OrchestrationV2PlanArtifact =
            input.kind === "todo_list"
              ? {
                  id: planId,
                  threadId: input.context.input.threadId,
                  runId: input.context.input.runId,
                  nodeId,
                  kind: "todo_list",
                  status: todoStatus,
                  steps,
                }
              : {
                  id: planId,
                  threadId: input.context.input.threadId,
                  runId: input.context.input.runId,
                  nodeId,
                  kind: "proposed_plan",
                  status: "active",
                  markdown: input.markdown ?? "",
                };
          const node: OrchestrationV2ExecutionNode = {
            id: nodeId,
            threadId: input.context.input.threadId,
            runId: input.context.input.runId,
            parentNodeId: input.context.input.rootNodeId,
            rootNodeId: input.context.input.rootNodeId,
            kind: input.kind === "todo_list" ? "todo_list" : "plan",
            status: "completed",
            countsForRun: false,
            providerThreadId: input.context.input.providerThread.id,
            providerTurnId: input.context.providerTurnId,
            nativeItemRef,
            runtimeRequestId: null,
            checkpointScopeId: null,
            startedAt: updatedAt,
            completedAt: updatedAt,
          };
          const common = {
            id: idAllocator.derive.turnItemFromProviderItem({
              driver: CLAUDE_PROVIDER,
              nativeItemId: projectionNativeItemId,
            }),
            threadId: input.context.input.threadId,
            runId: input.context.input.runId,
            nodeId,
            providerThreadId: input.context.input.providerThread.id,
            providerTurnId: input.context.providerTurnId,
            nativeItemRef,
            parentItemId: null,
            ordinal,
            status: "completed" as const,
            title: null,
            startedAt: updatedAt,
            completedAt: updatedAt,
            updatedAt,
          };
          const turnItem: OrchestrationV2TurnItem =
            input.kind === "todo_list"
              ? { ...common, type: "todo_list", planId, steps }
              : {
                  ...common,
                  type: "proposed_plan",
                  planId,
                  markdown: input.markdown ?? "",
                  streaming: false,
                };
          const latestPlanKey = `${input.context.input.threadId}:${input.kind}`;
          const previousPlan = (yield* Ref.get(latestPlanByKind)).get(latestPlanKey);
          yield* Effect.all(
            [
              ...(previousPlan === undefined ||
              previousPlan.id === plan.id ||
              previousPlan.status === "completed"
                ? []
                : [
                    emitProviderEvent({
                      type: "plan.updated" as const,
                      driver: CLAUDE_PROVIDER,
                      plan: { ...previousPlan, status: "superseded" as const },
                    }),
                  ]),
              emitProviderEvent({ type: "node.updated", driver: CLAUDE_PROVIDER, node }),
              emitProviderEvent({ type: "plan.updated", driver: CLAUDE_PROVIDER, plan }),
              emitProviderEvent({ type: "turn_item.updated", driver: CLAUDE_PROVIDER, turnItem }),
            ],
            { concurrency: 1 },
          );
          yield* Ref.update(latestPlanByKind, (current) => {
            const updated = new Map(current);
            updated.set(latestPlanKey, plan);
            return updated;
          });
        });

        // Resolves the subagent that owns a parent_tool_use_id. The session
        // registry is authoritative: every update replaces the subagent
        // object, and per-turn tool-use aliases can lag behind (updates
        // without a toolUseId) or be empty (a turn other than the one that
        // launched the subagent). Mutations must land on the current object.
        const resolveSubagentByToolUseId = Effect.fnUntraced(function* (
          context: ActiveClaudeTurnContext,
          toolUseId: string,
        ) {
          const taskId = (yield* Ref.get(sessionSubagentTaskIdsByToolUseId)).get(toolUseId);
          const registered =
            taskId === undefined
              ? undefined
              : (yield* Ref.get(sessionSubagentsByTaskId)).get(taskId);
          return registered ?? context.subagentsByToolUseId.get(toolUseId);
        });

        const ensureToolCallStarted = Effect.fnUntraced(function* (input: {
          readonly context: ActiveClaudeTurnContext;
          readonly nativeItemId: string;
          readonly toolName: string;
          readonly toolInput: ClaudeNativeToolInput;
          readonly parentToolUseId: string | null;
          readonly presentation?: ClaudeToolPresentation | undefined;
        }) {
          const existing = input.context.toolCalls.get(input.nativeItemId);
          if (existing !== undefined) {
            // The permission callback can start a call before its assistant
            // frame arrives with the tool's display name and icon.
            if (input.presentation === undefined || existing.presentation !== undefined) {
              return existing;
            }
            const presented = { ...existing, presentation: input.presentation };
            input.context.toolCalls.set(input.nativeItemId, presented);
            const updatedAt = yield* DateTime.now;
            yield* emitToolCallArtifacts(
              buildToolCallArtifacts({
                context: input.context,
                nativeItemId: presented.nativeItemId,
                toolName: presented.toolName,
                classification: presented.classification,
                toolInput: presented.input,
                threadId: presented.threadId,
                runId: presented.runId,
                rootNodeId: presented.rootNodeId,
                parentNodeId: presented.parentNodeId,
                ordinal: presented.ordinal,
                output: NO_CLAUDE_NATIVE_TOOL_OUTPUT,
                status: "running",
                startedAt: presented.startedAt,
                updatedAt,
                presentation: input.presentation,
              }),
            );
            return presented;
          }
          const startedAt = yield* DateTime.now;
          const classification = classifyClaudeNativeTool(input.toolName);
          const subagent =
            input.parentToolUseId === null
              ? undefined
              : yield* resolveSubagentByToolUseId(input.context, input.parentToolUseId);
          const threadId = subagent?.childThreadId ?? input.context.input.threadId;
          const runId = subagent === undefined ? input.context.input.runId : null;
          const rootNodeId = subagent?.childRootNodeId ?? input.context.input.rootNodeId;
          const parentNodeId = rootNodeId;
          const ordinal =
            subagent === undefined
              ? yield* resolveItemOrdinal(input.context, input.nativeItemId)
              : ++subagent.nextChildItemOrdinal;
          const toolCall: ActiveClaudeToolCall = {
            nativeItemId: input.nativeItemId,
            toolName: input.toolName,
            classification,
            input: input.toolInput,
            threadId,
            runId,
            rootNodeId,
            parentNodeId,
            ordinal,
            startedAt,
            ...(input.presentation === undefined ? {} : { presentation: input.presentation }),
          };
          input.context.toolCalls.set(input.nativeItemId, toolCall);
          yield* emitToolCallArtifacts(
            buildToolCallArtifacts({
              context: input.context,
              nativeItemId: input.nativeItemId,
              toolName: input.toolName,
              classification,
              toolInput: input.toolInput,
              threadId,
              runId,
              rootNodeId,
              parentNodeId,
              ordinal,
              output: NO_CLAUDE_NATIVE_TOOL_OUTPUT,
              status: "running",
              startedAt,
              updatedAt: startedAt,
              presentation: input.presentation,
            }),
          );
          return toolCall;
        });

        const buildApprovalRequestArtifacts = Effect.fnUntraced(function* (input: {
          readonly context: ActiveClaudeTurnContext;
          readonly nativeItemId: string;
          readonly nativeRequestId: string;
          readonly requestKind: OrchestrationV2RuntimeRequest["kind"];
          readonly prompt?: string;
          readonly questions?: ReadonlyArray<OrchestrationV2UserInputQuestion>;
        }) {
          const createdAt = yield* DateTime.now;
          const requestId = yield* idAllocator.allocate.runtimeRequest({
            driver: CLAUDE_PROVIDER,
            providerTurnId: input.context.providerTurnId,
            nativeRequestId: input.nativeRequestId,
          });
          const nodeId = idAllocator.derive.approvalNode({ requestId });
          const providerSessionId = input.context.input.providerThread.providerSessionId;
          if (providerSessionId === null) {
            return yield* new ProviderAdapter.ProviderAdapterProtocolError({
              driver: CLAUDE_PROVIDER,
              detail: `Provider thread ${input.context.input.providerThread.id} is missing a provider session id.`,
            });
          }
          const ordinal = yield* resolveItemOrdinal(
            input.context,
            `${input.nativeItemId}:approval:${input.nativeRequestId}`,
          );
          const nativeItemRef = {
            driver: CLAUDE_PROVIDER,
            nativeId: input.nativeRequestId,
            strength: "strong" as const,
          };
          const node: OrchestrationV2ExecutionNode = {
            id: nodeId,
            threadId: input.context.input.threadId,
            runId: input.context.input.runId,
            parentNodeId: idAllocator.derive.nodeFromProviderItem({
              driver: CLAUDE_PROVIDER,
              nativeItemId: input.nativeItemId,
            }),
            rootNodeId: input.context.input.rootNodeId,
            kind: input.questions === undefined ? "approval_request" : "user_input_request",
            status: "waiting",
            countsForRun: false,
            providerThreadId: input.context.input.providerThread.id,
            providerTurnId: input.context.providerTurnId,
            nativeItemRef,
            runtimeRequestId: requestId,
            checkpointScopeId: null,
            startedAt: createdAt,
            completedAt: null,
          };
          const request: OrchestrationV2RuntimeRequest = {
            id: requestId,
            nodeId,
            providerTurnId: input.context.providerTurnId,
            nativeRequestRef: {
              driver: CLAUDE_PROVIDER,
              nativeId: input.nativeRequestId,
              strength: "strong",
            },
            kind: input.requestKind,
            status: "pending",
            responseCapability: {
              type: "live",
              providerSessionId,
            },
            createdAt,
            resolvedAt: null,
          };
          const turnItem: OrchestrationV2TurnItem = {
            id: idAllocator.derive.approvalTurnItem({ requestId }),
            threadId: input.context.input.threadId,
            runId: input.context.input.runId,
            nodeId,
            providerThreadId: input.context.input.providerThread.id,
            providerTurnId: input.context.providerTurnId,
            nativeItemRef,
            parentItemId: null,
            ordinal,
            status: "waiting",
            title: null,
            startedAt: createdAt,
            completedAt: null,
            updatedAt: createdAt,
            ...(input.questions === undefined
              ? {
                  type: "approval_request" as const,
                  requestId,
                  requestKind: input.requestKind as ProviderRequestKind,
                  ...(input.prompt === undefined ? {} : { prompt: input.prompt }),
                }
              : {
                  type: "user_input_request" as const,
                  requestId,
                  questions: [...input.questions],
                }),
          };
          return { node, request, turnItem };
        });

        const ensureReasoningBlock = Effect.fnUntraced(function* (
          context: ActiveClaudeTurnContext,
          itemId: string,
        ) {
          if (!context.reasoning.blocks.has(itemId)) {
            context.reasoning.blocks.set(itemId, {
              startedAt: yield* DateTime.now,
              ordinal: yield* resolveItemOrdinal(context, itemId),
              text: "",
            });
          }
        });
        const reasoningDeltas = yield* makeProviderTextDeltaCoalescer({
          flushIntervalMs: 50,
          emit: (update) =>
            Effect.gen(function* () {
              const context = yield* Ref.get(activeTurn);
              if (context === null || context.nativeTurnId !== update.turnId) return;
              const block = context.reasoning.blocks.get(update.itemId);
              if (block === undefined || update.text.length === 0) return;
              block.text = update.text;
              const now = yield* DateTime.now;
              yield* emitProviderEvent({
                type: "turn_item.updated",
                driver: CLAUDE_PROVIDER,
                turnItem: {
                  id: idAllocator.derive.turnItemFromProviderItem({
                    driver: CLAUDE_PROVIDER,
                    nativeItemId: update.itemId,
                  }),
                  threadId: context.input.threadId,
                  runId: context.input.runId,
                  nodeId: context.input.rootNodeId,
                  providerThreadId: context.input.providerThread.id,
                  providerTurnId: context.providerTurnId,
                  nativeItemRef: {
                    driver: CLAUDE_PROVIDER,
                    nativeId: update.itemId,
                    strength: "strong",
                  },
                  parentItemId: null,
                  ordinal: block.ordinal,
                  type: "reasoning",
                  title: "Thinking",
                  text: update.text,
                  streaming: !update.completed,
                  status: update.completed ? "completed" : "running",
                  startedAt: block.startedAt,
                  completedAt: update.completed ? now : null,
                  updatedAt: now,
                },
              });
            }),
        });

        const finalizeActiveTurn = Effect.fnUntraced(function* (input: {
          readonly context: ActiveClaudeTurnContext;
          readonly status: Extract<
            OrchestrationV2ProviderTurn["status"],
            "completed" | "interrupted" | "failed" | "cancelled"
          >;
          readonly completedAt: DateTime.Utc;
          readonly failure?: OrchestrationV2ProviderFailure;
          readonly threadDisposition?: "reusable" | "broken";
          readonly result?: SDKResultMessage;
        }) {
          yield* reasoningDeltas.flushTurn(input.context.nativeTurnId);
          for (const toolCall of input.context.toolCalls.values()) {
            const artifacts = buildToolCallArtifacts({
              context: input.context,
              nativeItemId: toolCall.nativeItemId,
              toolName: toolCall.toolName,
              classification: toolCall.classification,
              toolInput: toolCall.input,
              threadId: toolCall.threadId,
              runId: toolCall.runId,
              rootNodeId: toolCall.rootNodeId,
              parentNodeId: toolCall.parentNodeId,
              ordinal: toolCall.ordinal,
              output: NO_CLAUDE_NATIVE_TOOL_OUTPUT,
              // A stopped turn cuts its open tools short; only a turn that
              // ended on its own leaves them failed.
              status: input.status === "completed" ? "failed" : input.status,
              startedAt: toolCall.startedAt,
              updatedAt: input.completedAt,
              presentation: toolCall.presentation,
            });
            yield* emitToolCallArtifacts(artifacts);
          }
          input.context.toolCalls.clear();

          if (
            input.context.assistant.emittedNativeItemIds.size === 0 &&
            input.context.assistant.fallbackText.length > 0
          ) {
            const ordinal = yield* resolveItemOrdinal(
              input.context,
              input.context.assistant.fallbackNativeItemId,
            );
            const artifacts = buildAssistantArtifacts({
              idAllocator,
              turnInput: input.context.input,
              providerTurnId: input.context.providerTurnId,
              nativeItemId: input.context.assistant.fallbackNativeItemId,
              text: input.context.assistant.fallbackText,
              ordinal,
              startedAt: input.context.startedAt,
              completedAt: input.completedAt,
            });
            yield* Effect.all(
              [
                emitProviderEvent({
                  type: "node.updated",
                  driver: CLAUDE_PROVIDER,
                  node: artifacts.node,
                }),
                emitProviderEvent({
                  type: "message.updated",
                  driver: CLAUDE_PROVIDER,
                  message: artifacts.message,
                }),
                emitProviderEvent({
                  type: "turn_item.updated",
                  driver: CLAUDE_PROVIDER,
                  turnItem: artifacts.turnItem,
                }),
              ],
              { concurrency: 1 },
            );
          }

          const providerRetry = yield* Ref.modify(providerRetries, (current) => {
            const retry = current.get(input.context.providerTurnId);
            if (retry === undefined) {
              return [undefined, current] as const;
            }
            const updated = new Map(current);
            updated.delete(input.context.providerTurnId);
            return [retry, updated] as const;
          });
          if (providerRetry !== undefined && input.status !== "failed") {
            yield* emitProviderEvent({
              type: "turn_item.updated",
              driver: CLAUDE_PROVIDER,
              turnItem: makeProviderRetryTurnItem({
                idAllocator,
                driver: CLAUDE_PROVIDER,
                threadId: input.context.input.threadId,
                runId: input.context.input.runId,
                nodeId: input.context.input.rootNodeId,
                providerThreadId: input.context.input.providerThread.id,
                providerTurnId: input.context.providerTurnId,
                itemOrdinal: providerRetry.itemOrdinal,
                failure: providerRetry.failure,
                retry: providerRetry.retry,
                status: input.status,
                startedAt: providerRetry.startedAt,
                updatedAt: input.completedAt,
              }),
            });
          }

          const threadDisposition = input.threadDisposition ?? "reusable";
          const terminalEvent: ProviderAdapter.ProviderAdapterV2Event =
            input.status === "failed"
              ? {
                  type: "turn.terminal",
                  driver: CLAUDE_PROVIDER,
                  providerThreadId: input.context.input.providerThread.id,
                  providerTurnId: input.context.providerTurnId,
                  runOrdinal: input.context.input.runOrdinal,
                  failureItemOrdinal: yield* resolveItemOrdinal(
                    input.context,
                    `terminal-failure:${input.context.providerTurnId}`,
                  ),
                  status: input.status,
                  failure: input.failure ?? makeProviderFailure({ class: "provider_error" }),
                  ...(providerRetry === undefined
                    ? {}
                    : {
                        retry: providerRetry.retry,
                        retryStartedAt: providerRetry.startedAt,
                      }),
                  threadDisposition,
                }
              : {
                  type: "turn.terminal",
                  driver: CLAUDE_PROVIDER,
                  providerThreadId: input.context.input.providerThread.id,
                  providerTurnId: input.context.providerTurnId,
                  runOrdinal: input.context.input.runOrdinal,
                  status: input.status,
                  failure: null,
                  threadDisposition,
                };
          yield* Effect.all(
            [
              emitProviderEvent({
                type: "provider_turn.updated",
                driver: CLAUDE_PROVIDER,
                providerTurn: {
                  ...providerTurnPayload({
                    context: input.context,
                    status: input.status,
                    completedAt: input.completedAt,
                  }),
                  turnTokenUsage: normalizeClaudeTurnTokenUsage(
                    input.result,
                    input.context.subagentsByTaskId.size > 0 ||
                      input.context.subagentsByToolUseId.size > 0,
                    input.status,
                  ),
                },
              }),
              // Surface this native thread's roster before the root turn
              // terminals so writeFinalRunEvents preserves it. Failed or
              // interrupted turns drop only this thread's roster so sibling
              // native threads keep their Waiting state.
              Effect.gen(function* () {
                const nativeThreadId =
                  input.context.input.providerThread.nativeThreadRef?.nativeId ?? null;
                if (nativeThreadId !== null) {
                  if (input.status !== "completed") {
                    yield* clearPendingBackgroundTasksForNativeThread(nativeThreadId);
                    yield* clearNativeThreadTaskIdSet(
                      wakeEligibleBackgroundTasksByNativeThread,
                      nativeThreadId,
                    );
                    yield* clearNativeThreadTaskIdSet(
                      opaqueBackgroundTaskReplayTombstonesByNativeThread,
                      nativeThreadId,
                    );
                  }
                }
                const roster =
                  nativeThreadId === null
                    ? new Map<string, OrchestrationV2PendingBackgroundTask>()
                    : rosterForNativeThread(
                        yield* Ref.get(pendingBackgroundTasksByNativeThread),
                        nativeThreadId,
                      );
                const clearConversationHead =
                  input.status === "completed" &&
                  input.context.input.providerThread.nativeConversationHeadRef !== null;
                // While a goal is set, Claude ends a turn on its own only after the
                // goal's Stop hook passes. It defers that check while background
                // work runs, and a hook that stops the turn reports another reason.
                // SDK mode does not report an evaluator timeout or an impossible
                // verdict, so those still read as complete.
                const goal =
                  nativeThreadId === null ? undefined : goalsByNativeThread.get(nativeThreadId);
                const goalChecked = goalCheckedTurns.delete(input.context.providerTurnId);
                const terminalReason = input.result?.terminal_reason;
                if (
                  nativeThreadId !== null &&
                  goal?.status === "active" &&
                  goalChecked &&
                  input.status === "completed" &&
                  (terminalReason === undefined || terminalReason === "completed") &&
                  roster.size === 0
                ) {
                  goalsByNativeThread.set(nativeThreadId, {
                    objective: goal.objective,
                    status: "complete",
                    ...(goal.checks === undefined ? {} : { checks: goal.checks }),
                  });
                }
                const providerThread: OrchestrationV2ProviderThread = {
                  ...input.context.input.providerThread,
                  providerSessionId: session.id,
                  ...(clearConversationHead ? { nativeConversationHeadRef: null } : {}),
                  ...(nativeThreadId !== null && goalsByNativeThread.has(nativeThreadId)
                    ? { goal: goalsByNativeThread.get(nativeThreadId) ?? null }
                    : {}),
                  firstRunOrdinal:
                    input.context.input.providerThread.firstRunOrdinal ??
                    input.context.input.runOrdinal,
                  lastRunOrdinal: input.context.input.runOrdinal,
                  pendingBackgroundTasks: claudePendingBackgroundTasksFromRoster(roster),
                  status: input.status === "completed" ? "active" : "idle",
                  updatedAt: input.completedAt,
                };
                yield* rememberProviderThread(providerThread);
                yield* emitProviderEvent({
                  type: "provider_thread.updated" as const,
                  driver: CLAUDE_PROVIDER,
                  providerThread,
                });
              }),
              emitProviderEvent(terminalEvent),
            ],
            { concurrency: 1 },
          );
          yield* Ref.update(activeTurn, (current) =>
            current?.providerTurnId === input.context.providerTurnId ? null : current,
          );
          yield* Ref.update(interruptedTurns, (current) => {
            const next = new Set(current);
            next.delete(input.context.providerTurnId);
            return next;
          });
        });

        const emitAssistantTextArtifacts = Effect.fnUntraced(function* (input: {
          readonly context: ActiveClaudeTurnContext;
          readonly nativeItemId: string;
          readonly text: string;
        }) {
          if (input.context.assistant.emittedNativeItemIds.has(input.nativeItemId)) {
            return;
          }
          input.context.assistant.emittedNativeItemIds.add(input.nativeItemId);
          const now = yield* DateTime.now;
          const ordinal = yield* resolveItemOrdinal(input.context, input.nativeItemId);
          const artifacts = buildAssistantArtifacts({
            idAllocator,
            turnInput: input.context.input,
            providerTurnId: input.context.providerTurnId,
            nativeItemId: input.nativeItemId,
            text: input.text,
            ordinal,
            startedAt: now,
            completedAt: now,
          });
          yield* Effect.all(
            [
              emitProviderEvent({
                type: "node.updated",
                driver: CLAUDE_PROVIDER,
                node: artifacts.node,
              }),
              emitProviderEvent({
                type: "message.updated",
                driver: CLAUDE_PROVIDER,
                message: artifacts.message,
              }),
              emitProviderEvent({
                type: "turn_item.updated",
                driver: CLAUDE_PROVIDER,
                turnItem: artifacts.turnItem,
              }),
            ],
            { concurrency: 1 },
          );
        });

        const finalizeActiveTurnAfterQueryExit = Effect.fnUntraced(function* (
          cause?: Cause.Cause<ClaudeAgentSdkQueryRunnerError>,
        ) {
          const context = yield* Ref.get(activeTurn);
          if (context === null) {
            return;
          }
          const completedAt = yield* DateTime.now;
          const interrupted = (yield* Ref.get(interruptedTurns)).has(context.providerTurnId);
          yield* finalizeActiveTurn({
            context,
            status: interrupted ? "interrupted" : "failed",
            completedAt,
            ...(interrupted
              ? {}
              : {
                  failure: makeProviderFailure({
                    cause: cause === undefined ? undefined : Cause.squash(cause),
                    class: "transport_error",
                  }),
                }),
          });
          yield* Ref.update(interruptedTurns, (current) => {
            const next = new Set(current);
            next.delete(context.providerTurnId);
            return next;
          });
          if (cause !== undefined) {
            yield* Effect.logWarning("orchestration-v2.claude-query-stream-failed", {
              providerSessionId: input.providerSessionId,
              providerThreadId: context.input.providerThread.id,
              providerTurnId: context.providerTurnId,
              cause,
            });
          }
        });

        const bufferWakeMessage = Effect.fnUntraced(function* (wakeInput: {
          readonly nativeThreadId: string;
          readonly message: SDKMessage;
        }) {
          const message = wakeInput.message;
          const isNotification =
            message.type === "system" && message.subtype === "task_notification";
          // Only notifications for tracked tasks count as wake evidence: a
          // wake-eligible local_bash task (eligibility set, not the Waiting
          // roster), or a session-registered subagent that is still running
          // (Agent with run_in_background settling after the root turn). A
          // stray notification for an unknown task is dropped as before
          // instead of triggering a spurious continuation.
          const isPendingTaskNotification =
            isNotification &&
            (yield* isWakeEligibleOpaqueBackgroundTaskOnNativeThread(
              wakeInput.nativeThreadId,
              message.task_id,
            ));
          const bufferedMessages =
            (yield* Ref.get(wakeBuffers)).get(wakeInput.nativeThreadId)?.messages ?? [];
          // A nested subagent's end goes to the subagent that started it, not
          // the root. It is buffered so the next drain completes its card, but
          // it is not a wake.
          const isNestedSubagentNotification =
            isNotification &&
            !isPendingTaskNotification &&
            (yield* isNestedSubagentTask(message.task_id));
          const isPendingSubagentNotification =
            isNotification &&
            !isPendingTaskNotification &&
            !isNestedSubagentNotification &&
            ((yield* Ref.get(sessionSubagentsByTaskId)).get(message.task_id)?.task.status ===
              "running" ||
              bufferedMessages.some(
                (entry) =>
                  entry.type === "system" &&
                  entry.subtype === "task_started" &&
                  entry.task_id === message.task_id,
              ));
          // A subagent launched while the root is idle (inside a native wake
          // turn) must reach the continuation drain with its task_started, or
          // its frames have no registered owner and are held indefinitely.
          const isNewSubagentTaskStarted =
            message.type === "system" &&
            message.subtype === "task_started" &&
            !isClaudeNonSubagentTask(message);
          // A task_started for a session-registered subagent that races past
          // settle is a resume (SendMessage to a completed subagent re-emits
          // task_started with the same task id). Re-open the registry entry
          // so the resumed run pins idle and its eventual notification counts
          // as wake evidence again, and buffer the frame so the continuation
          // drain re-opens the projection row; it does not itself offer a
          // continuation.
          const isKnownSubagentTaskStarted =
            message.type === "system" &&
            message.subtype === "task_started" &&
            (yield* Ref.get(sessionSubagentsByTaskId)).has(message.task_id);
          if (
            isKnownSubagentTaskStarted &&
            message.type === "system" &&
            message.subtype === "task_started"
          ) {
            const now = yield* DateTime.now;
            yield* Ref.update(sessionSubagentsByTaskId, (current) => {
              const registered = current.get(message.task_id);
              if (registered === undefined || registered.task.status === "running") {
                return current;
              }
              const { progress: _staleProgress, ...priorTask } = registered.task;
              return new Map(current).set(message.task_id, {
                ...registered,
                task: {
                  ...priorTask,
                  status: "running",
                  result: null,
                  startedAt: now,
                  completedAt: null,
                  updatedAt: now,
                },
              });
            });
          }
          // Rate-limit frames park with the wake output so the drain can
          // replay them to the turn that was still starting when they
          // arrived; the offer gate below keeps them from requesting a
          // continuation on their own.
          const isWakeTurnStart = isClaudeTurnStartMessage(message);
          const isWakeEvidence =
            isPendingTaskNotification ||
            isPendingSubagentNotification ||
            isNestedSubagentNotification ||
            isKnownSubagentTaskStarted ||
            isNewSubagentTaskStarted ||
            isWakeTurnStart ||
            message.type === "assistant" ||
            message.type === "user" ||
            message.type === "result" ||
            message.type === "rate_limit_event";
          if (!isWakeEvidence) {
            return;
          }
          const notificationSummary =
            isNotification && typeof message.summary === "string" && message.summary.length > 0
              ? message.summary
              : null;
          if (isPendingTaskNotification) {
            yield* recordWakeReport(
              wakeInput.nativeThreadId,
              message.task_id,
              yield* opaqueTaskWakeReport(wakeInput.nativeThreadId, message),
            );
          } else if (isPendingSubagentNotification) {
            const registered = (yield* Ref.get(sessionSubagentsByTaskId)).get(message.task_id);
            const started = bufferedMessages.find(
              (entry) =>
                entry.type === "system" &&
                entry.subtype === "task_started" &&
                entry.task_id === message.task_id,
            );
            yield* recordWakeReport(wakeInput.nativeThreadId, message.task_id, {
              kind: "subagent",
              label:
                registered?.task.title ??
                (started?.type === "system" && started.subtype === "task_started"
                  ? started.description
                  : undefined),
              outcome: claudeTaskOutcome(message.status),
              childThreadId: registered?.childThreadId,
            });
          }
          yield* Ref.update(wakeBuffers, (current) => {
            const existing = current.get(wakeInput.nativeThreadId);
            const updated = new Map(current);
            updated.set(wakeInput.nativeThreadId, {
              messages: [...(existing?.messages ?? []), message],
              detail: notificationSummary ?? existing?.detail ?? null,
            });
            return updated;
          });
          // First idle opaque notification: consume wake eligibility so a
          // duplicate cannot re-buffer, and leave a short-lived replay
          // tombstone for continuation-drain classification.
          if (isPendingTaskNotification) {
            yield* consumeWakeEligibilityForBufferedNotification(
              wakeInput.nativeThreadId,
              message.task_id,
            );
          }
          // A terminal task notification can clear the Waiting roster without
          // Claude dequeuing it into a native model turn. Buffer it for replay,
          // but do not open an opaque-task continuation until the turn's `init`,
          // or native user, assistant, or result output, proves that Claude
          // actually began the wake turn. `init` comes first, so the thread
          // shows working while Claude thinks instead of looking finished.
          // Subagent notifications retain their existing immediate offer
          // because their projected lifecycle owns the continuation. Only
          // root frames prove it: a background subagent keeps streaming its
          // own frames while the root is idle.
          const buffered = (yield* Ref.get(wakeBuffers)).get(wakeInput.nativeThreadId);
          const hasBufferedNotification =
            buffered?.messages.some(
              (entry) => entry.type === "system" && entry.subtype === "task_notification",
            ) ?? false;
          const isNativeOpaqueWakeFrame =
            hasBufferedNotification &&
            (message.type === "assistant" || message.type === "user") &&
            parentToolUseIdFromSdkMessage(message) === null;
          if (
            !isPendingSubagentNotification &&
            !isNativeOpaqueWakeFrame &&
            !isWakeTurnStart &&
            message.type !== "result"
          ) {
            return;
          }
          const route = (yield* Ref.get(lastTurnRouteByNativeThread)).get(wakeInput.nativeThreadId);
          if (route === undefined) {
            yield* Effect.logWarning("orchestration-v2.claude-wake-turn-unroutable", {
              providerSessionId: input.providerSessionId,
              nativeThreadId: wakeInput.nativeThreadId,
            });
            return;
          }
          const shouldOffer = yield* Ref.modify(requestedContinuations, (current) => {
            if (current.has(wakeInput.nativeThreadId)) {
              return [false, current] as const;
            }
            const updated = new Set(current);
            updated.add(wakeInput.nativeThreadId);
            return [true, updated] as const;
          });
          if (!shouldOffer) {
            return;
          }
          const detail =
            (yield* Ref.get(wakeBuffers)).get(wakeInput.nativeThreadId)?.detail ?? null;
          const reports = yield* takeWakeReports(wakeInput.nativeThreadId);
          const notification = backgroundWorkNotification(
            [...(reports?.values() ?? [])].map((entry) => entry.report),
          );
          yield* Effect.logInfo("orchestration-v2.claude-wake-turn-detected", {
            providerSessionId: input.providerSessionId,
            threadId: route.threadId,
            providerThreadId: route.providerThreadId,
          });
          yield* continuationRequests.offer({
            threadId: route.threadId,
            providerThreadId: route.providerThreadId,
            driver: CLAUDE_PROVIDER,
            detail,
            ...(notification === null ? {} : { notification }),
          });
        });

        const applyBackgroundTaskRosterMessage = Effect.fnUntraced(function* (input: {
          readonly nativeThreadId: string;
          readonly message: SDKMessage;
          readonly activeContext: ActiveClaudeTurnContext | null;
        }) {
          const message = input.message;
          let rosterChanged = false;

          if (isClaudeBackgroundTasksChangedMessage(message)) {
            const roster = Reflect.get(message, "tasks");
            if (!Array.isArray(roster)) {
              return false;
            }
            const nextTasks: OrchestrationV2PendingBackgroundTask[] = [];
            const listedTaskIds = new Set(
              roster.flatMap((entry) => {
                const taskId =
                  entry !== null && typeof entry === "object"
                    ? Reflect.get(entry, "task_id")
                    : undefined;
                return typeof taskId === "string" ? [taskId] : [];
              }),
            );
            const monitorTasks = yield* endClaudeMonitorTasks(
              (taskId, task) =>
                task.nativeThreadId === input.nativeThreadId && !listedTaskIds.has(taskId),
            );
            for (const entry of roster) {
              const task = parseClaudeBackgroundTaskEntry(entry, monitorTasks);
              if (task !== null) {
                nextTasks.push(task);
              }
            }
            yield* replacePendingBackgroundTasks(input.nativeThreadId, nextTasks);
            rosterChanged = true;
          } else if (message.type === "system" && message.subtype === "task_started") {
            // Incremental fallback when background_tasks_changed is absent.
            // Subagent tasks project as subagent turn items; only non-subagent
            // background work (e.g. local_bash) lives on the provider-thread roster.
            // A foreground task blocks its tool call (a subagent's own Bash
            // steps included), so it is not background work; one moved to
            // the background later arrives in background_tasks_changed.
            if (!isClaudeNonSubagentTask(message) || message.is_backgrounded === false) {
              return false;
            }
            yield* upsertPendingBackgroundTask(
              input.nativeThreadId,
              claudePendingBackgroundTask({
                taskId: message.task_id,
                taskType: claudeTaskTypeFromSdkMessage(message),
                startedByMonitor: yield* isClaudeMonitorTask({
                  nativeThreadId: input.nativeThreadId,
                  taskId: message.task_id,
                  toolUseId: message.tool_use_id,
                }),
                description:
                  typeof message.description === "string" ? message.description : undefined,
              }),
            );
            rosterChanged = true;
          } else if (message.type === "system" && message.subtype === "task_notification") {
            yield* endClaudeMonitorTasks((taskId) => taskId === message.task_id);
            const removed = yield* clearPendingBackgroundTask(
              input.nativeThreadId,
              message.task_id,
            );
            // Waiting roster clears on the notification edge. Wake eligibility
            // is consumed when the first idle notification is buffered; clear
            // here too for same-turn active notifications that never entered
            // the idle buffer path. Replay tombstones are not cleared here.
            yield* clearTaskIdFromNativeThreadSet(
              wakeEligibleBackgroundTasksByNativeThread,
              input.nativeThreadId,
              message.task_id,
            );
            rosterChanged = removed;
          }

          if (!rosterChanged) {
            return false;
          }

          const baseThread =
            input.activeContext?.input.providerThread ??
            (yield* Ref.get(lastProviderThreadByNativeThread)).get(input.nativeThreadId);
          if (baseThread === undefined) {
            return true;
          }

          // Between turns, never resurrect active status from a late empty
          // roster update. During an active turn, preserve the thread status.
          const status =
            input.activeContext === null
              ? ("idle" as const)
              : baseThread.status === "idle"
                ? ("active" as const)
                : baseThread.status;
          yield* emitProviderThreadRoster({
            nativeThreadId: input.nativeThreadId,
            providerThread: baseThread,
            status,
          });
          return true;
        });

        const handleSdkMessageFrame = Effect.fnUntraced(function* (input: {
          readonly query: ClaudeAgentSdkQuerySession;
          readonly message: SDKMessage;
          // A held subagent frame replayed after its owner registered. Its
          // turn-level assistant bookkeeping already ran when it arrived.
          readonly replayed?: boolean;
        }) {
          const liveQuery = yield* Ref.get(queryContext);
          if (liveQuery?.query !== input.query) {
            return;
          }

          const message = input.message;
          // Before any routing: a Monitor started during an idle wake turn
          // reports its task before the drain replays the tool call.
          yield* trackClaudeMonitorCalls(message);
          // Before routing too: the wake gate reads it while the root is idle.
          if (
            message.type === "system" &&
            message.subtype === "task_started" &&
            !isClaudeNonSubagentTask(message) &&
            (message.spawn_depth ?? 1) > 1
          ) {
            yield* Ref.update(nestedSubagentTaskIds, (current) =>
              current.has(message.task_id) ? current : new Set(current).add(message.task_id),
            );
          }
          if (message.type === "rate_limit_event") {
            const rateLimitInfo = message.rate_limit_info;
            if (!rateLimitInfo) return;
            const names = adapterOptions.scopedLimitNames
              ? yield* Ref.get(adapterOptions.scopedLimitNames)
              : { overageIncluded: undefined };
            const update = claudeRateLimitEventToUpdate(rateLimitInfo, names);
            const now = yield* DateTime.now;
            if (update && adapterOptions.onUsageLimits) {
              yield* adapterOptions.onUsageLimits({
                ...update,
                checkedAt: DateTime.formatIso(now),
              });
            }
            const context = yield* Ref.get(activeTurn);
            if (context === null) {
              // A rejected window can open the CLI's notification wake,
              // before the continuation turn exists to record it on. Park
              // the frame with the wake output so the drain replays it to
              // the turn; dropping it here loses the reset time the
              // provider just reported.
              yield* bufferWakeMessage({
                nativeThreadId: liveQuery.nativeThreadId,
                message,
              });
              return;
            }
            const overageAllowed =
              rateLimitInfo.overageStatus === "allowed" ||
              rateLimitInfo.overageStatus === "allowed_warning" ||
              rateLimitInfo.isUsingOverage === true ||
              rateLimitInfo.overageInUse === true;
            const blocked = rateLimitInfo.status === "rejected" && !overageAllowed;
            const limitType = rateLimitInfo.rateLimitType ?? "unknown";
            if (blocked) {
              context.rejectedRateLimitTypes.add(limitType);
              const resetMs = (rateLimitInfo.resetsAt ?? NaN) * 1000;
              context.rateLimitResetTimes.set(
                limitType,
                Number.isFinite(resetMs) && resetMs > 0 && resetMs < 8.64e15
                  ? DateTime.formatIso(DateTime.makeUnsafe(resetMs))
                  : null,
              );
            } else if (
              rateLimitInfo.status === "allowed" ||
              rateLimitInfo.status === "allowed_warning" ||
              overageAllowed
            ) {
              context.rejectedRateLimitTypes.delete(limitType);
              context.rateLimitResetTimes.delete(limitType);
            }
            // Rejected windows pause the SDK without ending its turn. Overage
            // and warnings keep running; repeats of a window need only one notice.
            if (blocked) {
              const limitKey = `${limitType}:${rateLimitInfo.resetsAt ?? "unknown"}`;
              if (!context.announcedUsageLimits.has(limitKey)) {
                context.announcedUsageLimits.add(limitKey);
                const nativeItemId = `usage-limit:${context.providerTurnId}:${limitKey}`;
                const notice = describeClaudeUsageLimit(
                  rateLimitInfo,
                  DateTime.toEpochMillis(now),
                  names,
                );
                yield* emitProviderEvent({
                  type: "turn_item.updated",
                  driver: CLAUDE_PROVIDER,
                  turnItem: {
                    id: idAllocator.derive.turnItemFromProviderItem({
                      driver: CLAUDE_PROVIDER,
                      nativeItemId,
                    }),
                    threadId: context.input.threadId,
                    runId: context.input.runId,
                    nodeId: context.input.rootNodeId,
                    providerThreadId: context.input.providerThread.id,
                    providerTurnId: context.providerTurnId,
                    nativeItemRef: {
                      driver: CLAUDE_PROVIDER,
                      nativeId: nativeItemId,
                      strength: "weak",
                    },
                    parentItemId: null,
                    ordinal: yield* resolveItemOrdinal(context, nativeItemId),
                    type: "system_notice",
                    status: "completed",
                    title: notice,
                    message: notice,
                    startedAt: now,
                    completedAt: now,
                    updatedAt: now,
                  },
                });
              }
            }
            return;
          }
          const context = yield* Ref.get(activeTurn);
          if (context === null) {
            // task_notification must buffer wake evidence while still tracked
            // on the roster; clearing first would drop the wake pin.
            if (message.type === "system" && message.subtype === "task_notification") {
              yield* bufferWakeMessage({ nativeThreadId: liveQuery.nativeThreadId, message });
              yield* applyBackgroundTaskRosterMessage({
                nativeThreadId: liveQuery.nativeThreadId,
                message,
                activeContext: null,
              });
            } else {
              yield* applyBackgroundTaskRosterMessage({
                nativeThreadId: liveQuery.nativeThreadId,
                message,
                activeContext: null,
              });
              yield* bufferWakeMessage({ nativeThreadId: liveQuery.nativeThreadId, message });
            }
            return;
          }
          yield* trackClaudeGoal({ nativeThreadId: liveQuery.nativeThreadId, context, message });

          // Subagent narration belongs to its child thread, never the parent log.
          if (message.type === "stream_event" && !message.parent_tool_use_id) {
            const event = message.event;
            const reasoning = context.reasoning;
            if (event.type === "message_start") {
              reasoning.messageId = event.message.id;
              reasoning.streamBlocks.clear();
            } else if (
              event.type === "content_block_start" &&
              event.content_block.type === "thinking" &&
              reasoning.messageId !== null
            ) {
              const index = reasoning.nextBlockIndex.get(reasoning.messageId) ?? 0;
              reasoning.nextBlockIndex.set(reasoning.messageId, index + 1);
              const itemId = `${reasoning.messageId}:thinking:${index}`;
              reasoning.streamBlocks.set(event.index, itemId);
              yield* ensureReasoningBlock(context, itemId);
              yield* reasoningDeltas.append({
                turnId: context.nativeTurnId,
                itemId,
                delta: event.content_block.thinking,
              });
            } else if (
              event.type === "content_block_delta" &&
              event.delta.type === "thinking_delta"
            ) {
              const itemId = reasoning.streamBlocks.get(event.index);
              if (itemId !== undefined) {
                yield* reasoningDeltas.append({
                  turnId: context.nativeTurnId,
                  itemId,
                  delta: event.delta.thinking,
                });
              }
            } else if (event.type === "content_block_stop") {
              const itemId = reasoning.streamBlocks.get(event.index);
              if (itemId !== undefined) {
                yield* reasoningDeltas.complete({
                  turnId: context.nativeTurnId,
                  itemId,
                  emitEmpty: false,
                });
                reasoning.streamBlocks.delete(event.index);
              }
            }
            return;
          }
          if (
            message.type === "assistant" &&
            !message.parent_tool_use_id &&
            !context.reasoning.snapshots.has(message.uuid)
          ) {
            context.reasoning.snapshots.add(message.uuid);
            // The SDK emits one assistant snapshot per completed content block.
            // Count thinking blocks separately so snapshots share the streamed ID.
            for (const block of message.message.content) {
              if (block.type !== "thinking") continue;
              const index = context.reasoning.snapshotBlockIndex.get(message.message.id) ?? 0;
              context.reasoning.snapshotBlockIndex.set(message.message.id, index + 1);
              const itemId = `${message.message.id}:thinking:${index}`;
              yield* ensureReasoningBlock(context, itemId);
              const finalText = block.thinking || context.reasoning.blocks.get(itemId)?.text;
              yield* reasoningDeltas.complete({
                turnId: context.nativeTurnId,
                itemId,
                ...(finalText ? { finalText } : {}),
                emitEmpty: false,
              });
            }
          }

          if (message.type === "assistant" && input.replayed !== true) {
            context.nativeMessageCursor = message.uuid;
            if (message.parent_tool_use_id === null) {
              context.latestAssistantRateLimited = message.error === "rate_limit";
              if (message.error === "authentication_failed") {
                context.authenticationFailureMessage = claudeSignedOutMessage({
                  configDir: adapterOptions.environment.CLAUDE_CONFIG_DIR,
                  cwd: path.resolve(context.input.runtimePolicy.cwd ?? "."),
                });
              }
            }
          }

          if (message.type === "system" && message.subtype === "compact_boundary") {
            const now = yield* DateTime.now;
            const nativeItemId = message.uuid;
            const postTokens = message.compact_metadata.post_tokens;
            const afterTokenCount =
              typeof postTokens === "number" && Number.isFinite(postTokens) && postTokens > 0
                ? Math.round(postTokens)
                : undefined;
            if (afterTokenCount !== undefined) {
              yield* emitProviderEvent({
                type: "provider_turn.updated",
                driver: CLAUDE_PROVIDER,
                threadId: context.input.threadId,
                providerTurn: {
                  id: context.providerTurnId,
                  providerThreadId: context.input.providerThread.id,
                  nodeId: context.input.rootNodeId,
                  runAttemptId: context.input.attemptId,
                  nativeTurnRef: {
                    driver: CLAUDE_PROVIDER,
                    nativeId: context.nativeTurnId,
                    strength: "strong",
                  },
                  ordinal: context.providerTurnOrdinal,
                  status: "running",
                  startedAt: context.startedAt,
                  completedAt: null,
                  tokenUsage: {
                    usedTokens: afterTokenCount,
                    maxTokens: claudeContextWindow(context.input.modelSelection),
                    updatedAt: DateTime.formatIso(now),
                  },
                },
              });
            }
            yield* emitProviderEvent({
              type: "turn_item.updated",
              driver: CLAUDE_PROVIDER,
              turnItem: {
                id: idAllocator.derive.turnItemFromProviderItem({
                  driver: CLAUDE_PROVIDER,
                  nativeItemId,
                }),
                threadId: context.input.threadId,
                runId: context.input.runId,
                nodeId: context.input.rootNodeId,
                providerThreadId: context.input.providerThread.id,
                providerTurnId: context.providerTurnId,
                nativeItemRef: {
                  driver: CLAUDE_PROVIDER,
                  nativeId: nativeItemId,
                  strength: "strong",
                },
                parentItemId: null,
                ordinal: yield* resolveItemOrdinal(context, nativeItemId),
                type: "compaction",
                driver: CLAUDE_PROVIDER,
                status: "completed",
                title: "Context compacted",
                startedAt: now,
                completedAt: now,
                updatedAt: now,
                ...(message.compact_metadata.pre_tokens === undefined
                  ? {}
                  : { beforeTokenCount: message.compact_metadata.pre_tokens }),
                ...(afterTokenCount === undefined ? {} : { afterTokenCount }),
              },
            });
            return;
          }

          if (message.type === "system" && message.subtype === "model_refusal_fallback") {
            const now = yield* DateTime.now;
            const nativeItemId = message.uuid;
            yield* emitProviderEvent({
              type: "turn_item.updated",
              driver: CLAUDE_PROVIDER,
              turnItem: {
                id: idAllocator.derive.turnItemFromProviderItem({
                  driver: CLAUDE_PROVIDER,
                  nativeItemId,
                }),
                threadId: context.input.threadId,
                runId: context.input.runId,
                nodeId: context.input.rootNodeId,
                providerThreadId: context.input.providerThread.id,
                providerTurnId: context.providerTurnId,
                nativeItemRef: {
                  driver: CLAUDE_PROVIDER,
                  nativeId: nativeItemId,
                  strength: "strong",
                },
                parentItemId: null,
                ordinal: yield* resolveItemOrdinal(context, nativeItemId),
                type: "system_notice",
                status: "completed",
                title: message.content,
                message: message.content,
                startedAt: now,
                completedAt: now,
                updatedAt: now,
              },
            });
            return;
          }

          if (message.type === "system" && message.subtype === "api_retry") {
            const updatedAt = yield* DateTime.now;
            const previous = (yield* Ref.get(providerRetries)).get(context.providerTurnId);
            const retry: OrchestrationV2ProviderRetry = {
              attempt: Math.max(1, Math.trunc(message.attempt)),
              maxAttempts: Math.max(1, Math.trunc(message.max_retries)),
              retryDelayMs: Math.max(0, Math.trunc(message.retry_delay_ms)),
            };
            const failure = providerFailureFromApiRetry(message);
            const itemOrdinal =
              previous?.itemOrdinal ??
              (yield* resolveItemOrdinal(context, `terminal-failure:${context.providerTurnId}`));
            const state: ActiveClaudeProviderRetry = {
              retry,
              failure,
              startedAt: previous?.startedAt ?? updatedAt,
              itemOrdinal,
            };
            yield* Ref.update(providerRetries, (current) => {
              const updated = new Map(current);
              updated.set(context.providerTurnId, state);
              return updated;
            });
            yield* emitProviderEvent({
              type: "turn_item.updated",
              driver: CLAUDE_PROVIDER,
              turnItem: makeProviderRetryTurnItem({
                idAllocator,
                driver: CLAUDE_PROVIDER,
                threadId: context.input.threadId,
                runId: context.input.runId,
                nodeId: context.input.rootNodeId,
                providerThreadId: context.input.providerThread.id,
                providerTurnId: context.providerTurnId,
                itemOrdinal,
                failure,
                retry,
                status: "running",
                startedAt: state.startedAt,
                updatedAt,
              }),
            });
            return;
          }

          if (message.type === "assistant" && input.replayed !== true) {
            const now = yield* DateTime.now;
            yield* completeProviderRetry(context, now);
            if (message.parent_tool_use_id === null && message.message.usage !== undefined) {
              yield* emitProviderEvent({
                type: "provider_turn.updated",
                driver: CLAUDE_PROVIDER,
                threadId: context.input.threadId,
                providerTurn: {
                  id: context.providerTurnId,
                  providerThreadId: context.input.providerThread.id,
                  nodeId: context.input.rootNodeId,
                  runAttemptId: context.input.attemptId,
                  nativeTurnRef: {
                    driver: CLAUDE_PROVIDER,
                    nativeId: context.nativeTurnId,
                    strength: "strong",
                  },
                  ordinal: context.providerTurnOrdinal,
                  status: "running",
                  startedAt: context.startedAt,
                  completedAt: null,
                  tokenUsage: claudeProviderTurnTokenUsage(
                    message.message.usage,
                    context.input.modelSelection,
                    DateTime.formatIso(now),
                  ),
                },
              });
            }
            const parentToolUseId = message.parent_tool_use_id;
            const snapshotModel =
              typeof message.message.model === "string" ? message.message.model.trim() : "";
            const model = snapshotModel.length === 0 ? undefined : snapshotModel;
            if (parentToolUseId !== null && model !== undefined) {
              const subagent = yield* resolveSubagentByToolUseId(context, parentToolUseId);
              if (subagent === undefined) {
                rememberPendingClaudeSubagentLaunch(
                  context.pendingSubagentLaunchesByToolUseId,
                  parentToolUseId,
                  { model },
                );
              } else if (subagent.task.status === "running" && subagent.task.model !== model) {
                yield* updateClaudeSubagentNode({
                  context,
                  taskId: subagent.task.nativeTaskRef?.nativeId ?? String(subagent.task.id),
                  toolUseId: parentToolUseId,
                  model,
                  status: subagent.task.status,
                });
              }
            }
          }

          const frameParentToolUseId = parentToolUseIdFromSdkMessage(message);
          if (
            frameParentToolUseId !== null &&
            (yield* resolveSubagentByToolUseId(context, frameParentToolUseId)) === undefined
          ) {
            // Owner not registered yet: hold the frame rather than letting its
            // text and tools fall back to the parent thread.
            const droppedToolUseId = yield* Ref.modify(
              pendingSubagentFramesByToolUseId,
              (current) => {
                const frames = current.get(frameParentToolUseId) ?? [];
                if (frames.length >= PENDING_CLAUDE_SUBAGENT_FRAME_CAP) {
                  return [frameParentToolUseId, current] as const;
                }
                const next = new Map(current).set(frameParentToolUseId, [...frames, message]);
                const oldest = next.keys().next();
                if (next.size > PENDING_CLAUDE_SUBAGENT_CAP && !oldest.done) {
                  next.delete(oldest.value);
                  return [oldest.value, next] as const;
                }
                return [null, next] as const;
              },
            );
            if (droppedToolUseId !== null) {
              yield* Effect.logWarning("orchestration-v2.claude-subagent-frames-dropped", {
                providerTurnId: context.providerTurnId,
                parentToolUseId: droppedToolUseId,
              });
            }
            return;
          }

          if (isClaudeBackgroundTasksChangedMessage(message)) {
            yield* applyBackgroundTaskRosterMessage({
              nativeThreadId: liveQuery.nativeThreadId,
              message,
              activeContext: context,
            });
            return;
          }

          if (message.type === "system" && message.subtype === "task_started") {
            if (isClaudeNonSubagentTask(message)) {
              context.ignoredTaskIds.add(message.task_id);
              yield* applyBackgroundTaskRosterMessage({
                nativeThreadId: liveQuery.nativeThreadId,
                message,
                activeContext: context,
              });
            } else {
              const launch =
                message.tool_use_id === undefined
                  ? undefined
                  : context.pendingSubagentLaunchesByToolUseId.get(message.tool_use_id);
              if (message.tool_use_id !== undefined) {
                context.pendingSubagentLaunchesByToolUseId.delete(message.tool_use_id);
              }
              const owner =
                launch?.ownerToolUseId === undefined
                  ? undefined
                  : yield* resolveSubagentByToolUseId(context, launch.ownerToolUseId);
              // With no model of its own, a nested subagent runs on its
              // owner's (the SDK's default for a subagent's Agent call).
              const model = launch?.model ?? owner?.task.model ?? undefined;
              // A nested subagent's end goes to its owner, so it never wakes the root.
              if (
                message.is_backgrounded === true &&
                !(yield* isNestedSubagentTask(message.task_id))
              ) {
                yield* Ref.update(backgroundedSubagentTaskIds, (current) =>
                  new Set(current).add(message.task_id),
                );
              }
              yield* recoverResumedClaudeSubagent({
                context,
                nativeThreadId: liveQuery.nativeThreadId,
                taskId: message.task_id,
                toolUseId: message.tool_use_id,
                title: message.description,
              });
              yield* updateClaudeSubagentNode({
                context,
                taskId: message.task_id,
                ...(message.tool_use_id === undefined ? {} : { toolUseId: message.tool_use_id }),
                ...(message.prompt === undefined ? {} : { prompt: message.prompt }),
                ...(model === undefined ? {} : { model }),
                ...(owner === undefined ? {} : { owner }),
                title: message.description,
                status: "running",
                reopen: true,
              });
            }
          }

          if (message.type === "system" && message.subtype === "task_progress") {
            const progress = message.description.trim();
            const isBackgroundTask = yield* hasPendingBackgroundTaskOnNativeThread(
              liveQuery.nativeThreadId,
              message.task_id,
            );
            if (
              progress.length > 0 &&
              !context.ignoredTaskIds.has(message.task_id) &&
              !isBackgroundTask
            ) {
              yield* updateClaudeSubagentNode({
                context,
                taskId: message.task_id,
                ...(message.tool_use_id === undefined ? {} : { toolUseId: message.tool_use_id }),
                progress,
                status: "running",
              });
            }
          }

          if (message.type === "system" && message.subtype === "task_notification") {
            // A wake-replay turn has empty ignoredTaskIds, so opaque-task
            // tracking (live roster, wake eligibility, or the short-lived
            // post-buffer replay tombstone) classifies local_bash before any
            // subagent handling.
            const wasBackgroundTask = yield* isKnownOpaqueBackgroundTaskOnNativeThread(
              liveQuery.nativeThreadId,
              message.task_id,
            );
            // Backgrounded work that ends during a user turn wakes the root after
            // it. Drained wake frames replay here too; they were recorded idle.
            if (!isClaudeProviderContinuationTurn(context.input)) {
              if (wasBackgroundTask) {
                yield* recordWakeReport(
                  liveQuery.nativeThreadId,
                  message.task_id,
                  yield* opaqueTaskWakeReport(liveQuery.nativeThreadId, message),
                );
              } else if (
                !wasBackgroundTask &&
                (yield* Ref.get(backgroundedSubagentTaskIds)).has(message.task_id)
              ) {
                const registered = (yield* Ref.get(sessionSubagentsByTaskId)).get(message.task_id);
                yield* recordWakeReport(liveQuery.nativeThreadId, message.task_id, {
                  kind: "subagent",
                  label: registered?.task.title ?? undefined,
                  outcome: claudeTaskOutcome(message.status),
                  childThreadId: registered?.childThreadId,
                });
              }
            }
            // A resume starts the subagent again and says again whether it is backgrounded.
            yield* Ref.update(backgroundedSubagentTaskIds, (current) => {
              if (!current.has(message.task_id)) return current;
              const updated = new Set(current);
              updated.delete(message.task_id);
              return updated;
            });
            yield* applyBackgroundTaskRosterMessage({
              nativeThreadId: liveQuery.nativeThreadId,
              message,
              activeContext: context,
            });
            if (!wasBackgroundTask && !context.ignoredTaskIds.has(message.task_id)) {
              yield* updateClaudeSubagentNode({
                context,
                taskId: message.task_id,
                ...(message.tool_use_id === undefined ? {} : { toolUseId: message.tool_use_id }),
                result: message.summary,
                status:
                  message.status === "completed"
                    ? "completed"
                    : message.status === "stopped"
                      ? "cancelled"
                      : "failed",
              });
            }
            // Replay tombstone only needs to outlive buffering until this
            // drained/live classification runs; drop it so it cannot leak.
            if (wasBackgroundTask) {
              yield* clearOpaqueBackgroundTaskReplayTombstone(
                liveQuery.nativeThreadId,
                message.task_id,
              );
            }
          }

          const toolPresentations = claudeToolPresentationsFromAssistantMessage(message);
          for (const toolUse of claudeToolUseBlocksFromAssistantMessage(message)) {
            const nativeToolInput = claudeNativeToolInputFromUnknown(toolUse.input);
            if (toolUse.name === "Agent") {
              rememberClaudeSubagentLaunch(
                context,
                toolUse.id,
                nativeToolInput,
                parentToolUseIdFromSdkMessage(message),
              );
              continue;
            }
            if (toolUse.name === "TodoWrite" && parentToolUseIdFromSdkMessage(message) === null) {
              yield* emitClaudePlanProjection({
                context,
                nativeItemId: toolUse.id,
                kind: "todo_list",
                steps: claudeTodoSteps(nativeToolInput),
              }).pipe(Effect.orDie);
            }
            yield* ensureToolCallStarted({
              context,
              nativeItemId: toolUse.id,
              toolName: toolUse.name,
              toolInput: nativeToolInput,
              parentToolUseId: parentToolUseIdFromSdkMessage(message),
              presentation:
                toolPresentations.get(toolUse.id) ??
                mcpToolPresentation({
                  toolName: toolUse.name.replace(/^mcp__claude_ai_/u, "mcp__"),
                }),
            });
            const heldPlan = heldProposedPlansByToolUseId.get(toolUse.id);
            if (heldPlan !== undefined) {
              heldProposedPlansByToolUseId.delete(toolUse.id);
              yield* emitClaudePlanProjection({
                context,
                nativeItemId: toolUse.id,
                kind: "proposed_plan",
                markdown: heldPlan,
              }).pipe(Effect.orDie);
            }
          }

          for (const { toolResult, output } of claudeToolResultEntriesFromMessage(message)) {
            const subagent = context.subagentsByToolUseId.get(toolResult.tool_use_id);
            // A resume task_started reuses the resuming tool call's
            // tool_use_id (e.g. SendMessage), whose tool_result only
            // acknowledges delivery. Only the Agent launch's tool_result may
            // terminalize the subagent, and Agent tool_uses never enter
            // toolCalls (they project as subagent rows instead).
            if (subagent !== undefined && !context.toolCalls.has(toolResult.tool_use_id)) {
              // A background Agent launch resolves its tool_use immediately
              // with an async-launch ACK while the task keeps running; only
              // the eventual task_notification terminalizes the subagent.
              if (isClaudeSubagentAsyncLaunchAck(output)) {
                continue;
              }
              const result = claudeSubagentResultText(output);
              yield* updateClaudeSubagentNode({
                context,
                taskId: subagent.task.nativeTaskRef?.nativeId ?? String(subagent.task.id),
                toolUseId: toolResult.tool_use_id,
                ...(result.length === 0 ? {} : { result }),
                status: isClaudeToolResultError(toolResult) ? "failed" : "completed",
              });
              continue;
            }
            const parentToolUseId = parentToolUseIdFromSdkMessage(message);
            const toolCall =
              context.toolCalls.get(toolResult.tool_use_id) ??
              (yield* ensureToolCallStarted({
                context,
                nativeItemId: toolResult.tool_use_id,
                toolName: toolNameFromClaudeToolResult(toolResult),
                toolInput: EMPTY_CLAUDE_NATIVE_TOOL_INPUT,
                parentToolUseId,
              }));
            const completedAt = yield* DateTime.now;
            const toolNonExecutionKind = claudeToolNonExecutionKind(
              message,
              toolResult.tool_use_id,
            );
            const artifacts = buildToolCallArtifacts({
              context,
              nativeItemId: toolCall.nativeItemId,
              toolName: toolCall.toolName,
              classification: toolCall.classification,
              toolInput: toolCall.input,
              threadId: toolCall.threadId,
              runId: toolCall.runId,
              rootNodeId: toolCall.rootNodeId,
              parentNodeId: toolCall.parentNodeId,
              ordinal: toolCall.ordinal,
              output,
              status:
                toolNonExecutionKind === "cancelled"
                  ? "cancelled"
                  : isClaudeToolResultError(toolResult)
                    ? "failed"
                    : "completed",
              ...(toolNonExecutionKind === undefined ? {} : { toolNonExecutionKind }),
              startedAt: toolCall.startedAt,
              updatedAt: completedAt,
              presentation: toolCall.presentation,
            });
            yield* emitToolCallArtifacts(artifacts);
            context.toolCalls.delete(toolCall.nativeItemId);
          }

          const assistantParentToolUseId = parentToolUseIdFromSdkMessage(message);
          if (message.type === "assistant" && assistantParentToolUseId !== null) {
            // Claude never streams subagent output, so each thinking block
            // arrives whole in its own snapshot and lands in the child thread.
            const thinking = message.message.content.flatMap((block) =>
              block.type === "thinking" && block.thinking.trim().length > 0 ? [block.thinking] : [],
            );
            const subagent =
              thinking.length === 0
                ? undefined
                : yield* resolveSubagentByToolUseId(context, assistantParentToolUseId);
            if (subagent !== undefined) {
              const now = yield* DateTime.now;
              for (const [index, text] of thinking.entries()) {
                const nativeItemId = `${message.uuid}:thinking:${index}`;
                yield* emitProviderEvent({
                  type: "turn_item.updated",
                  driver: CLAUDE_PROVIDER,
                  turnItem: {
                    id: idAllocator.derive.turnItemFromProviderItem({
                      driver: CLAUDE_PROVIDER,
                      nativeItemId,
                    }),
                    threadId: subagent.childThreadId,
                    runId: null,
                    nodeId: subagent.childRootNodeId,
                    providerThreadId: null,
                    providerTurnId: null,
                    nativeItemRef: {
                      driver: CLAUDE_PROVIDER,
                      nativeId: nativeItemId,
                      strength: "strong",
                    },
                    parentItemId: null,
                    ordinal: ++subagent.nextChildItemOrdinal,
                    type: "reasoning",
                    title: "Thinking",
                    text,
                    streaming: false,
                    status: "completed",
                    startedAt: now,
                    completedAt: now,
                    updatedAt: now,
                  },
                });
              }
            }
          }
          const assistantText = assistantTextFromSdkMessage(message);
          if (
            assistantText !== null &&
            assistantText.text.length > 0 &&
            assistantParentToolUseId !== null
          ) {
            // Subagent text belongs to the subagent's child thread, never the
            // parent transcript. Unowned frames were already held above.
            const subagent = yield* resolveSubagentByToolUseId(context, assistantParentToolUseId);
            if (subagent === undefined) {
              return;
            }
            const now = yield* DateTime.now;
            // One native message arrives as one snapshot per content block.
            const nativeMessageId =
              message.type === "assistant" && typeof message.message.id === "string"
                ? message.message.id
                : null;
            subagent.lastAssistantText =
              nativeMessageId !== null && nativeMessageId === subagent.lastAssistantMessageId
                ? `${subagent.lastAssistantText ?? ""}\n${assistantText.text}`
                : assistantText.text;
            subagent.lastAssistantMessageId = nativeMessageId;
            const artifacts = makeSubagentConversationArtifacts({
              messageId: idAllocator.derive.messageFromProviderItem({
                driver: CLAUDE_PROVIDER,
                nativeItemId: assistantText.nativeItemId,
              }),
              turnItemId: idAllocator.derive.turnItemFromProviderItem({
                driver: CLAUDE_PROVIDER,
                nativeItemId: assistantText.nativeItemId,
              }),
              threadId: subagent.childThreadId,
              rootNodeId: subagent.childRootNodeId,
              providerThreadId: null,
              providerTurnId: null,
              nativeItemRef: {
                driver: CLAUDE_PROVIDER,
                nativeId: assistantText.nativeItemId,
                strength: "strong",
              },
              role: "assistant",
              text: assistantText.text,
              ordinal: ++subagent.nextChildItemOrdinal,
              now,
            });
            yield* emitProviderEvent({
              type: "message.updated",
              driver: CLAUDE_PROVIDER,
              message: artifacts.message,
            });
            yield* emitProviderEvent({
              type: "turn_item.updated",
              driver: CLAUDE_PROVIDER,
              turnItem: artifacts.turnItem,
            });
            return;
          }
          if (assistantText !== null && assistantText.text.length > 0) {
            yield* emitAssistantTextArtifacts({
              context,
              nativeItemId: assistantText.nativeItemId,
              text: assistantText.text,
            });
            return;
          }

          // A zero-turn task-notification-origin result is almost always
          // lifecycle debris, so it must not finalize a normal turn or supply
          // fallback assistant text. Provider continuation turns still consume
          // it when draining buffered wake messages.
          //
          // "Almost always" is the honest word: num_turns is a workload count,
          // not a causal link to the prompt this turn is waiting on. A genuine
          // wake that fails before any model turn also reports zero, and is
          // dropped here, so that turn hangs until query exit. Narrowing the
          // drop to zero-turn results only shrinks a pre-existing drop; closing
          // the residue needs a correlation id on the result, which the wire
          // does not carry today.
          if (
            isClaudeTaskNotificationOriginResult(message) &&
            !isClaudeProviderContinuationTurn(context.input) &&
            message.num_turns === 0
          ) {
            // Routine lifecycle noise, so debug rather than warning: interrupt
            // recovery produces this every time.
            yield* Effect.logDebug("orchestration-v2.claude-task-notification-result-dropped", {
              providerTurnId: context.providerTurnId,
              num_turns: message.num_turns,
              stop_reason: message.stop_reason,
              terminal_reason: message.terminal_reason,
              uuid: message.uuid,
              session_id: message.session_id,
              createdBy: context.input.message.createdBy,
              creationSource: context.input.message.creationSource,
            });
            return;
          }

          // The converse of the drop above, and the case actually worth
          // watching: a positive-turn task-notification result settling a turn
          // T3 did not mark as a continuation. That is the hang fix working,
          // but it is also the shape a stale result would take if one ever
          // carried model turns, which nothing on the wire lets us rule out.
          if (
            isClaudeTaskNotificationOriginResult(message) &&
            !isClaudeProviderContinuationTurn(context.input)
          ) {
            // This user turn ran the wake itself, so no offer will name its work.
            yield* clearWakeReports(liveQuery.nativeThreadId);
            yield* Effect.logInfo("orchestration-v2.claude-task-notification-result-accepted", {
              providerTurnId: context.providerTurnId,
              num_turns: message.num_turns,
              stop_reason: message.stop_reason,
              terminal_reason: message.terminal_reason,
              uuid: message.uuid,
              session_id: message.session_id,
              createdBy: context.input.message.createdBy,
              creationSource: context.input.message.creationSource,
            });
          }

          // Failed result text belongs on the terminal-failure item, including
          // structured failures whose SDK result still has is_error=false.
          const resultText =
            message.type === "result" &&
            ((message.subtype === "success" && message.is_error) ||
              terminalStatusFromResult(message) === "failed")
              ? null
              : resultTextFromSdkMessage(message);
          if (
            context.assistant.emittedNativeItemIds.size === 0 &&
            context.assistant.fallbackText.length === 0 &&
            resultText !== null &&
            resultText.text.length > 0
          ) {
            context.assistant.fallbackText = resultText.text;
            context.assistant.fallbackNativeItemId = resultText.nativeItemId;
          }

          if (message.type === "result") {
            const completedAt = yield* DateTime.now;
            const interrupted = (yield* Ref.get(interruptedTurns)).has(context.providerTurnId);
            const wasSteered = (yield* Ref.get(steeredTurns)).has(context.providerTurnId);
            if (!interrupted && wasSteered && isClaudeActiveSteeringAbortResult(message)) {
              return;
            }
            yield* Ref.update(steeredTurns, (current) => {
              const next = new Set(current);
              next.delete(context.providerTurnId);
              return next;
            });
            const usageLimited =
              context.authenticationFailureMessage === undefined &&
              (context.rejectedRateLimitTypes.size > 0 || context.latestAssistantRateLimited) &&
              (message.subtype !== "success" ||
                message.api_error_status == null ||
                message.api_error_status === 429) &&
              (message.terminal_reason == null ||
                message.terminal_reason === "api_error" ||
                message.terminal_reason === "blocking_limit");
            const failureHint =
              context.authenticationFailureMessage ??
              (usageLimited
                ? "Claude usage limit reached. Send the message again once the limit resets."
                : undefined);
            const resetTimes = Array.from(context.rateLimitResetTimes.values());
            const resetAt =
              resetTimes.length > 0 && resetTimes.every((time) => time !== null)
                ? resetTimes.reduce((latest, time) => (time! > latest ? time! : latest), "")
                : null;
            const resultFailure = interrupted
              ? null
              : providerFailureFromResult(message, failureHint, usageLimited);
            const terminalFailure =
              resultFailure?.class === "usage_limit"
                ? { ...resultFailure, resetAt }
                : resultFailure;
            yield* finalizeActiveTurn({
              context,
              status: interrupted ? "interrupted" : terminalStatusFromResult(message, failureHint),
              completedAt,
              result: message,
              ...(terminalFailure === null ? {} : { failure: terminalFailure }),
            });
          }
        });

        // Held subagent frames whose owner this lifecycle frame resolves. The
        // frame's (task_id, tool_use_id) pair is authoritative, so it also
        // fills the tool-use index when task_started lacked a tool_use_id.
        const takeReleasableSubagentFrames = Effect.fnUntraced(function* (message: SDKMessage) {
          if (
            message.type !== "system" ||
            (message.subtype !== "task_started" &&
              message.subtype !== "task_progress" &&
              message.subtype !== "task_notification") ||
            message.tool_use_id === undefined ||
            !(yield* Ref.get(sessionSubagentsByTaskId)).has(message.task_id)
          ) {
            return [];
          }
          const toolUseId = message.tool_use_id;
          const taskId = message.task_id;
          yield* Ref.update(sessionSubagentTaskIdsByToolUseId, (current) =>
            current.get(toolUseId) === taskId ? current : new Map(current).set(toolUseId, taskId),
          );
          return yield* Ref.modify(pendingSubagentFramesByToolUseId, (current) => {
            const frames = current.get(toolUseId);
            if (frames === undefined) {
              return [[] as ReadonlyArray<SDKMessage>, current] as const;
            }
            const next = new Map(current);
            next.delete(toolUseId);
            return [frames, next] as const;
          });
        });

        const handleRoutedSdkMessage = Effect.fnUntraced(function* (input: {
          readonly query: ClaudeAgentSdkQuerySession;
          readonly message: SDKMessage;
        }) {
          // Progress or a notification can be the first frame naming a known
          // subagent's tool_use_id; its held frames must precede the result.
          if (input.message.type !== "system" || input.message.subtype !== "task_started") {
            for (const message of yield* takeReleasableSubagentFrames(input.message)) {
              yield* handleSdkMessageFrame({ query: input.query, message, replayed: true });
            }
          }
          yield* handleSdkMessageFrame(input);
          // task_started registers its subagent while being handled.
          for (const message of yield* takeReleasableSubagentFrames(input.message)) {
            yield* handleSdkMessageFrame({ query: input.query, message, replayed: true });
          }
        });

        // Root tool_use ids among a turn's held frames.
        const heldToolUseIds = (context: ActiveClaudeTurnContext): ReadonlySet<string> =>
          new Set(
            context.heldRootFrames.flatMap((frame) =>
              parentToolUseIdFromSdkMessage(frame) === null
                ? claudeToolUseBlocksFromAssistantMessage(frame).map((toolUse) => toolUse.id)
                : [],
            ),
          );

        // Gives held root output to the pending prompt turn.
        const releaseHeldRootFrames = Effect.fnUntraced(function* (
          context: ActiveClaudeTurnContext,
        ) {
          context.promptEcho = "confirmed";
          const liveQuery = yield* Ref.get(queryContext);
          const held = context.heldRootFrames.splice(0);
          if (liveQuery === null) {
            return;
          }
          for (const message of held) {
            yield* handleRoutedSdkMessage({ query: liveQuery.query, message });
          }
        });

        // A prompt offered while Claude has a turn of its own queued (a
        // background task or subagent finished, a peer message arrived, a
        // resume reports work the previous process left) is answered only
        // after that turn runs, and the two look alike until each turn's
        // result. Claude echoes the prompt's uuid on the turn that answers
        // it, so a result for another turn (see isClaudeResultForOtherTurn)
        // never settles this one. On a CLI that echoes on the turn's first
        // frame, root output that arrives before the echo is held: the echo
        // releases it to this turn, and another turn's result sends it to the
        // wake buffer and so to a continuation run. The echo lands on the
        // turn's first frame, so the prompt's own turn streams without delay.
        // A CLI that echoes only on the result (or not at all) is never held,
        // exactly as before this gate.
        const handleSdkMessage = Effect.fnUntraced(function* (input: {
          readonly query: ClaudeAgentSdkQuerySession;
          readonly message: SDKMessage;
        }) {
          const message = input.message;
          const context = yield* Ref.get(activeTurn);
          const liveQuery = yield* Ref.get(queryContext);
          if (
            context === null ||
            context.promptUuid === null ||
            context.promptEcho === "confirmed" ||
            liveQuery?.query !== input.query
          ) {
            yield* handleRoutedSdkMessage(input);
            return;
          }
          if (claudeEchoedPromptUuids(message).includes(context.promptUuid)) {
            if (
              liveQuery.promptEchoMode === "unknown" ||
              liveQuery.promptEchoMode === "acknowledged"
            ) {
              liveQuery.promptEchoMode =
                message.type !== "result" && context.gatedFramesBeforeEcho === 0
                  ? "early"
                  : "result_only";
            }
            yield* releaseHeldRootFrames(context);
            yield* handleRoutedSdkMessage(input);
            return;
          }
          if (
            liveQuery.promptEchoMode === "unknown" &&
            claudeAcknowledgedPromptUuid(message) === context.promptUuid
          ) {
            liveQuery.promptEchoMode = "acknowledged";
          }
          if (!isClaudePromptEchoGatedFrame(message)) {
            // Frames the held turn produced through its own tool uses (a
            // subagent it launched, its task lifecycle) follow that turn;
            // anything else, such as an earlier subagent still streaming,
            // keeps its own owner.
            if (
              context.heldRootFrames.length > 0 &&
              claudeFrameToolUseIds(message).some((id) => heldToolUseIds(context).has(id))
            ) {
              context.heldRootFrames.push(message);
              return;
            }
            yield* handleRoutedSdkMessage(input);
            return;
          }
          context.gatedFramesBeforeEcho += 1;
          if (
            message.type === "result" &&
            isClaudeResultForOtherTurn({
              message,
              promptUuid: context.promptUuid,
              promptEchoMode: liveQuery.promptEchoMode,
            })
          ) {
            const held = context.heldRootFrames.splice(0);
            // The prompt's own turn follows, so echo timing is learned from it alone.
            context.gatedFramesBeforeEcho = 0;
            if (message.num_turns === 0) {
              // Lifecycle debris, not a turn: any held output stays held for
              // its real owner.
              context.heldRootFrames.push(...held);
              yield* Effect.logDebug("orchestration-v2.claude-result-for-other-turn-dropped", {
                providerTurnId: context.providerTurnId,
                origin: message.origin?.kind,
                uuid: message.uuid,
              });
              return;
            }
            if (liveQuery.promptEchoMode === "early") {
              // The held turn ran before this prompt's turn, which still
              // follows on the same stream.
              yield* Effect.logInfo("orchestration-v2.claude-wake-turn-before-prompt", {
                providerTurnId: context.providerTurnId,
                origin: message.origin?.kind,
                heldFrames: held.length,
              });
              for (const frame of [...held, message]) {
                yield* bufferWakeMessage({
                  nativeThreadId: liveQuery.nativeThreadId,
                  message: frame,
                });
              }
              return;
            }
            // Its output already streamed into this turn, so only its result
            // stays out: settling here would end the turn before its prompt
            // runs. The prompt's own turn ends it with an echoing result.
            if (isClaudeTaskNotificationOriginResult(message)) {
              // This turn showed the wake, so no offer will name its work.
              yield* clearWakeReports(liveQuery.nativeThreadId);
            }
            yield* Effect.logInfo("orchestration-v2.claude-result-for-other-turn", {
              providerTurnId: context.providerTurnId,
              origin: message.origin?.kind,
              num_turns: message.num_turns,
              uuid: message.uuid,
            });
            return;
          }
          if (liveQuery.promptEchoMode !== "early") {
            yield* handleRoutedSdkMessage(input);
            return;
          }
          if (message.type !== "result") {
            context.heldRootFrames.push(message);
            return;
          }
          // A result from no other turn (an interrupt, a startup failure)
          // settles the prompt's turn.
          yield* releaseHeldRootFrames(context);
          yield* handleRoutedSdkMessage(input);
        });

        const canUseToolEffect = Effect.fn("ClaudeAdapterV2.canUseTool")(function* (
          toolName: Parameters<CanUseTool>[0],
          toolInput: Parameters<CanUseTool>[1],
          callbackOptions: Parameters<CanUseTool>[2],
        ) {
          const context = yield* Ref.get(activeTurn);
          if (context === null) {
            return {
              behavior: "deny",
              message: "Claude V2 adapter has no active turn for this tool request.",
              toolUseID: callbackOptions.toolUseID,
            } satisfies PermissionResult;
          }

          const nativeRequestId = callbackOptions.toolUseID;
          const nativeToolInput = claudeNativeToolInputFromRecord(toolInput);
          // While root output awaits its prompt echo, the tool's streamed
          // frames are held and may belong to a queued wake turn, so the
          // callback must not attach anything to the pending prompt turn:
          // the held tool_use frame starts the tool (and projects an
          // ExitPlanMode plan) in whichever run it is released to.
          const heldForEcho = context.heldRootFrames.length > 0;
          if (toolName === "Agent") {
            rememberClaudeSubagentLaunch(context, nativeRequestId, nativeToolInput, null);
          } else if (!heldForEcho) {
            yield* ensureToolCallStarted({
              context,
              nativeItemId: nativeRequestId,
              toolName,
              toolInput: nativeToolInput,
              parentToolUseId: null,
            });
          }

          if (
            heldForEcho &&
            toolName !== "ExitPlanMode" &&
            (toolName === "AskUserQuestion" || requiresClaudeApproval(context))
          ) {
            // The SDK blocks on the answer, and the prompt echo cannot arrive
            // until the held turn goes on, so the request is raised now and
            // the held output goes with it to the pending prompt turn, as it
            // did before this turn was held. ExitPlanMode is answered at once
            // below, so its frames stay held.
            yield* releaseHeldRootFrames(context);
            if (toolName !== "Agent") {
              yield* ensureToolCallStarted({
                context,
                nativeItemId: nativeRequestId,
                toolName,
                toolInput: nativeToolInput,
                parentToolUseId: null,
              });
            }
          }

          if (toolName === "AskUserQuestion") {
            const questions = claudeUserInputQuestions(nativeToolInput);
            const artifacts = yield* buildApprovalRequestArtifacts({
              context,
              nativeItemId: nativeRequestId,
              nativeRequestId,
              requestKind: "user_input",
              questions,
            });
            const answers = yield* Deferred.make<ProviderUserInputAnswers, never>();
            yield* Ref.update(pendingRuntimeRequests, (current) => {
              const updated = new Map(current);
              updated.set(String(artifacts.request.id), {
                type: "user_input",
                requestId: artifacts.request.id,
                answers,
              });
              return updated;
            });
            yield* Effect.all(
              [
                emitProviderEvent({
                  type: "node.updated",
                  driver: CLAUDE_PROVIDER,
                  node: artifacts.node,
                }),
                emitProviderEvent({
                  type: "runtime_request.updated",
                  driver: CLAUDE_PROVIDER,
                  runtimeRequest: artifacts.request,
                }),
                emitProviderEvent({
                  type: "turn_item.updated",
                  driver: CLAUDE_PROVIDER,
                  turnItem: artifacts.turnItem,
                }),
              ],
              { concurrency: 1 },
            );
            const resolvedAnswers = yield* awaitClaudeUserInputAnswers(
              answers,
              callbackOptions.signal,
            ).pipe(
              Effect.ensuring(
                Ref.update(pendingRuntimeRequests, (current) => {
                  const updated = new Map(current);
                  updated.delete(String(artifacts.request.id));
                  return updated;
                }),
              ),
            );
            return callbackOptions.signal.aborted
              ? ({
                  behavior: "deny",
                  message: "User cancelled tool execution.",
                } satisfies PermissionResult)
              : ({
                  behavior: "allow",
                  updatedInput: {
                    questions: toolInput.questions,
                    answers: claudeSdkUserInputAnswers(resolvedAnswers),
                  },
                  toolUseID: callbackOptions.toolUseID,
                } satisfies PermissionResult);
          }

          if (toolName === "ExitPlanMode") {
            const markdown = claudeProposedPlan(nativeToolInput);
            // Defer only while the tool_use frame itself is still held, so
            // the plan is published when that frame is handled; otherwise
            // publish now. Claude is told the plan was captured either way.
            if (markdown !== null && heldToolUseIds(context).has(nativeRequestId)) {
              heldProposedPlansByToolUseId.set(nativeRequestId, markdown);
            } else if (markdown !== null) {
              yield* emitClaudePlanProjection({
                context,
                nativeItemId: nativeRequestId,
                kind: "proposed_plan",
                markdown,
              });
            }
            return {
              behavior: "deny",
              message:
                "The client captured your proposed plan. Stop here and wait for the user's feedback or implementation request in a later turn.",
              toolUseID: callbackOptions.toolUseID,
            } satisfies PermissionResult;
          }

          if (!requiresClaudeApproval(context)) {
            return {
              behavior: "allow",
              updatedInput: toolInput,
              toolUseID: callbackOptions.toolUseID,
            } satisfies PermissionResult;
          }

          const requestKind = providerRequestKindFromClaudeTool(toolName);
          const prompt =
            callbackOptions.title ??
            callbackOptions.description ??
            callbackOptions.decisionReason ??
            summarizeClaudeToolRequest(toolName, nativeToolInput);
          const artifacts = yield* buildApprovalRequestArtifacts({
            context,
            nativeItemId: nativeRequestId,
            nativeRequestId,
            requestKind,
            prompt,
          });
          const decision = yield* Deferred.make<ProviderApprovalDecision, never>();
          yield* Ref.update(pendingRuntimeRequests, (current) => {
            const updated = new Map(current);
            updated.set(String(artifacts.request.id), {
              type: "approval",
              requestId: artifacts.request.id,
              requestKind,
              decision,
            });
            return updated;
          });
          yield* Effect.all(
            [
              emitProviderEvent({
                type: "node.updated",
                driver: CLAUDE_PROVIDER,
                node: artifacts.node,
              }),
              emitProviderEvent({
                type: "runtime_request.updated",
                driver: CLAUDE_PROVIDER,
                runtimeRequest: artifacts.request,
              }),
              emitProviderEvent({
                type: "turn_item.updated",
                driver: CLAUDE_PROVIDER,
                turnItem: artifacts.turnItem,
              }),
            ],
            { concurrency: 1 },
          );

          const resolvedDecision = yield* awaitClaudeApprovalDecision(
            decision,
            callbackOptions.signal,
          ).pipe(
            Effect.ensuring(
              Ref.update(pendingRuntimeRequests, (current) => {
                const updated = new Map(current);
                updated.delete(String(artifacts.request.id));
                return updated;
              }),
            ),
          );

          return permissionResultFromDecision({
            toolName,
            decision: resolvedDecision,
            toolInput,
            toolUseID: callbackOptions.toolUseID,
            ...(callbackOptions.suggestions === undefined
              ? {}
              : { suggestions: callbackOptions.suggestions }),
          });
        });

        const canUseTool: CanUseTool = (toolName, toolInput, callbackOptions) =>
          runPromise(canUseToolEffect(toolName, toolInput, callbackOptions));

        const onUserDialog: NonNullable<ClaudeQueryOptions["onUserDialog"]> = (
          request,
          callbackOptions,
        ) =>
          runPromise(
            Effect.gen(function* () {
              if (request.dialogKind !== "resume_return") {
                return { behavior: "cancelled" as const };
              }
              const ageMinutes =
                typeof request.payload.sessionAgeMinutes === "number" &&
                Number.isFinite(request.payload.sessionAgeMinutes)
                  ? Math.max(0, Math.floor(request.payload.sessionAgeMinutes))
                  : 0;
              const estimatedTokens =
                typeof request.payload.estimatedTokens === "number" &&
                Number.isFinite(request.payload.estimatedTokens)
                  ? Math.max(0, Math.floor(request.payload.estimatedTokens))
                  : 0;
              const question = formatClaudeResumeCompactionQuestion({
                ageMinutes,
                estimatedTokens,
              });
              const result = yield* canUseToolEffect(
                "AskUserQuestion",
                {
                  questions: [
                    {
                      header: "Resume session",
                      question,
                      options: [
                        {
                          label: "Compact and continue",
                          description: "Resume with a summary and use fewer tokens.",
                        },
                        {
                          label: "Keep full history",
                          description: "Resume without changing the conversation.",
                        },
                        {
                          label: CLAUDE_RESUME_COMPACTION_NEVER_ANSWER,
                          description: "Keep full history and skip future resume prompts.",
                        },
                      ],
                      multiSelect: false,
                    },
                  ],
                },
                {
                  signal: callbackOptions.signal,
                  requestId: callbackOptions.requestId,
                  toolUseID: request.toolUseID ?? callbackOptions.requestId,
                },
              );
              if (result.behavior !== "allow") return { behavior: "cancelled" as const };
              const answers =
                result.updatedInput === undefined
                  ? undefined
                  : Reflect.get(result.updatedInput, "answers");
              const selection =
                typeof answers === "object" && answers !== null
                  ? Reflect.get(answers, question)
                  : undefined;
              return {
                behavior: "completed" as const,
                result:
                  selection === "Compact and continue"
                    ? ("compact" as const)
                    : selection === CLAUDE_RESUME_COMPACTION_NEVER_ANSWER
                      ? ("never" as const)
                      : ("continue" as const),
              };
            }),
          );

        // Work the live process still runs. A subagent whose completion is
        // already buffered is done: the buffer outlives the process.
        const liveProcessRunsBackgroundWork = Effect.fnUntraced(function* (
          live: ClaudeLiveQueryContext,
        ) {
          if (
            rosterForNativeThread(
              yield* Ref.get(pendingBackgroundTasksByNativeThread),
              live.nativeThreadId,
            ).size > 0
          ) {
            return true;
          }
          const buffered = (yield* Ref.get(wakeBuffers)).get(live.nativeThreadId)?.messages ?? [];
          for (const [taskId, subagent] of yield* Ref.get(sessionSubagentsByTaskId)) {
            if (
              subagent.task.status === "running" &&
              !live.subagentsFromEarlierProcesses.has(subagent) &&
              !buffered.some(
                (message) =>
                  message.type === "system" &&
                  message.subtype === "task_notification" &&
                  message.task_id === taskId,
              )
            ) {
              return true;
            }
          }
          return false;
        });

        const openQuery = Effect.fnUntraced(function* (
          turnInput: ProviderAdapter.ProviderAdapterV2TurnInput,
          nativeThreadId: string,
        ) {
          const queryPolicy = claudeRuntimeQueryPolicyForRuntimePolicy(turnInput.runtimePolicy);
          const mcpOverrides = claudeMcpQueryOverrides({
            threadId: turnInput.threadId,
            readOnlySandbox:
              sandboxPolicyKindForClaudeRuntimePolicy(turnInput.runtimePolicy) === "readOnly",
            ...(queryPolicy.allowedTools === undefined
              ? {}
              : { allowedTools: queryPolicy.allowedTools }),
          });
          const queryPolicyKey = claudeEffectiveQueryPolicyKey(queryPolicy, mcpOverrides);
          const compiledSelection = compileClaudeModelSelection(turnInput.modelSelection);
          const resumeSessionAt = yield* getNativeConversationHeadId(turnInput.providerThread);
          const existing = yield* Ref.get(queryContext);
          // A continuation prompts nothing: it drains output the live process
          // already produced, so it keeps that process whatever its selection.
          if (
            existing !== null &&
            existing.nativeThreadId === nativeThreadId &&
            isClaudeProviderContinuationTurn(turnInput)
          ) {
            return existing;
          }
          if (
            existing !== null &&
            existing.nativeThreadId === nativeThreadId &&
            existing.queryPolicyKey === queryPolicyKey &&
            existing.selectionKey === compiledSelection.queryIdentity
          ) {
            // Claude can switch its own mode mid-session (EnterPlanMode), and
            // a denied ExitPlanMode leaves it there. Put the live process back
            // in the thread's mode before the next prompt.
            if (existing.permissionMode !== existing.openedPermissionMode) {
              yield* existing.query.setPermissionMode(existing.openedPermissionMode);
              existing.permissionMode = existing.openedPermissionMode;
            }
            return existing;
          }

          // Background agents and shells run inside the CLI process, so a
          // new selection would kill them and lose their results. Refuse until
          // they finish or the user presses Stop, which closes the process.
          // Another native thread on this session is one the app thread has
          // left (Claude sessions serve one app thread), so it is replaced.
          if (
            existing !== null &&
            existing.nativeThreadId === nativeThreadId &&
            !existing.stopping &&
            (yield* liveProcessRunsBackgroundWork(existing))
          ) {
            return yield* new ClaudeBackgroundWorkBlocksQueryReplacementError();
          }

          // openQuery owns one live process. Closing it for another native
          // thread kills that sibling's CLI; it can never emit a roster clear,
          // so drop its process-scoped Waiting/wake state immediately. Closing
          // for the same native thread leaves a non-authoritative roster until
          // the replacement open succeeds or fails below.
          const closedExistingNativeThreadId = existing !== null ? existing.nativeThreadId : null;
          if (existing !== null) {
            yield* existing.query.close.pipe(Effect.ignore);
            if (existing.nativeThreadId !== nativeThreadId) {
              yield* clearWakeStateForNativeThread(existing.nativeThreadId);
              yield* resetBackgroundTaskStateForNativeThreadProcess(existing.nativeThreadId, {
                status: "idle",
              });
            }
          }

          const openedWithResume = (yield* Ref.get(openedNativeThreads)).has(nativeThreadId);
          // openedNativeThreads is per session instance and is lost when the
          // provider session is idle-released. A prior turn on this native id
          // requires resume; sessionId would fail with "already in use".
          // A fresh-session fallback keeps provider-thread history but binds
          // a new native id, which must be created before it can be resumed.
          const hasPersistedProviderTurn =
            turnInput.nativeThreadHasTurns ?? turnInput.providerTurnOrdinal > 1;
          const shouldResume =
            resumeSessionAt !== undefined || openedWithResume || hasPersistedProviderTurn;
          const queryOptions = makeClaudeQueryOptions({
            modelSelection: turnInput.modelSelection,
            nativeThreadId,
            resume: shouldResume,
            ...(resumeSessionAt === undefined ? {} : { resumeSessionAt }),
            cwd: turnInput.runtimePolicy.cwd,
            attachmentsDir,
            settings: adapterOptions.settings,
            environment: adapterOptions.environment,
            tools: queryPolicy.tools ?? CLAUDE_CODE_PRESET_TOOLS,
            ...mcpOverrides,
            permissionMode: queryPolicy.permissionMode,
            ...(queryPolicy.allowDangerouslySkipPermissions === undefined
              ? {}
              : {
                  allowDangerouslySkipPermissions: queryPolicy.allowDangerouslySkipPermissions,
                }),
            canUseTool,
            onUserDialog,
            supportedDialogKinds: ["resume_return"],
          });
          const querySession = yield* queryRunner
            .open({
              threadId: turnInput.threadId,
              providerSessionId: input.providerSessionId,
              options: queryOptions,
            })
            .pipe(
              Effect.tapError(() =>
                // Same-native-thread replacement: the old process is already
                // dead, so its process-scoped roster is not authoritative.
                // First-ever failed open (no prior live query) must not invent
                // native-session reset events.
                closedExistingNativeThreadId === nativeThreadId
                  ? Effect.gen(function* () {
                      yield* clearWakeStateForNativeThread(nativeThreadId);
                      yield* resetBackgroundTaskStateForNativeThreadProcess(nativeThreadId, {
                        status: "idle",
                      });
                    })
                  : Effect.void,
              ),
            );
          // Marked only after a successful open: a failed create must not
          // leave the runtime believing the native session exists, or the
          // retry would resume a session that was never created.
          yield* Ref.update(openedNativeThreads, (current) => {
            if (current.has(nativeThreadId)) {
              return current;
            }
            const updated = new Set(current);
            updated.add(nativeThreadId);
            return updated;
          });
          // Level is per CLI process: reset Waiting roster and wake
          // eligibility whenever this native thread's process starts or is
          // replaced. Membership repopulates on the next snapshot/edge.
          // openQuery only runs from startTurn after ProviderTurnStartService
          // marked the provider thread active, and before activeTurn is set.
          // Buffered local_bash task_notification classification is preserved
          // across this reset (see resetBackgroundTaskStateForNativeThreadProcess).
          yield* resetBackgroundTaskStateForNativeThreadProcess(nativeThreadId, {
            status: "active",
          });
          const closed = yield* Deferred.make<void, never>();
          const context: ClaudeLiveQueryContext = {
            nativeThreadId,
            query: querySession,
            queryPolicyKey,
            selectionKey: compiledSelection.queryIdentity,
            closed,
            promptEchoMode: "unknown",
            openedPermissionMode: queryOptions.permissionMode,
            permissionMode: queryOptions.permissionMode,
            stopping: false,
            subagentsFromEarlierProcesses: new Set(
              [...(yield* Ref.get(sessionSubagentsByTaskId)).values()].filter(
                (subagent) => subagent.task.status === "running",
              ),
            ),
          };
          yield* Ref.set(queryContext, context);
          yield* querySession.messages.pipe(
            Stream.runForEach((message) => {
              if (
                message.type === "system" &&
                (message.subtype === "init" || message.subtype === "status") &&
                message.permissionMode !== undefined
              ) {
                context.permissionMode = message.permissionMode;
              }
              return handleSdkMessage({ query: querySession, message });
            }),
            Effect.exit,
            Effect.flatMap(
              Effect.fnUntraced(function* (exit: ClaudeQueryStreamExit) {
                // Output held for a prompt echo that never came still
                // belongs to the turn this stream ended in. A replaced
                // query's exit must not touch the next query's turn.
                const heldContext = yield* Ref.get(activeTurn);
                if (
                  (yield* Ref.get(queryContext))?.query === querySession &&
                  heldContext !== null &&
                  heldContext.heldRootFrames.length > 0
                ) {
                  yield* releaseHeldRootFrames(heldContext);
                }
                const ownsLiveQuery = yield* Ref.modify(queryContext, (current) =>
                  current?.query === querySession ? [true, null] : [false, current],
                );
                if (ownsLiveQuery) {
                  yield* finalizeActiveTurnAfterQueryExit(
                    exit._tag === "Failure" ? exit.cause : undefined,
                  );
                }
              }),
            ),
            Effect.ensuring(Deferred.succeed(closed, undefined)),
            Effect.forkIn(sessionScope),
          );
          return context;
        });

        const startTurn = Effect.fn("ClaudeAdapterV2.startTurn")(
          function* (turnInput: ProviderAdapter.ProviderAdapterV2TurnInput) {
            const startedAt = yield* DateTime.now;
            const nativeThreadId = yield* getNativeThreadId(turnInput.providerThread);
            const nativeTurnId = `turn:${turnInput.attemptId}`;
            const providerTurnId = idAllocator.derive.providerTurn({
              driver: CLAUDE_PROVIDER,
              nativeTurnId,
            });
            const providerTurnOrdinal = turnInput.providerTurnOrdinal;
            const currentTurn = yield* Ref.get(activeTurn);
            if (currentTurn !== null) {
              return yield* new ProviderAdapter.ProviderAdapterProtocolError({
                driver: CLAUDE_PROVIDER,
                detail: `Claude provider turn ${currentTurn.providerTurnId} is still active.`,
              });
            }
            yield* Ref.update(lastTurnRouteByNativeThread, (current) => {
              const updated = new Map(current);
              updated.set(nativeThreadId, {
                threadId: turnInput.threadId,
                providerThreadId: turnInput.providerThread.id,
              });
              return updated;
            });
            yield* rememberProviderThread(turnInput.providerThread);
            if (!goalsByNativeThread.has(nativeThreadId)) {
              goalsByNativeThread.set(nativeThreadId, turnInput.providerThread.goal ?? null);
            }
            const context: ActiveClaudeTurnContext = {
              input: turnInput,
              nativeTurnId,
              nativeMessageCursor: null,
              providerTurnId,
              providerTurnOrdinal,
              startedAt,
              itemOrdinals: new Map(),
              assistant: {
                fallbackText: "",
                fallbackNativeItemId: `assistant:${turnInput.runId}`,
                emittedNativeItemIds: new Set(),
              },
              reasoning: {
                messageId: null,
                streamBlocks: new Map(),
                nextBlockIndex: new Map(),
                snapshotBlockIndex: new Map(),
                snapshots: new Set(),
                blocks: new Map(),
              },
              toolCalls: new Map(),
              ignoredTaskIds: new Set(),
              announcedUsageLimits: new Set(),
              authenticationFailureMessage: undefined,
              rejectedRateLimitTypes: new Set(),
              rateLimitResetTimes: new Map(),
              latestAssistantRateLimited: false,
              subagentsByTaskId: new Map(),
              subagentsByToolUseId: new Map(),
              subagentNodesByTaskId: new Map(),
              pendingSubagentLaunchesByToolUseId: new Map(),
              promptUuid: isClaudeProviderContinuationTurn(turnInput)
                ? null
                : claudePromptUuid(turnInput.attemptId),
              promptEcho: isClaudeProviderContinuationTurn(turnInput) ? "confirmed" : "pending",
              gatedFramesBeforeEcho: 0,
              heldRootFrames: [],
            };
            // Continuation turns attach to the wake output the CLI already
            // produced instead of prompting it again: drain the buffered wake
            // messages into this turn and let any still-streaming messages
            // follow live. The continuation prompt text never reaches the CLI.
            const isContinuationTurn = context.promptUuid === null;
            const userMessage = isContinuationTurn
              ? null
              : yield* makeClaudeUserMessageWithAttachments({
                  text:
                    turnInput.message.text.trim() === "/compact"
                      ? turnInput.message.text
                      : applyClaudePromptEffortPrefix(
                          turnInput.message.text,
                          compileClaudeModelSelection(turnInput.modelSelection).promptEffort,
                        ),
                  attachments: turnInput.message.attachments,
                  attachmentsDir,
                  fileSystem,
                  skillNames: yield* userInvocableSkillNames(turnInput.runtimePolicy.cwd),
                  uuid: claudePromptUuid(turnInput.attemptId),
                });
            const querySession = yield* openQuery(turnInput, nativeThreadId);
            yield* Ref.set(activeTurn, context);
            yield* emitProviderEvent({
              type: "provider_turn.updated",
              driver: CLAUDE_PROVIDER,
              providerTurn: providerTurnPayload({
                context,
                status: "running",
                completedAt: null,
              }),
            });
            if (userMessage !== null) {
              // A user turn that races a wake leaves the buffer alone: the
              // continuation run the worker queued behind this run drains it
              // afterwards with correct attribution.
              // Counted only here, so a turn that failed to start does not age reports.
              yield* startUserTurnForWakeReports(nativeThreadId);
              yield* querySession.query.offer(userMessage);
              return;
            }
            const drained = yield* Ref.modify(wakeBuffers, (current) => {
              const entry = current.get(nativeThreadId);
              if (entry === undefined) {
                return [[] as ReadonlyArray<SDKMessage>, current] as const;
              }
              const updated = new Map(current);
              updated.delete(nativeThreadId);
              return [entry.messages, updated] as const;
            });
            yield* Ref.update(requestedContinuations, (current) => {
              const updated = new Set(current);
              updated.delete(nativeThreadId);
              return updated;
            });
            if (drained.length === 0) {
              // Spurious continuation (buffer already lost with a recycled
              // session, or a duplicate request): settle immediately instead
              // of leaving a run waiting on a prompt that was never sent.
              const completedAt = yield* DateTime.now;
              yield* finalizeActiveTurn({ context, status: "completed", completedAt });
              return;
            }
            // Replay any result message last: a result finalizes the turn, and
            // replaying it before the rest would drop them back into the wake
            // buffer and request another continuation.
            const resultMessages = drained.filter((entry) => entry.type === "result");
            const opaqueReplayTombstones = taskIdSetForNativeThread(
              yield* Ref.get(opaqueBackgroundTaskReplayTombstonesByNativeThread),
              nativeThreadId,
            );
            const hasOpaqueTaskNotification = drained.some(
              (entry) =>
                entry.type === "system" &&
                entry.subtype === "task_notification" &&
                opaqueReplayTombstones.has(entry.task_id),
            );
            for (const entry of drained) {
              if (entry.type !== "result") {
                yield* handleSdkMessage({ query: querySession.query, message: entry });
              }
            }
            const lastResult = resultMessages.at(-1);
            if (lastResult !== undefined) {
              yield* handleSdkMessage({ query: querySession.query, message: lastResult });
              return;
            }
            // A drained `init` means Claude began the wake turn, so its output
            // may still be on the way: stay open for it.
            const hasNativeWakeFrame = drained.some(
              (entry) =>
                entry.type === "user" ||
                entry.type === "assistant" ||
                isClaudeTurnStartMessage(entry),
            );
            if (hasOpaqueTaskNotification && !hasNativeWakeFrame) {
              const completedAt = yield* DateTime.now;
              yield* finalizeActiveTurn({ context, status: "completed", completedAt });
            }
          },
          (effect, turnInput) =>
            effect.pipe(
              Effect.mapError(
                (cause) =>
                  new ProviderAdapter.ProviderAdapterTurnStartError({
                    driver: CLAUDE_PROVIDER,
                    threadId: turnInput.threadId,
                    providerThreadId: turnInput.providerThread.id,
                    runId: turnInput.runId,
                    cause,
                  }),
              ),
            ),
        );

        const interruptTurn = Effect.fn("ClaudeAdapterV2.interruptTurn")(
          function* (turnInput: ProviderAdapter.ProviderAdapterV2InterruptInput) {
            const existing = yield* Ref.get(queryContext);
            const currentTurn = yield* Ref.get(activeTurn);
            const nativeThreadId = turnInput.providerThread.nativeThreadRef?.nativeId ?? null;
            if (currentTurn === null && turnInput.requestRuntimeRestart === true) {
              // Stop after the turn settled. With no CLI process of this
              // native thread left, nothing it started is still running: its
              // roster is not authoritative any more, and the orchestrator
              // settles the items the thread still shows.
              if (nativeThreadId === null) return;
              if (existing === null || existing.nativeThreadId !== nativeThreadId) {
                yield* clearWakeStateForNativeThread(nativeThreadId);
                yield* resetBackgroundTaskStateForNativeThreadProcess(nativeThreadId, {
                  status: "idle",
                });
                return;
              }
              // The background shells belong to the CLI process, so closing
              // its query is what stops them.
              yield* closeLiveQueryForNativeThread(nativeThreadId);
              // A turn started while the close was pending may have opened a
              // replacement process. Its Waiting and wake state are its own.
              const current = yield* Ref.get(queryContext);
              if (current === null || current.query === existing.query) {
                yield* clearWakeStateForNativeThread(nativeThreadId);
                yield* resetBackgroundTaskStateForNativeThreadProcess(nativeThreadId, {
                  status: "idle",
                });
              }
              return;
            }
            if (existing === null) {
              return yield* new ProviderAdapter.ProviderAdapterProtocolError({
                driver: CLAUDE_PROVIDER,
                detail: `Claude provider thread ${turnInput.providerThread.id} has no live query.`,
              });
            }
            if (currentTurn?.providerTurnId !== turnInput.providerTurnId) {
              return yield* new ProviderAdapter.ProviderAdapterProtocolError({
                driver: CLAUDE_PROVIDER,
                detail: `Claude provider turn ${turnInput.providerTurnId} is not the active turn.`,
              });
            }
            yield* Ref.update(interruptedTurns, (current) => {
              const next = new Set(current);
              next.add(turnInput.providerTurnId);
              return next;
            });
            yield* existing.query.interrupt;
            yield* existing.query.close.pipe(Effect.ignore);
            const closed = yield* Deferred.await(existing.closed).pipe(
              Effect.timeoutOption("10 seconds"),
            );
            if (Option.isSome(closed)) {
              return;
            }

            const completedAt = yield* DateTime.now;
            yield* Effect.logWarning("orchestration-v2.claude-query-interrupt-timeout", {
              providerSessionId: input.providerSessionId,
              providerThreadId: turnInput.providerThread.id,
              providerTurnId: turnInput.providerTurnId,
            });
            yield* Ref.update(queryContext, (current) =>
              current?.query === existing.query ? null : current,
            );
            yield* finalizeActiveTurn({
              context: currentTurn,
              status: "interrupted",
              completedAt,
            });
            yield* Deferred.succeed(existing.closed, undefined);
          },
          (effect, turnInput) =>
            effect.pipe(
              Effect.mapError(
                (cause) =>
                  new ProviderAdapter.ProviderAdapterInterruptError({
                    driver: CLAUDE_PROVIDER,
                    providerThreadId: turnInput.providerThread.id,
                    providerTurnId: turnInput.providerTurnId,
                    cause,
                  }),
              ),
            ),
        );

        const steerTurn = Effect.fn("ClaudeAdapterV2.steerTurn")(
          function* (turnInput: ProviderAdapter.ProviderAdapterV2SteerInput) {
            const existing = yield* Ref.get(queryContext);
            if (existing === null) {
              return yield* new ProviderAdapter.ProviderAdapterProtocolError({
                driver: CLAUDE_PROVIDER,
                detail: `Claude provider thread ${turnInput.providerThread.id} has no live query.`,
              });
            }
            const currentTurn = yield* Ref.get(activeTurn);
            if (currentTurn?.providerTurnId !== turnInput.providerTurnId) {
              return yield* new ProviderAdapter.ProviderAdapterProtocolError({
                driver: CLAUDE_PROVIDER,
                detail: `Claude provider turn ${turnInput.providerTurnId} is not the active turn.`,
              });
            }
            const userMessage = yield* makeClaudeUserMessageWithAttachments({
              text: applyClaudePromptEffortPrefix(
                turnInput.message.text,
                compileClaudeModelSelection(currentTurn.input.modelSelection).promptEffort,
              ),
              attachments: turnInput.message.attachments,
              priority: "now",
              attachmentsDir,
              fileSystem,
              skillNames: yield* userInvocableSkillNames(currentTurn.input.runtimePolicy.cwd),
            });
            yield* Ref.update(steeredTurns, (current) => {
              const next = new Set(current);
              next.add(turnInput.providerTurnId);
              return next;
            });
            yield* existing.query.offer(userMessage);
          },
          (effect, turnInput) =>
            effect.pipe(
              Effect.mapError(
                (cause) =>
                  new ProviderAdapter.ProviderAdapterSteerRunError({
                    driver: CLAUDE_PROVIDER,
                    providerThreadId: turnInput.providerThread.id,
                    providerTurnId: turnInput.providerTurnId,
                    cause,
                  }),
              ),
            ),
        );

        const closeSession = Effect.fnUntraced(function* () {
          const existing = yield* Ref.get(queryContext);
          if (existing !== null) {
            yield* existing.query.close.pipe(Effect.ignore);
          }
          yield* Effect.yieldNow;
          yield* queryRunner.assertComplete.pipe(
            Effect.catchCause((cause) =>
              Effect.logWarning("orchestration-v2.claude-query-runner-incomplete", {
                providerSessionId: input.providerSessionId,
                cause,
              }),
            ),
          );
        });

        const closeLiveQueryForNativeThread = Effect.fnUntraced(function* (nativeThreadId: string) {
          const existing = yield* Ref.get(queryContext);
          if (existing === null || existing.nativeThreadId !== nativeThreadId) {
            return;
          }

          existing.stopping = true;
          yield* existing.query.close.pipe(Effect.ignore);
          const closed = yield* Deferred.await(existing.closed).pipe(
            Effect.timeoutOption("10 seconds"),
          );
          if (Option.isSome(closed)) {
            return;
          }

          yield* Effect.logWarning("orchestration-v2.claude-query-close-timeout-before-fork", {
            providerSessionId: input.providerSessionId,
            nativeThreadId,
          });
          yield* Ref.update(queryContext, (current) =>
            current?.query === existing.query ? null : current,
          );
          yield* Deferred.succeed(existing.closed, undefined);
        });
        yield* Effect.addFinalizer(() => closeSession());

        const runtime: ProviderAdapter.ProviderAdapterV2SessionRuntime = {
          instanceId: adapterOptions.instanceId,
          driver: CLAUDE_PROVIDER,
          providerSessionId: input.providerSessionId,
          providerSession: session,
          getModelContextWindow: (selection) =>
            resolveClaudeCatalogContextWindowTokens(BUNDLED_CLAUDE_MODEL_CATALOG, selection),
          events: Stream.fromEffectRepeat(Queue.take(events)),
          hasPendingBackgroundWork: Effect.gen(function* () {
            // Session capability: any native thread with pending work pins idle.
            for (const roster of (yield* Ref.get(pendingBackgroundTasksByNativeThread)).values()) {
              if (roster.size > 0) {
                return true;
              }
            }
            for (const subagent of (yield* Ref.get(sessionSubagentsByTaskId)).values()) {
              if (subagent.task.status === "running") {
                return true;
              }
            }
            const buffers = yield* Ref.get(wakeBuffers);
            for (const entry of buffers.values()) {
              if (
                entry.messages.some(
                  (message) =>
                    message.type === "user" ||
                    message.type === "assistant" ||
                    message.type === "result",
                )
              ) {
                return true;
              }
            }
            return false;
          }),
          hasPendingBackgroundWorkForThread: (providerThread) =>
            Effect.gen(function* () {
              const nativeThreadId = providerThread.nativeThreadRef?.nativeId;
              if (nativeThreadId === undefined || nativeThreadId === null) {
                return false;
              }
              // Root-run stop gate: only this native thread's roster. Session
              // subagents and wake buffers stay on the session-wide probe.
              return (
                rosterForNativeThread(
                  yield* Ref.get(pendingBackgroundTasksByNativeThread),
                  nativeThreadId,
                ).size > 0
              );
            }),
          ensureThread: Effect.fn("ClaudeAdapterV2.ensureThread")(
            function* (threadInput: ProviderAdapter.ProviderAdapterV2EnsureThreadInput) {
              const createdAt = yield* DateTime.now;
              const nativeThreadId = yield* queryRunner.allocateSessionId;
              return makeProviderThread({
                idAllocator,
                providerInstanceId: adapterOptions.instanceId,
                appThreadId: threadInput.threadId,
                providerSessionId: input.providerSessionId,
                nativeThreadId,
                now: createdAt,
              });
            },
            (effect, threadInput) =>
              effect.pipe(
                Effect.mapError(
                  (cause) =>
                    new ProviderAdapter.ProviderAdapterEnsureThreadError({
                      driver: CLAUDE_PROVIDER,
                      threadId: threadInput.threadId,
                      cause,
                    }),
                ),
              ),
          ),
          resumeThread: Effect.fn("ClaudeAdapterV2.resumeThread")(
            function* (threadInput: { readonly providerThread: OrchestrationV2ProviderThread }) {
              const updatedAt = yield* DateTime.now;
              return {
                ...threadInput.providerThread,
                providerSessionId: input.providerSessionId,
                status: "idle" as const,
                updatedAt,
              };
            },
            (effect, threadInput) =>
              effect.pipe(
                Effect.mapError(
                  (cause) =>
                    new ProviderAdapter.ProviderAdapterResumeThreadError({
                      driver: CLAUDE_PROVIDER,
                      providerSessionId: input.providerSessionId,
                      providerThreadId: threadInput.providerThread.id,
                      cause,
                    }),
                ),
              ),
          ),
          startTurn,
          compactThread: (turnInput) =>
            startTurn({
              ...turnInput,
              message: { ...turnInput.message, text: "/compact" },
            }),
          steerTurn,
          interruptTurn,
          respondToRuntimeRequest: Effect.fn("ClaudeAdapterV2.respondToRuntimeRequest")(
            function* (requestInput) {
              const pending = (yield* Ref.get(pendingRuntimeRequests)).get(
                String(requestInput.requestId),
              );
              if (pending === undefined) {
                return yield* new ProviderAdapter.ProviderAdapterRuntimeRequestResponseError({
                  driver: CLAUDE_PROVIDER,
                  requestId: requestInput.requestId,
                  cause: new ProviderAdapter.ProviderAdapterProtocolError({
                    driver: CLAUDE_PROVIDER,
                    detail: `No pending Claude runtime request ${requestInput.requestId}.`,
                  }),
                });
              }
              if (pending.type === "user_input") {
                yield* Deferred.succeed(pending.answers, requestInput.answers ?? {});
                return;
              }
              if (requestInput.decision === undefined) {
                return yield* new ProviderAdapter.ProviderAdapterRuntimeRequestResponseError({
                  driver: CLAUDE_PROVIDER,
                  requestId: requestInput.requestId,
                  cause: new ProviderAdapter.ProviderAdapterProtocolError({
                    driver: CLAUDE_PROVIDER,
                    detail: `Claude ${pending.requestKind} request ${requestInput.requestId} requires an approval decision.`,
                  }),
                });
              }
              yield* Deferred.succeed(pending.decision, requestInput.decision);
            },
            (effect, requestInput) =>
              effect.pipe(
                Effect.mapError((cause) =>
                  isProviderAdapterRuntimeRequestResponseError(cause)
                    ? cause
                    : new ProviderAdapter.ProviderAdapterRuntimeRequestResponseError({
                        driver: CLAUDE_PROVIDER,
                        requestId: requestInput.requestId,
                        cause,
                      }),
                ),
              ),
          ),
          readThreadSnapshot: (snapshotInput) =>
            Effect.fail(
              new ProviderAdapter.ProviderAdapterReadThreadSnapshotError({
                driver: CLAUDE_PROVIDER,
                providerThreadId: snapshotInput.providerThread.id,
                cause: "Claude V2 adapter does not implement snapshots.",
              }),
            ),
          rollbackThread: Effect.fn("ClaudeAdapterV2.rollbackThread")(
            function* (rollbackInput) {
              const currentTurn = yield* Ref.get(activeTurn);
              if (currentTurn !== null) {
                return yield* new ProviderAdapter.ProviderAdapterProtocolError({
                  driver: CLAUDE_PROVIDER,
                  detail: `Cannot roll back Claude provider thread ${rollbackInput.providerThread.id} while provider turn ${currentTurn.providerTurnId} is active.`,
                });
              }

              const nativeThreadId = yield* getNativeThreadId(rollbackInput.providerThread);
              yield* closeLiveQueryForNativeThread(nativeThreadId);
              const now = yield* DateTime.now;

              if (rollbackInput.target.type === "thread_start") {
                const resetNativeThreadId = yield* queryRunner.allocateSessionId;
                return {
                  providerThread: {
                    ...makeProviderThread({
                      idAllocator,
                      providerInstanceId: adapterOptions.instanceId,
                      appThreadId: rollbackInput.providerThread.appThreadId,
                      ...(rollbackInput.providerThread.ownerNodeId === null
                        ? {}
                        : { ownerNodeId: rollbackInput.providerThread.ownerNodeId }),
                      providerSessionId: input.providerSessionId,
                      nativeThreadId: resetNativeThreadId,
                      ...(rollbackInput.providerThread.forkedFrom === null
                        ? {}
                        : { forkedFrom: rollbackInput.providerThread.forkedFrom }),
                      now,
                    }),
                    handoffIds: rollbackInput.providerThread.handoffIds,
                  },
                  providerTurns: [],
                  messages: [],
                  runtimeRequests: [],
                };
              }

              const resumeSessionAt = yield* resolveClaudeRollbackResumeSessionAt(rollbackInput);
              return {
                providerThread: {
                  ...rollbackInput.providerThread,
                  providerSessionId: input.providerSessionId,
                  nativeConversationHeadRef:
                    resumeSessionAt === null
                      ? null
                      : {
                          driver: CLAUDE_PROVIDER,
                          nativeId: resumeSessionAt,
                          strength: "weak" as const,
                        },
                  status: "idle" as const,
                  lastRunOrdinal: rollbackInput.target.appRunOrdinal,
                  updatedAt: now,
                },
                providerTurns: [],
                messages: [],
                runtimeRequests: [],
              };
            },
            (effect, rollbackInput) =>
              effect.pipe(
                Effect.mapError((cause) =>
                  isProviderAdapterRollbackThreadError(cause)
                    ? cause
                    : new ProviderAdapter.ProviderAdapterRollbackThreadError({
                        driver: CLAUDE_PROVIDER,
                        providerThreadId: rollbackInput.providerThread.id,
                        cause,
                      }),
                ),
              ),
          ),
          forkThread: Effect.fn("ClaudeAdapterV2.forkThread")(
            function* (forkInput) {
              const currentTurn = yield* Ref.get(activeTurn);
              if (currentTurn !== null) {
                return yield* new ProviderAdapter.ProviderAdapterProtocolError({
                  driver: CLAUDE_PROVIDER,
                  detail: `Cannot fork Claude provider thread ${forkInput.sourceProviderThread.id} while provider turn ${currentTurn.providerTurnId} is active.`,
                });
              }

              const sourceNativeThreadId = yield* getNativeThreadId(forkInput.sourceProviderThread);
              yield* closeLiveQueryForNativeThread(sourceNativeThreadId);
              const upToMessageId = yield* resolveClaudeForkUpToMessageId(forkInput);
              const forkOptions: ForkSessionOptions = {
                ...(input.runtimePolicy.cwd === null ? {} : { dir: input.runtimePolicy.cwd }),
                ...(upToMessageId === undefined ? {} : { upToMessageId }),
              };
              const forked = yield* queryRunner.forkSession({
                sessionId: sourceNativeThreadId,
                options: forkOptions,
                threadId: forkInput.targetThreadId,
                providerSessionId: input.providerSessionId,
              });
              yield* Ref.update(openedNativeThreads, (current) => {
                const updated = new Set(current);
                updated.add(forked.sessionId);
                return updated;
              });
              const now = yield* DateTime.now;
              return makeProviderThread({
                idAllocator,
                providerInstanceId: adapterOptions.instanceId,
                appThreadId: forkInput.targetThreadId,
                ownerNodeId: forkInput.ownerNodeId ?? null,
                providerSessionId: input.providerSessionId,
                nativeThreadId: forked.sessionId,
                forkedFrom: {
                  providerThreadId: forkInput.sourceProviderThread.id,
                  ...(forkInput.providerTurnId === undefined
                    ? {}
                    : { providerTurnId: forkInput.providerTurnId }),
                },
                now,
              });
            },
            (effect, forkInput) =>
              effect.pipe(
                Effect.mapError(
                  (cause) =>
                    new ProviderAdapter.ProviderAdapterForkThreadError({
                      driver: CLAUDE_PROVIDER,
                      providerThreadId: forkInput.sourceProviderThread.id,
                      cause,
                    }),
                ),
              ),
          ),
        };

        return runtime;
      },
      (effect, input) =>
        effect.pipe(
          Effect.mapError(
            (cause) =>
              new ProviderAdapter.ProviderAdapterOpenSessionError({
                driver: CLAUDE_PROVIDER,
                providerSessionId: input.providerSessionId,
                cause,
              }),
          ),
        ),
    ),
  });
}

export type ClaudeAdapterV2DriverEnv =
  | ClaudeAgentSdkQueryRunner
  | FileSystem.FileSystem
  | IdAllocator.IdAllocatorV2
  | Path.Path
  | ServerConfig.ServerConfig;

export const createClaudeAdapterV2 = Effect.fn("ClaudeAdapterV2Driver.create")(
  function* (
    input: ProviderAdapterDriverCreateInput<ClaudeSettings>,
    hooks: Pick<ClaudeAdapterV2Options, "scopedLimitNames" | "onUsageLimits"> = {},
  ) {
    const { instanceId, environment, enabled, config } = input;
    const fileSystem = yield* FileSystem.FileSystem;
    const hostEnvironment = yield* HostProcessEnvironment;
    const idAllocator = yield* IdAllocator.IdAllocatorV2;
    const queryRunner = yield* ClaudeAgentSdkQueryRunner;
    const serverConfig = yield* ServerConfig.ServerConfig;
    const continuationRequests = yield* ProviderContinuationRequests.ProviderContinuationRequests;
    const baseEnvironment = mergeProviderInstanceEnvironment(environment, hostEnvironment);
    const claudeEnvironment = yield* makeClaudeEnvironment(config, baseEnvironment);
    const path = yield* Path.Path;
    const binaryPath = yield* resolveClaudeSdkExecutablePath(
      expandHomePath(config.binaryPath),
      claudeEnvironment,
    );
    return makeClaudeAdapterV2({
      instanceId,
      settings: { ...config, enabled, binaryPath },
      environment: claudeEnvironment,
      attachmentsDir: serverConfig.attachmentsDir,
      fileSystem,
      path,
      idAllocator,
      queryRunner,
      continuationRequests,
      ...hooks,
    });
  },
  (effect, input, _hooks) =>
    effect.pipe(
      Effect.mapError(
        (cause) =>
          new ProviderAdapterDriverCreateError({
            driver: CLAUDE_PROVIDER,
            instanceId: input.instanceId,
            detail: "Failed to create Claude Agent SDK adapter.",
            cause,
          }),
      ),
    ),
);

export const ClaudeAdapterV2Driver: ProviderAdapterDriver<
  ClaudeSettings,
  ClaudeAdapterV2DriverEnv
> = {
  driverKind: CLAUDE_PROVIDER,
  configSchema: ClaudeSettings,
  defaultConfig: (): ClaudeSettings => DEFAULT_CLAUDE_SETTINGS,
  create: (input) => createClaudeAdapterV2(input, {}),
};

const makeDefaultClaudeAdapterV2 = Effect.fn("ClaudeAdapterV2.layer")(function* () {
  const fileSystem = yield* FileSystem.FileSystem;
  const path = yield* Path.Path;
  const hostEnvironment = yield* HostProcessEnvironment;
  const idAllocator = yield* IdAllocator.IdAllocatorV2;
  const queryRunner = yield* ClaudeAgentSdkQueryRunner;
  const serverConfig = yield* ServerConfig.ServerConfig;
  const continuationRequests = yield* ProviderContinuationRequests.ProviderContinuationRequests;

  return makeClaudeAdapterV2({
    instanceId: CLAUDE_DEFAULT_INSTANCE_ID,
    settings: DEFAULT_CLAUDE_SETTINGS,
    environment: hostEnvironment,
    attachmentsDir: serverConfig.attachmentsDir,
    fileSystem,
    path,
    idAllocator,
    queryRunner,
    continuationRequests,
  });
});

const layer: Layer.Layer<
  ProviderAdapter.ProviderAdapterV2,
  never,
  | ClaudeAgentSdkQueryRunner
  | FileSystem.FileSystem
  | IdAllocator.IdAllocatorV2
  | Path.Path
  | ServerConfig.ServerConfig
> = Layer.effect(ProviderAdapter.ProviderAdapterV2, makeDefaultClaudeAdapterV2());
