import {
  defaultProcessTreeKiller,
  type CapturedProcess,
  type ProcessTreeKiller,
  type TerminalKillSignal,
} from "../terminal/processTreeKiller.ts";
import { Effect } from "effect";

const DEFAULT_TERM_GRACE_MS = 1_500;
const DEFAULT_FORCE_EXIT_MS = 1_500;
const DEFAULT_POLL_MS = 25;
// Each descendant inspection shells out to a synchronous `ps`, so it must not run
// once per poll: that put ~120 blocking scans on the event loop per teardown, and
// the session reaper runs teardowns on a timer with no user present.
const DEFAULT_INSPECT_INTERVAL_MS = 250;

export interface SupervisedProcessTeardownInput {
  readonly rootPid: number;
  /** Must resolve only after the owned root process has emitted its terminal exit. */
  readonly rootExited: Promise<unknown>;
  readonly termGraceMs?: number;
  readonly forceExitMs?: number;
  readonly pollMs?: number;
  /** Minimum gap between descendant `ps` inspections while polling for exit proof. */
  readonly inspectIntervalMs?: number;
}

export interface ProcessExitHandle {
  readonly pid?: number | undefined;
  readonly exitCode: number | null;
  readonly signalCode: NodeJS.Signals | null;
  once(event: "exit", listener: () => void): unknown;
  removeListener(event: "exit", listener: () => void): unknown;
}

export interface EffectProcessExitHandle {
  readonly pid: number;
  readonly exitCode: Effect.Effect<unknown, unknown>;
}

export interface SupervisedProcessTeardownResult {
  readonly escalated: boolean;
  readonly signalErrors: ReadonlyArray<Error>;
}

export interface SupervisedProcessTeardownDependencies {
  readonly processTreeKiller: ProcessTreeKiller;
  readonly now: () => number;
  readonly sleep: (milliseconds: number) => Promise<void>;
}

export class ProviderProcessExitUnprovenError extends Error {
  readonly rootPid: number;
  readonly rootExited: boolean;
  readonly remainingDescendantPids: ReadonlyArray<number> | null;
  readonly captureComplete: boolean;

  constructor(input: {
    readonly rootPid: number;
    readonly rootExited: boolean;
    readonly remainingDescendantPids: ReadonlyArray<number> | null;
    readonly captureComplete: boolean;
  }) {
    const descendantDetail =
      input.remainingDescendantPids === null
        ? "descendant state could not be verified"
        : input.remainingDescendantPids.length > 0
          ? `descendants still running: ${input.remainingDescendantPids.join(", ")}`
          : "no captured descendants remain";
    super(
      `Provider process tree ${input.rootPid} did not prove exit ` +
        `(rootExited=${String(input.rootExited)}, captureComplete=${String(input.captureComplete)}; ${descendantDetail}).`,
    );
    this.name = "ProviderProcessExitUnprovenError";
    this.rootPid = input.rootPid;
    this.rootExited = input.rootExited;
    this.remainingDescendantPids = input.remainingDescendantPids;
    this.captureComplete = input.captureComplete;
  }
}

const defaultDependencies: SupervisedProcessTeardownDependencies = {
  processTreeKiller: defaultProcessTreeKiller,
  now: Date.now,
  sleep: (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)),
};

function positiveDuration(value: number | undefined, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : fallback;
}

function waitForOwnedProcessExit(process: ProcessExitHandle): Promise<void> {
  if (process.exitCode !== null || process.signalCode !== null) {
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    const onExit = () => resolve();
    process.once("exit", onExit);
    if (process.exitCode !== null || process.signalCode !== null) {
      process.removeListener("exit", onExit);
      resolve();
    }
  });
}

export async function teardownChildProcessTree(
  process: ProcessExitHandle,
  teardownProcessTree: typeof teardownProviderProcessTree = teardownProviderProcessTree,
): Promise<SupervisedProcessTeardownResult> {
  if (process.pid === undefined) {
    throw new Error("Cannot prove process exit because the spawned process has no PID.");
  }
  return teardownProcessTree({
    rootPid: process.pid,
    rootExited: waitForOwnedProcessExit(process),
  });
}

export function teardownEffectProcessTree(
  process: EffectProcessExitHandle,
  teardownProcessTree: typeof teardownProviderProcessTree = teardownProviderProcessTree,
): Promise<SupervisedProcessTeardownResult> {
  return teardownProcessTree({
    rootPid: Number(process.pid),
    rootExited: Effect.runPromise(Effect.exit(process.exitCode)),
  });
}

/**
 * Owns the complete provider process-tree stop sequence. Success means the exact root emitted exit
 * and every identity-matched descendant captured before TERM is gone; sending a signal is not
 * considered completion.
 */
export async function teardownProviderProcessTree(
  input: SupervisedProcessTeardownInput,
  dependencies: Partial<SupervisedProcessTeardownDependencies> = {},
): Promise<SupervisedProcessTeardownResult> {
  if (!Number.isInteger(input.rootPid) || input.rootPid <= 0) {
    throw new TypeError(
      `Provider process root PID must be a positive integer, got ${input.rootPid}.`,
    );
  }

  const deps = { ...defaultDependencies, ...dependencies };
  const tree = deps.processTreeKiller.capture(input.rootPid);
  const signalErrors: Error[] = [];
  let rootExited = false;
  void input.rootExited.then(
    () => {
      rootExited = true;
    },
    () => {
      // A rejected watcher is not evidence that the owned process exited.
    },
  );

  const signal = (killSignal: TerminalKillSignal, includeRootTree: boolean): void => {
    deps.processTreeKiller.signal({
      rootPid: input.rootPid,
      signal: killSignal,
      tree,
      includeRootTree,
      onError: (error) => signalErrors.push(error),
    });
  };

  // An empty incomplete capture means descendant state is unknown, not verified
  // empty. Releasing ownership on it could let a replacement start while a
  // reparented descendant from the old provider is still running.
  const inspectDescendants = (): ReadonlyArray<CapturedProcess> | null => {
    const inspection =
      tree.captureComplete === false ? undefined : deps.processTreeKiller.inspect?.(tree);
    return inspection?.verified === true ? inspection.survivors : null;
  };

  const waitForExitProof = async (timeoutMs: number) => {
    const deadline = deps.now() + timeoutMs;
    const inspectIntervalMs = positiveDuration(
      input.inspectIntervalMs,
      DEFAULT_INSPECT_INTERVAL_MS,
    );
    let remainingDescendants: ReadonlyArray<CapturedProcess> | null = null;
    let lastInspectedAt: number | null = null;
    do {
      // Flush a root-exit resolution caused synchronously by a signal test double.
      await Promise.resolve();
      // Descendants can only prove exit once the root itself has, so inspecting
      // before that spends a blocking `ps` on a result that cannot end the wait.
      // Throttling the repeats keeps the poll responsive to the root's exit while
      // costing a couple of scans per teardown instead of one per poll.
      const sinceLastInspect = lastInspectedAt === null ? null : deps.now() - lastInspectedAt;
      if (rootExited && (sinceLastInspect === null || sinceLastInspect >= inspectIntervalMs)) {
        lastInspectedAt = deps.now();
        remainingDescendants = inspectDescendants();
        if (remainingDescendants !== null && remainingDescendants.length === 0) {
          return { proven: true as const, remainingDescendants };
        }
      }
      const remainingMs = deadline - deps.now();
      if (remainingMs <= 0) break;
      await deps.sleep(Math.min(positiveDuration(input.pollMs, DEFAULT_POLL_MS), remainingMs));
    } while (deps.now() <= deadline);
    // Giving up reports which descendants are still alive, so refresh the survivor
    // list once here rather than leaving it unknown when the gate above skipped
    // every poll's inspection.
    return { proven: false as const, remainingDescendants: inspectDescendants() };
  };

  signal("SIGTERM", true);
  const graceful = await waitForExitProof(
    positiveDuration(input.termGraceMs, DEFAULT_TERM_GRACE_MS),
  );
  if (graceful.proven) {
    return { escalated: false, signalErrors };
  }

  // A root can exit while descendants ignore TERM and become reparented. Preserve the captured
  // identities and force only those descendants rather than re-signalling a potentially reused PID.
  signal("SIGKILL", !rootExited);
  const forced = await waitForExitProof(positiveDuration(input.forceExitMs, DEFAULT_FORCE_EXIT_MS));
  if (forced.proven) {
    return { escalated: true, signalErrors };
  }

  throw new ProviderProcessExitUnprovenError({
    rootPid: input.rootPid,
    rootExited,
    remainingDescendantPids:
      forced.remainingDescendants?.map((descendant) => descendant.pid) ?? null,
    captureComplete: tree.captureComplete !== false,
  });
}
