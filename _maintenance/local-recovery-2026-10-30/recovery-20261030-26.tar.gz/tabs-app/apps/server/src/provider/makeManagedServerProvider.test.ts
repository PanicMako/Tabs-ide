import { describe, it, assert } from "@effect/vitest";
import { ProviderDriverKind, ProviderInstanceId, type ServerProvider } from "@tabs/contracts";
import { createModelCapabilities } from "@tabs/shared/model";
import * as Deferred from "effect/Deferred";
import * as Effect from "effect/Effect";
import * as Fiber from "effect/Fiber";
import * as PubSub from "effect/PubSub";
import * as Ref from "effect/Ref";
import * as Stream from "effect/Stream";

import * as Layer from "effect/Layer";
import * as BackgroundPolicy from "../background/BackgroundPolicy.ts";
import * as ServerSettings from "../serverSettings.ts";
import { makeManagedServerProvider } from "./makeManagedServerProvider";

const testLayer = Layer.mergeAll(
  Layer.mock(BackgroundPolicy.BackgroundPolicy)({}),
  Layer.mock(ServerSettings.ServerSettingsService)({
    getSettings: Effect.succeed({} as any),
  }),
);

const emptyCapabilities = createModelCapabilities({ optionDescriptors: [] });
const fastModeCapabilities = createModelCapabilities({
  optionDescriptors: [
    {
      id: "fastMode",
      label: "Fast Mode",
      type: "boolean",
    },
  ],
});

interface TestSettings {
  readonly enabled: boolean;
}

const maintenanceCapabilities = {
  provider: "codex" as ProviderDriverKind,
  packageName: "@openai/codex",
  update: {
    command: "npm install -g @openai/codex@latest",

    executable: "npm",

    args: ["install", "-g", "@openai/codex@latest"],

    lockKey: "npm-global",
  },
} as const;

const initialSnapshot: ServerProvider = {
  instanceId: "codex" as ProviderInstanceId,
  driver: "codex" as ProviderDriverKind,
  enabled: true,
  installed: true,
  version: null,
  status: "warning",
  auth: { status: "unknown" },
  checkedAt: "2026-04-10T00:00:00.000Z",
  message: "Checking provider availability...",
  models: [],
  slashCommands: [],
  skills: [],
};

const refreshedSnapshot: ServerProvider = {
  instanceId: "codex" as ProviderInstanceId,
  driver: "codex" as ProviderDriverKind,
  enabled: true,
  installed: true,
  version: "1.0.0",
  status: "ready",
  auth: { status: "authenticated" },
  checkedAt: "2026-04-10T00:00:01.000Z",
  models: [],
  slashCommands: [],
  skills: [],
};

const enrichedSnapshot: ServerProvider = {
  ...refreshedSnapshot,
  checkedAt: "2026-04-10T00:00:02.000Z",
  models: [
    {
      slug: "composer-2",
      name: "Composer 2",
      isCustom: false,
      capabilities: fastModeCapabilities,
    },
  ],
};

const refreshedSnapshotSecond: ServerProvider = {
  ...refreshedSnapshot,
  checkedAt: "2026-04-10T00:00:03.000Z",
  message: "Refreshed provider availability again.",
};

const enrichedSnapshotSecond: ServerProvider = {
  ...refreshedSnapshotSecond,
  checkedAt: "2026-04-10T00:00:04.000Z",
  models: [
    {
      slug: "gpt-5.4",
      name: "GPT-5.4",
      isCustom: false,
      capabilities: emptyCapabilities,
    },
  ],
};

describe("makeManagedServerProvider", () => {
  it.effect(
    "runs the initial provider check in the background and streams the refreshed snapshot",
    () =>
      Effect.scoped(
        Effect.gen(function* () {
          const checkCalls = yield* Ref.make(0);
          const releaseCheck = yield* Deferred.make<void>();
          const provider = yield* makeManagedServerProvider<TestSettings>({
            maintenanceCapabilities,
            getSettings: Effect.succeed({ enabled: true }),
            streamSettings: Stream.empty,
            haveSettingsChanged: (previous, next) => previous.enabled !== next.enabled,
            initialSnapshot: () => Effect.succeed(initialSnapshot),
            checkProvider: Ref.update(checkCalls, (count) => count + 1).pipe(
              Effect.flatMap(() => Deferred.await(releaseCheck)),
              Effect.as(refreshedSnapshot),
            ),
            refreshInterval: "1 hour",
          });

          const initial = yield* provider.getSnapshot;
          assert.deepStrictEqual(initial, initialSnapshot);

          const updatesFiber = yield* Stream.take(provider.streamChanges, 1).pipe(
            Stream.runCollect,
            Effect.forkChild,
          );
          yield* Effect.yieldNow;

          yield* Deferred.succeed(releaseCheck, undefined);

          const updates = Array.from(yield* Fiber.join(updatesFiber));
          const latest = yield* provider.getSnapshot;

          assert.deepStrictEqual(updates, [refreshedSnapshot]);
          assert.deepStrictEqual(latest, refreshedSnapshot);
          assert.strictEqual(yield* Ref.get(checkCalls), 1);
        }),
      ).pipe(Effect.provide(testLayer)) as any,
  );

  it.effect(
    "reruns the provider check when streamed settings change",
    () =>
      Effect.scoped(
        Effect.gen(function* () {
          const settingsRef = yield* Ref.make<TestSettings>({ enabled: true });
          const settingsChanges = yield* PubSub.unbounded<TestSettings>();
          const checkCalls = yield* Ref.make(0);
          const releaseInitialCheck = yield* Deferred.make<void>();
          const releaseSettingsCheck = yield* Deferred.make<void>();
          const provider = yield* makeManagedServerProvider<TestSettings>({
            maintenanceCapabilities,
            getSettings: Ref.get(settingsRef),
            streamSettings: Stream.fromPubSub(settingsChanges),
            haveSettingsChanged: (previous, next) => previous.enabled !== next.enabled,
            initialSnapshot: () => Effect.succeed(initialSnapshot),
            checkProvider: Ref.updateAndGet(checkCalls, (count) => count + 1).pipe(
              Effect.flatMap((count) =>
                count === 1
                  ? Deferred.await(releaseInitialCheck).pipe(Effect.as(refreshedSnapshot))
                  : Deferred.await(releaseSettingsCheck).pipe(Effect.as(refreshedSnapshotSecond)),
              ),
            ),
            refreshInterval: "1 hour",
          });

          const updatesFiber = yield* Stream.take(provider.streamChanges, 2).pipe(
            Stream.runCollect,
            Effect.forkChild,
          );
          yield* Effect.yieldNow;

          yield* Deferred.succeed(releaseInitialCheck, undefined);
          yield* Ref.set(settingsRef, { enabled: false });
          yield* PubSub.publish(settingsChanges, { enabled: false });
          yield* Deferred.succeed(releaseSettingsCheck, undefined);

          const updates = Array.from(yield* Fiber.join(updatesFiber));
          const latest = yield* provider.getSnapshot;

          assert.deepStrictEqual(updates, [refreshedSnapshot, refreshedSnapshotSecond]);
          assert.deepStrictEqual(latest, refreshedSnapshotSecond);
          assert.strictEqual(yield* Ref.get(checkCalls), 2);
        }),
      ).pipe(Effect.provide(testLayer)) as any,
  );

  it.effect(
    "streams supplemental snapshot updates after the base provider check completes",
    () =>
      Effect.scoped(
        Effect.gen(function* () {
          const releaseEnrichment = yield* Deferred.make<void>();
          const releaseCheck = yield* Deferred.make<void>();
          const provider = yield* makeManagedServerProvider<TestSettings>({
            maintenanceCapabilities,
            getSettings: Effect.succeed({ enabled: true }),
            streamSettings: Stream.empty,
            haveSettingsChanged: (previous, next) => previous.enabled !== next.enabled,
            initialSnapshot: () => Effect.succeed(initialSnapshot),
            checkProvider: Deferred.await(releaseCheck).pipe(Effect.as(refreshedSnapshot)),
            enrichSnapshot: ({ publishSnapshot }) =>
              Deferred.await(releaseEnrichment).pipe(
                Effect.flatMap(() => publishSnapshot(enrichedSnapshot)),
              ),
            refreshInterval: "1 hour",
          });

          const updatesFiber = yield* Stream.take(provider.streamChanges, 2).pipe(
            Stream.runCollect,
            Effect.forkChild,
          );
          yield* Effect.yieldNow;

          yield* Deferred.succeed(releaseCheck, undefined);

          yield* Deferred.succeed(releaseEnrichment, undefined);

          const updates = Array.from(yield* Fiber.join(updatesFiber));
          const latest = yield* provider.getSnapshot;

          assert.deepStrictEqual(updates, [refreshedSnapshot, enrichedSnapshot]);
          assert.deepStrictEqual(latest, enrichedSnapshot);
        }),
      ).pipe(Effect.provide(testLayer)) as any,
  );

  it.effect(
    "ignores stale enrichment callbacks after a newer refresh advances generation",
    () =>
      Effect.scoped(
        Effect.gen(function* () {
          const publishCallbacks: Array<(snapshot: ServerProvider) => Effect.Effect<void>> = [];
          const refreshCount = yield* Ref.make(0);
          const firstCallbackReady = yield* Deferred.make<void>();
          const secondCallbackReady = yield* Deferred.make<void>();
          const allowFirstRefresh = yield* Deferred.make<void>();
          const provider = yield* makeManagedServerProvider<TestSettings>({
            maintenanceCapabilities,
            getSettings: Effect.succeed({ enabled: true }),
            streamSettings: Stream.empty,
            haveSettingsChanged: (previous, next) => previous.enabled !== next.enabled,
            initialSnapshot: () => Effect.succeed(initialSnapshot),
            checkProvider: Ref.updateAndGet(refreshCount, (count) => count + 1).pipe(
              Effect.flatMap((count) =>
                count === 1
                  ? Deferred.await(allowFirstRefresh).pipe(Effect.as(refreshedSnapshot))
                  : Effect.succeed(refreshedSnapshotSecond),
              ),
            ),
            enrichSnapshot: ({ publishSnapshot }) =>
              Effect.gen(function* () {
                publishCallbacks.push(publishSnapshot);
                if (publishCallbacks.length === 1) {
                  yield* Deferred.succeed(firstCallbackReady, undefined).pipe(Effect.ignore);
                } else if (publishCallbacks.length === 2) {
                  yield* Deferred.succeed(secondCallbackReady, undefined).pipe(Effect.ignore);
                }
              }),
            refreshInterval: "1 hour",
          });

          const updatesFiber = yield* Stream.take(provider.streamChanges, 3).pipe(
            Stream.runCollect,
            Effect.forkChild,
          );
          yield* Effect.yieldNow;

          yield* Deferred.succeed(allowFirstRefresh, undefined);
          yield* Deferred.await(firstCallbackReady);

          yield* provider.refresh;
          yield* Deferred.await(secondCallbackReady);

          yield* publishCallbacks[0]!(enrichedSnapshot);
          yield* publishCallbacks[1]!(enrichedSnapshotSecond);

          const updates = Array.from(yield* Fiber.join(updatesFiber));
          const latest = yield* provider.getSnapshot;

          assert.deepStrictEqual(updates, [
            refreshedSnapshot,
            refreshedSnapshotSecond,
            enrichedSnapshotSecond,
          ]);
          assert.deepStrictEqual(latest, enrichedSnapshotSecond);
        }),
      ).pipe(Effect.provide(testLayer)) as any,
  );
});
